#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""实时统计AB测试及模型的点击率
@Time    : '2018/6/27 下午2:48'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'cal_real_index.py.py'
"""
import redis

REDIS_HOST='10.19.131.137'
REDIS_PORT = "6379"

import redis_memorycache as rmu
import pandas as pd
import sys
import datetime


def main():
    if len(sys.argv)==1:
        dt = datetime.datetime.today().strftime("%Y-%m-%d")
    else:
        dt = sys.argv[1]
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    expose_dict = get_index(r.hgetall("wx_expose_"+dt))
    click_dict = get_index(r.hgetall("wx_click_" + dt))
    playtime_dict = get_index(r.hgetall("wx_playtime_"+dt))
    cal_index(expose_dict, click_dict, playtime_dict)


def cal_index(expose_dict, click_dict, playtime_dict):
    exp_total, exp_model, exp_source  = expose_dict
    click_total, click_model, click_source = click_dict
    pt_total, pt_model, pt_source = playtime_dict
    strategy_ctr = get_ctr(exp_total, click_total,pt_total, ['hour', 'strategy','value'], 'value')
    strategy_model_ctr = get_ctr(exp_model, click_model, pt_model,['hour', 'strategy','model', 'value'], 'value')
    strategy_source_ctr = get_ctr(exp_source, click_source,pt_source,['hour', 'strategy', 'source', 'value'], 'value')
    save(strategy_ctr, "./data/strategy_ctr.csv")
    save(strategy_model_ctr, "./data/strategy_model_ctr.csv")
    save(strategy_source_ctr, "./data/strategy_source_ctr.csv")

def save(dt, filename):
    dtr = dt.values.tolist()
    with open(filename, "w") as f:
        for line in dtr:
            value = "\t".join(map(str, line))
            print value
            f.write(value +"\n")


def get_ctr(exp, click, pt,cols, rename_col):
    exp_data = pd.DataFrame(exp, columns=cols)
    exp_data.rename(columns={rename_col: 'expose'}, inplace=True)
    click_data = pd.DataFrame(click, columns=cols)
    click_data.rename(columns={rename_col: 'click'}, inplace=True)
    pt_data = pd.DataFrame(pt, columns=cols)
    pt_data.rename(columns={rename_col: 'pt'}, inplace=True)
    cols.remove(rename_col)
    exp_click = pd.merge(exp_data, click_data,how ='left', on=cols).fillna(0)
    exp_click = pd.merge(exp_click, pt_data, how ='left', on=cols).fillna(0)
    exp_click['ctr'] =  exp_click['click']/exp_click['expose']
    return exp_click




def get_index(expose_click_dict):
    total = []
    source = []
    model=[]
    for k, v in expose_click_dict.iteritems():
        value = float(v)
        if k.startswith("t_"):
            hour,strategy = k.strip().split("_")[1:3]
            total.append((hour, strategy, value))
        elif k.startswith("s_"):
            hour, strategy, lsource = k.strip().split("_")[1:4]
            source.append((hour, strategy, lsource, value))
        elif k.startswith("m_"):
            hour, strategy, lmodel = k.strip().split("_")[1:4]
            model.append((hour, strategy, lmodel, value))
    return [total, model, source]

if __name__ =="__main__":
    main()
