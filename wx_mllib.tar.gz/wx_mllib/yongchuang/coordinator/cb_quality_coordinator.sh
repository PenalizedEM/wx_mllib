#!/bin/sh

#source /etc/profile
export PATH=${PATH}
HADOOP_HOME=/home/hadoop
########################################
########################################

date=`date +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
datebuf=$1

if [ -z "$1" ] ;then
date=`date -d "1 days ago" +"%Y-%m-%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
exit 0
fi
fi

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf



########################################
echo "`date` [INFO] ----------- 1��distcp video to weixin  to cluster begin ---------"
########################################
{
${HADOOP_HOME}/bin/hadoop distcp -overwrite hdfs://10.10.186.203:8020/olap/da/cb_quality_score/${datebuf} /olap/da/cb_quality_score
} >> ../log/distcp_cb_quality_score_${datebuf}.log 2>&1


