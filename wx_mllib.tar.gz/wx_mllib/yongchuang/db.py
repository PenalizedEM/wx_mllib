#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/9/25 上午10:33'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'db.py'
"""

import os
import sys
import MySQLdb
import logging

DB_HOST = None
DB_USER = None
DB_PASSWD = None
DB_DB = None
DB_PORT = None

def init(host="127.0.0.1", user="root", passwd="cyc__ruc", db='online',database='tangdouapp', port=3306):
    global DB_HOST, DB_USER, DB_PASSWD, DB_DB, DB_PORT
    if db == 'online':
        DB_HOST='10.10.120.205'
        #DB_USER='root'
        #DB_PASSWD='tangdouapp#123'
        DB_USER='bigdata'
        DB_PASSWD='bsZUE(=3XJDxR5L3'
        DB_DB='tangdouapp'
        DB_PORT=3306
    else:
        DB_HOST = host
        DB_USER =user
        DB_PASSWD = passwd
        DB_DB = database
        DB_PORT=port
init()

def connect_db():
	try:
		db_conn = MySQLdb.connect(host=DB_HOST,user=DB_USER,passwd=DB_PASSWD,db=DB_DB,port=DB_PORT,\
                local_infile=True,init_command='set names utf8',use_unicode = True, charset = 'utf8')
	except MySQLdb.Error,e:
		logging.error("mysql connect faild")
	return db_conn        

def query(sql):
	conn = connect_db()
	cur = conn.cursor()
	cur.execute(sql)
	for row in cur:
		yield row
	cur.close()
	conn.close()

def commit(sql):
	try:
		conn = connect_db()
		cur = conn.cursor()
		cur.execute(sql)
		conn.commit() # must commit
		#print >> sys.stderr, 'execute sql succussed: %s' % sql
		print >> sys.stderr, 'execute sql succussed'
	except MySQLdb.Error,e:
		logging.error('execute sql failed: %s' % e)
	cur.close()
	conn.close()


if __name__ == '__main__':
    #for row in query('select * from user_data'):
    #    print row[4]
    #    break
    #commit('ALTER TABLE user_data ALTER COLUMN uid varchar(32)')
    #commit('insert into user_data (uid, province, city, traj_point_data, stay_point_data) values ("a", "b", "c" ,"d", "e")')
    #commit('delete from user_data where uid="9F225970981F25CD647DF2A468457727|179555250985353"')
    commit('delete from user_data where uid!="9a"')

