#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""构建广场舞feed流数据源
@Time    : '2018/7/16 下午4:01'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'gcw_feed_flow.py.py'
"""
import db
import redis_memorycache as rmu
import os

REDIS_HOST= "10.19.34.74"
LIFT_REDIS_HOST="10.19.141.180"
SERVICE_REDIS_HOST = "10.10.119.135"
REDIS_PORT = "6379"
MYSQL_HOST = "10.10.115.174"
MYSQL_USER ="weixin"
MYSQL_PWD = 'tangdouapp#123'
TOPN = 36
TOPB = 450
import hadoop


def main():
    r = rmu.init_redis_online(host=REDIS_HOST, port=REDIS_PORT)
    #所有的数据
    lite_feed_video = build_recommend()
    rmu.loaddata2redis(r, lite_feed_video, tag='lite_feed', key_redis='w_feed_flow')
    #最新的top
    lite_new_video = build_recommend_new()
    rmu.loaddata2redis(r, lite_new_video, tag='lite_feed_new', key_redis='w_feed_new')
    #最近视频
    lite_last_video = build_recommend_last()
    rmu.loaddata2redis(r, lite_last_video, tag='lite_feed_last', key_redis='w_feed_last')
    build_last_video(r, lite_last_video)
    #加载所有的数据到hdfs
    # gcw
    recommend2hdfs()
    # 爱生活
    recommend2hdfs("life")
    r=rmu.init_redis_online(host=LIFT_REDIS_HOST, port=REDIS_PORT)
    #rmu.loadfile2redisset(r, "./data/life_recom", "life_rec")
    rmu.loadfile2redisset(r, "./data/amuse_recom", "amuse_rec")
    #rmu.loadfile2redisset(r, "./data/life_top", "life_top")
    rmu.loadfile2redisset(r, "./data/amuse_top", "amuse_top")
    build_life_recommed()
    lite_flow_video=get_life_all_recommend()
    rmu.loaddata2redis(r, lite_flow_video, tag='life_flow', key_redis="life_flow")

def build_life_recommed():
    """获取爱生活相关推荐视频
    """
    # top 视频
    get_life_recommed("relation_video_list:yangsheng_interest_video", "./data/life_top")
    # 老用户尾部视频
    get_life_recommed("relation_video_list:yangsheng_old_user", "./data/life_recom_old")
    # 新用户尾部视频
    get_life_recommed("relation_video_list:yangsheng_new_user", "./data/life_recom_new")
    #  导入新集群
    r = rmu.init_redis_online(host=LIFT_REDIS_HOST, port=REDIS_PORT)
    rmu.loadfile2redisset(r, "./data/life_top", "life_top")
    rmu.loadfile2redisset(r, "./data/life_recom_old", "life_recom_old")
    rmu.loadfile2redisset(r, "./data/life_recom_new", "life_recom_new")


def get_life_recommed(redis_key, save_dir):
    r = rmu.init_redis_online(host=SERVICE_REDIS_HOST, port=REDIS_PORT)
    # 获取头部视频
    life_data = r.lrange(redis_key, 0, -1)
    with open(save_dir, "w") as f:
        for vid in life_data:
            f.write(vid + "\n")


def build_last_video(r, lite_last_video):
    with open("./data/feed_last_set", "w") as f:
        for key, vid in lite_last_video:
            f.write(vid + "\n")
    rmu.loadfile2redisset(r, "./data/feed_last_set", "feed_last_set")

        


def recommend2hdfs(cate="gcw"):
    """加载广场舞数据到hdfs
    """
    db.init(host=MYSQL_HOST, user=MYSQL_USER, passwd=MYSQL_PWD, db='offline', database='lite_weixin')
    if cate=="gcw":
        sql = "SELECT vid, type FROM home_recommend where type=1 order by uptime desc"
        recommend_hdfs = "/olap/da/gcw_recommend/"
    elif cate=="life":
        sql = "select vid, type FROM home_recommend where type in (2,3,4,5,6,10,11) order by uptime desc"
        recommend_hdfs = "/olap/da/life_recommend/"
    vids = db.query(sql)
    file = "recommed"
    vid_dict= dict()
    i =0
    with open("./" + file, "w") as f:
        for vid, type in vids:
            if vid not in vid_dict.keys():
                vid_dict[vid] = type
            else:
                continue
            i +=1
            f.write("\t".join(map(str, [vid, type])) + "\n")
    if cate=="life":
        vid_dict_add = merge_life(vid_dict)
        print "add vid nums is %d" % len(vid_dict_add.keys())
        with open("./" + file, "a") as f:
            for vid, type in vid_dict_add.iteritems():
                f.write("\t".join(map(str, [vid, type])) + "\n")
    if hadoop.is_file_exist(recommend_hdfs + file) ==0:
        hadoop.rm_dir(recommend_hdfs+file)
    print "job %s nums is %d" %(cate, i) 
    hadoop.put("./" + file, recommend_hdfs)
    os.system("rm -fr %s" %file)

def merge_life(vid_dict):
    vid_dict_add = dict()
    r = rmu.init_redis_online(host=SERVICE_REDIS_HOST, port=REDIS_PORT)
    life_top = r.lrange("relation_video_list:yangsheng_interest_video", 0, -1)
    recom_old = r.lrange("relation_video_list:yangsheng_old_user", 0, -1)
    recom_new = r.lrange("relation_video_list:yangsheng_new_user", 0, -1)
    for vid in life_top:
        vid = str(vid)
        if vid not in vid_dict.keys():
            vid_dict_add[vid] = "-1"
            vid_dict[vid]= "-1"
    for vid in recom_old:
        vid = str(vid)
        if vid not in vid_dict.keys():
            vid_dict_add[vid] = "-2"
            vid_dict[vid] = "-2"
    for vid in recom_new:
        vid = str(vid)
        if vid not in vid_dict.keys():
            vid_dict_add[vid]= "-3"
            vid_dict[vid] = "-3"
    return vid_dict_add



def build_recommend():
    """获取推荐的商品
    """
    db.init(host=MYSQL_HOST, user=MYSQL_USER, passwd=MYSQL_PWD, db='offline', database='lite_weixin')
    sql ="SELECT vid FROM home_recommend where type=1 order by uptime desc"
    vids = db.query(sql)
    all_video = [("w_feed_flow", str(vid[0])) for vid in vids]
    all_video = all_video[::-1]
    return all_video

def get_life_all_recommend():
    """获取推荐的商品
    """
    db.init(host=MYSQL_HOST, user=MYSQL_USER, passwd=MYSQL_PWD, db='offline', database='lite_weixin')
    sql ="SELECT vid FROM home_recommend where type in (2,3,4,5,6,10,11) order by uptime desc"
    vids = db.query(sql)
    all_video = [("life_flow", str(vid[0])) for vid in vids]
    all_video = all_video[::-1]
    return all_video

def build_recommend_new(topn=TOPN):
    """获取推荐的商品
    """
    db.init(host=MYSQL_HOST, user=MYSQL_USER, passwd=MYSQL_PWD, db='offline', database='lite_weixin')
    sql ="SELECT vid FROM home_recommend where type=1 order by uptime desc limit %s" %topn
    vids = db.query(sql)
    all_video = [("w_feed_new", str(vid[0])) for vid in vids]
    all_video = all_video[::-1]
    return all_video

def build_recommend_last(topa=TOPN, topb=TOPB):
    """获取推荐的商品
    """
    db.init(host=MYSQL_HOST, user=MYSQL_USER, passwd=MYSQL_PWD, db='offline', database='lite_weixin')
    sql ="SELECT vid FROM home_recommend where type=1  order by uptime desc limit %s, %s" %(topa, topb)
    vids = db.query(sql)
    all_video = [("w_feed_last", str(vid[0])) for vid in vids]
    all_video = all_video[::-1]
    return all_video




if __name__ == "__main__":
    main()



