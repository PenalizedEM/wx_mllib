#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取node2vec特征数据
@Time    : '2018/9/3 上午11:48'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'filter_node2vec.py'
"""
import sys
import datetime
import hadoop
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from optparse import OptionParser

NODE_EMB="hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/word2vec_feature/"
NODE_EMB_FILTER="/olap/da/node2vec_feature/"
LIFE_NODE_EMB_FILTER="/olap/da/life_node2vec_feature/"
NODE_INDEX="hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/node2vec_result.n2i"
LIFE_DIR = "/olap/da/life_recommend/recommed"


def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--node_feature_dir", dest="node_feature_dir", default=NODE_EMB, help="node features dir")
    parser.add_option("--item_feature_dir", dest="item_feature_dir", default=NODE_EMB_FILTER, help="item features dir")
    parser.add_option("--update_life", dest="update_life", default=True, help="item features dir")
    (flags, args) = parser.parse_args(args)
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_day = (datetime.datetime.today()- datetime.timedelta(7)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.appName('filter_node2vec:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    flags.update_life = check_bool(flags.update_life)
    del_dir = [flags.item_feature_dir]
    if flags.update_life:
        del_dir.append(LIFE_NODE_EMB_FILTER)
    hadoop.del_hdfs(del_dir, [model_day, del_day])
    input_dir = flags.node_feature_dir + model_day
    embedding_features = load_embedding_features(sc, input_dir)
    embedding_features = spark.createDataFrame(embedding_features)
    embedding_features.createOrReplaceTempView("embedding_features")
    node_index = load_nodeindex(sc)
    node_index = spark.createDataFrame(node_index)
    node_index.createOrReplaceTempView("node_index")
    sql = "select c.vid, a.features_vec  from embedding_features a \
    join node_index c on(c.index = a.uid_vid) \
    join da.video b  on(c.vid = b.vid) \
    where b.uid >0  and b.sync =0 and \
    b.status =0 and b.type not in (10,12)"
    save_features_dir = NODE_EMB_FILTER + model_day
    feature_vec = spark.sql(sql)
    feature_vec.rdd.map(lambda x: "\t".join([x['vid'], x['features_vec']])).coalesce(1)\
        .saveAsTextFile(save_features_dir)
    if flags.update_life:
        save_features_dir = LIFE_NODE_EMB_FILTER + model_day
        life_dt = sc.textFile(LIFE_DIR)\
            .map(lambda x: x.strip().split("\t")[:2]).collectAsMap()
        life_video_dict = sc.broadcast(life_dt)
        feature_vec.rdd.map(lambda x: [x['vid'], x['features_vec']])\
            .filter(lambda x: x[0] in life_video_dict.value.keys())\
            .map(lambda x: "\t".join(x)).coalesce(1)\
            .saveAsTextFile(save_features_dir)
    spark.stop()


def load_embedding_features(sc, dir):
    def parse_emb(line):
        segment=line.strip().split("\t")
        if len(segment) !=2:
            return None
        else:
            uid_vid, feature_vec = segment
            return [uid_vid, feature_vec]
    return sc.textFile(dir).map(parse_emb)\
        .filter(lambda x: x is not None)\
        .map(lambda x: Row(uid_vid= x[0], features_vec= x[1]))

def load_nodeindex(sc):
    def parser(line):
        segment = line.strip().encode("utf-8").split("\t")
        if len(segment)!=2:
            return None
        return [segment[0], segment[1]]
    node_index = sc.textFile(NODE_INDEX)\
        .map(parser).filter(lambda x: x is not None)\
        .map(lambda x: Row(vid= x[0], index= x[1]))
    return node_index


def check_bool(flags):
    if flags in ['False','F','false','f', False]:
        return False
    elif flags in ['True', 'T', 'true', 't', True]:
        return True


if __name__ == "__main__":
    main()



