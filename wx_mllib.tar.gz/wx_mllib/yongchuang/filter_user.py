import zlib
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession

Flow =[10, 100]
from optparse import OptionParser
import sys
import hadoop

def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--input", dest="input", default='', help="input dir")
    parser.add_option("--output", dest="output", default='', help="ouput dir")
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    (flags, args) = parser.parse_args(args)
    spark = SparkSession.builder \
        .appName('diu_filter:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    hadoop.del_oldhdfs(flags.output)
    data= sc.textFile(flags.input).map(get_ab).filter(lambda x: x is not None)
    data.saveAsTextFile(flags.output)
    spark.stop()

def get_ab(line):
    diu_1, recs = line.strip().encode("utf-8").split("\t", 1)
    crc = zlib.crc32(diu_1) & 0xffffffff
    ab_tag = crc %100
    if ab_tag >=Flow[0] and ab_tag <=Flow[1]:
        return "\t".join([diu_1, recs])
    else:
        return None

if __name__ == "__main__":
    main()
