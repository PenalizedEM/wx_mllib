#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取近线推荐
@Time    : '2018/9/20 下午3:55'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_log.py'
"""
import hadoop
import datetime

def get_log():
    mode_day = datetime.datetime.today().strftime("%y-%m-%d")
    del_day = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%y-%m-%d")
    obj_master='10.42.55.58'
    in_hdfs="hdfs://10.10.186.203:8020/weixin/" + mode_day
    #out_hdfs="hdfs://" + obj_master + ":8020/weixin/" + mode_day
    out_hdfs="/weixin/" + mode_day
    del_hdfs = "/weixin/" + del_day
    #del_hdfs = "hdfs://" + obj_master +":8020/weixin/" + del_day
    print in_hdfs, out_hdfs
    if hadoop.is_dir_exist(del_hdfs)==0:
        hadoop.rm_dir(del_hdfs)
    if hadoop.is_dir_exist(out_hdfs)==0:
        hadoop.rm_dir(out_hdfs)
    hadoop.distcp(in_hdfs, out_hdfs)


if __name__ == "__main__":
    get_log()

