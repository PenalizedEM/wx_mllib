#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/6/5 下午12:43'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'hadoop.py.py'
"""
import os
HADOOP_BIN='/home/hadoop/bin/hadoop'

def del_hdfs(dirs, dts):
    """将路径对应时间下的文件删除
    """
    for dir in dirs:
        for dt in dts:
            del_oldhdfs(dir, dt)

def del_oldhdfs(dir, dt=None):
    if dt is not None:
        if not dir.endswith("/"):
            dir = dir + "/"
        dir = dir + dt
    if is_dir_exist(dir) == 0:
        rm_dir(dir)


def is_dir_exist(hadoop_dir):
    """
    判断hadoop目录是否存在，如果存在返回0，否则返回1
    """
    cmd = "%s fs -test -d %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8

def is_file_exist(hadoop_dir):
    """
    判断hadoop文件是否存在，如果存在返回0，否则返回1
    """
    cmd = "%s fs -test -e %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8

def rm_dir(hadoop_dir):
    """
    递归删除目录，成功返回0，失败返回255
    """
    print "del hdfs %s" %hadoop_dir
    cmd = "%s fs -rm -r %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8

def getmerge(hadoop_dir, local_file):
    """
    将一个hadoop文件或者目录拷贝到本地文件，成功返回0，失败返回255
    """
    cmd = "%s fs -getmerge %s %s" % (HADOOP_BIN, hadoop_dir, local_file)
    ret = os.system(cmd)
    return ret >> 8

def put(local_dir, hadoop_dir):
    """
    将一个本地local_dir的目录或者文件上传到hadoop_dir，成功返回0，失败返回255
    """
    cmd = "%s fs -put %s %s" % (HADOOP_BIN, local_dir, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8


def mkdir(hadoop_dir):
    """
    新建目录，成功返回0，失败返回255
    """
    cmd = "%s fs -mkdir %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8

def distcp(in_dir, out_dir):
    """copy 目录文件
    """
    cmd = "%s distcp -overwrite %s %s" % (HADOOP_BIN, in_dir, out_dir)
    ret = os.system(cmd)
    return ret >> 8
