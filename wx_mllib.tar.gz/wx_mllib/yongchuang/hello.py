#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/9/6 下午12:50'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'helloword.py'
"""
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
def main():
    #spark = SparkSession.builder.appName("Word Count").getOrCreate()
    spark = SparkSession.builder.appName("Word Count").config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sql ="select * from da.recy_ucf_rating2 limit 10"
    result=spark.sql(sql).rdd.map(lambda x: [x['diu'], x['vid']])
    #sc.parallelize([['a',1],['b',1],['a',2]])\
    #    .reduceByKey(lambda a,b :a+b)\
    result.repartition(1).saveAsTextFile("/user/yongchuang/hello")


if __name__ == "__main__":
    main()

