#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""item_based CF,基于最近3个月用户点击视频行为来计算视频的相似度，同时产生用户的个性化推荐列表
@Time    : '2018/6/5 上午10:41'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'item_cf.py.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import pyspark.sql.functions as sf
import datetime
import sys
import math
import recommder
import util
import hadoop
# item2item商品的相似邻居的个数
NEIGHBOURS = 50
# 用户推荐商品个数
RECOMMED_NUMS = 50
# 用于个性化计算视频的相似度
HIGH_NEIGHBOURS= 20


INPUT_DIR=''
# 基于cf计算的视频到视频的相似度
CF_ITEM2ITEM_DIR = "/olap/da/cf_item2item/"
#  计算gcw feed流 item2item视频相似度
GCW_ITEM2ITEM_DIR = "/olap/da/gcw_item2item/"
#  计算life feed流 item2item视频相似度
LIFE_ITEM2ITEM_DIR = "/olap/da/life_item2item/"
LIFE_CF_PERSONAL_DIR = "/olap/da/life_cf_personal/"
# 基于cf计算视频的个性化候选列表
CF_PERSONAL_DIR = "/olap/da/cf_personal/"
# item cf视频相似度模型id
SIMIL_MODE_ID = "11"
GCW_SIMIL_MODE_ID = "16"
# item cf个性化推荐列表
PERSONAL_MODE_ID = "21"
UPDATE_ITEM_SIMIL=True
UPDATE_LIFE = True
WEIGHTS=0.5
SIMIL_FILTER=0.005

from optparse import OptionParser



def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--uvr_dir", dest="uvr_dir", default='', help="user item pref dir")
    parser.add_option("--item2item_dir", dest="item2item_dir", default=CF_ITEM2ITEM_DIR, help="cf item simil dir")
    parser.add_option("--is_dt", dest="is_dt", default=True, help="whether item simil dir add date")
    parser.add_option("--personal_dir", dest="personal_dir", default=CF_PERSONAL_DIR, help="cf personal dir")
    parser.add_option("--update_simil", dest="update_simil", default=UPDATE_ITEM_SIMIL, help="whether update item simil")
    parser.add_option("--update_life", dest="update_life", default=UPDATE_LIFE, help="whether update life")
    (flags, args) = parser.parse_args(args)
    mode_date = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.master('yarn-client') \
        .appName('item_cf:' + mode_date) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.addPyFile("recommder.py") 
    sc.addPyFile("hadoop.py") 
    sc.addPyFile("util.py") 
    cf_item_dir = flags.item2item_dir
    cf_personal_dir = flags.personal_dir
    flags.update_simil = check_bool(flags.update_simil)
    flags.is_dt = check_bool(flags.is_dt)
    flags.update_life = check_bool(flags.update_life)
    del_date = (datetime.datetime.today() - datetime.timedelta(4)).strftime("%Y-%m-%d")
    # 删除无效的数据:当天及历史数据
    cf_del_dir = [cf_personal_dir]
    if flags.update_simil:
        cf_del_dir.append(cf_item_dir)
        cf_del_dir.append(GCW_ITEM2ITEM_DIR)
    if flags.update_life:
        cf_del_dir.append(LIFE_ITEM2ITEM_DIR)
        cf_del_dir.append(LIFE_CF_PERSONAL_DIR)
    hadoop.del_hdfs(cf_del_dir, [mode_date, del_date])
    sc = spark.sparkContext
    # 输入数据源进行大小视频的拆分
    util.update_table(spark)
    if flags.update_simil:
        user_item_weight = util.load_file(spark, INPUT_DIR, method='cf').map(lambda x: x[:4])
        user_item = user_item_weight.map(lambda (uid, item_id, weights, act_day): [uid, item_id])
        item2item_simil = cf_item_simil(spark, user_item)
        # 合并app item2item
        item2item_simil_topn= merge_item2item(spark, item2item_simil, NEIGHBOURS)
        item2item_simil_topn.persist()
        # 输出item2item相似度
        item2item_simil_topn.map(lambda x: util.add_mode_id(x, SIMIL_MODE_ID)).\
        coalesce(200).saveAsTextFile(cf_item_dir + mode_date)
        # 输出gcw feed流item2item相似度
        gcw_feed_simil = build_business_item2item(sc, item2item_simil_topn)
        #gcw_feed_simil = build_business_item2item(sc, item2item_simil)
        gcw_feed_simil.map(lambda x: util.add_mode_id(x, GCW_SIMIL_MODE_ID))\
            .coalesce(200).saveAsTextFile(GCW_ITEM2ITEM_DIR + mode_date)
        # 输出life feed流item2item相似度
        if flags.update_life:
            life_feed_simil = build_business_item2item(sc, item2item_simil_topn,type='life')
            #life_feed_simil = build_business_item2item(sc, item2item_simil,type='life')
            life_feed_simil.map(lambda x: util.add_mode_id(x, SIMIL_MODE_ID))\
                .coalesce(200).saveAsTextFile(LIFE_ITEM2ITEM_DIR + mode_date)
    else:
        # 加载item2item的相似度数据
        item2item_simil_topn = util.load_item2item(sc, cf_item_dir, flags.is_dt)
        item2item_simil_topn.persist()
    get_personal_recom(spark, item2item_simil_topn, mode_date, "squaredance")
    if flags.update_life:
        get_personal_recom(spark, life_feed_simil, mode_date, "yangsheng")
    item2item_simil_topn.unpersist()
    spark.stop()

def get_personal_recom(spark, item2item_simil_topn, mode_date, appname="squaredance"):
    sc = spark.sparkContext
    user_item_weight = util.load_file(spark, INPUT_DIR, method='cf', appname=appname).map(lambda x: x[:4])
    active_user_item = get_active(sc, user_item_weight)
    # 个性化推荐列表,过滤点击过的视频
    user_recommed_list = recommder.recommed_user(sc,
                                                 item2item_simil_topn.filter(lambda x: x[3] < HIGH_NEIGHBOURS),
                                                 active_user_item, RECOMMED_NUMS * 5)
    if appname=='squaredance':
        personal_dir = CF_PERSONAL_DIR
    elif appname == 'yangsheng':
        personal_dir = LIFE_CF_PERSONAL_DIR
    # 个性化推荐列表, 需过滤历史推荐数据
    filter_user_recommed = util.filter_recommed_history(sc, user_recommed_list, personal_dir)
    # 过滤曝光数据
    filter_recommed = util.filter_exposure(spark, filter_user_recommed, appname=appname)
    user_recommed_save = util.sorted_recommed(filter_recommed, topn=RECOMMED_NUMS)
    user_recommed_save.map(lambda x: util.add_mode_id(x, PERSONAL_MODE_ID)). \
        coalesce(200).saveAsTextFile(personal_dir + mode_date)


def build_business_item2item(sc, item2item_simil, type="gcw", is_merge=True):
    """过滤gcw item2item相似度
    """
    def load_gcw(sc, dir):
        all_videos = sc.textFile(dir)\
            .map(lambda x: x.strip().split("\t")[:2]).collectAsMap()
        return all_videos
    if type=="gcw":
        dir = "/olap/da/gcw_recommend/recommed"
    elif type=="life":
        dir = "/olap/da/life_recommend/recommed"
    feed_video = load_gcw(sc, dir)
    feed_video_dict = sc.broadcast(feed_video)
    if is_merge:
        item2item_filter= item2item_simil.filter(lambda x: x[1] in feed_video_dict.value.keys())\
            .map(lambda x:[x[0],(x[1], x[2])])
    else:
        item2item_filter= item2item_simil.filter(lambda x: x[1][0] in feed_video_dict.value.keys())
    item2item_topn = util.sorted_recommed(item2item_filter)
    return item2item_topn



def get_active(sc, user_item_weight):
    """获取活跃用户或者最近登陆用户
    """
    last_week = datetime.datetime.today()-datetime.timedelta(8)
    user_item_last = user_item_weight.filter(lambda x: datetime.datetime.strptime(x[3], "%Y-%m-%d") < last_week)
    user_filter = user_item_last.map(lambda (uid, item_id, weights, act_day):[uid, set([act_day])])\
        .reduceByKey(lambda a, b: a|b)\
        .map(lambda (uid, act_days): [uid, len(act_days)])\
        .filter(lambda x: x[1] >=3)
    active_user = user_item_last.map(lambda (uid, item_id, weights, act_day):[uid, (item_id, weights)])\
        .join(user_filter)\
        .map(lambda (uid, ((item_id, weights), act_days)): [uid, item_id, weights])
    user_new = user_item_weight.filter(lambda x: datetime.datetime.strptime(x[3], "%Y-%m-%d") >= last_week)\
        .map(lambda (uid, item_id, weights, act_day):[uid, item_id, weights])
    return active_user.union(user_new)



def merge_item2item(spark, item2item_simil, neighbours, is_merge=True):
    """
    """
    if is_merge:
        cols = ["vid_1", "vid_2", "similarity", "rank"]
        sql = "select %s from da.cb_quality_score where similarity > %s and vid_1 <> vid_2" %(",".join(cols), SIMIL_FILTER)
        #sql = "select %s from da.recy_icf_similarity_topn_b where similarity > %s" %(",".join(cols), SIMIL_FILTER)
    	item2item_simil_app = spark.sql(sql).rdd.map(lambda x: (x['vid_1'],(x['vid_2'], (1-WEIGHTS)*x['similarity'])))
        item2item_simil_all = item2item_simil.union(item2item_simil_app)
    else:
        item2item_simil_all = item2item_simil
    # 业务过滤数据
    filter_item2item = util.filter_item2item(spark, item2item_simil_all)
    # 过滤，排序, 小视频top100且 simil>0.01， 大视频top50;小视频35天，大视频7天。最近365天的数据
    item_topn = util.sorted_recommed(filter_item2item, topn=neighbours)
    return item_topn


def cf_item_simil(spark, user_item_ID):
    """计算item2item 的cosine相似度
    Args:
        user_item_ID:用户-视频数据
    Returns:
        item2item_simil:(item1,(item2,simil))分别为item1,item2,cosine相似度
    """
    user_item_item = user_item_ID.join(user_item_ID).map(lambda (uid, (item1, item2)): [(item1, item2), uid]).repartition(4000)
    #item_item_nums = user_item_item.map(lambda ((item1, item2), uid): [(item1, item2), set([uid])])\
    #    .reduceByKey(lambda a, b: a | b).map(lambda ((item1, item2), uidlist): [(item1, item2), len(uidlist)])
    item_item_nums = user_item_item.map(lambda ((item1, item2), uid): [(item1, item2), 1])\
        .reduceByKey(lambda a, b: a+ b)
    item_user_nums = item_item_nums.map(lambda ((item1, item2),co_nums): [item1, int(co_nums)])\
        .reduceByKey(lambda a, b: a + b)
    item1_nums = item_item_nums.map(lambda ((item1, item2), co_nums): [item1, (item2, co_nums)]).join(item_user_nums)
    item2_nums = item1_nums.map(lambda (item1, ((item2, co_nums), nums_item1)):
                                [item2, (item1, co_nums, nums_item1)]).join(item_user_nums)
    item2item_simil = item2_nums.map(cosine_simil).filter(lambda (item1, (item2, simil)): simil > 0)
    return item2item_simil

def cosine_simil(item_nums):
    """计算cosine相似度
    Args:
        [item2,((item1,item1_item2_nums,item1_nums),item2_nums)]:分别是item2_id,item1_id,
            item1_id与item2_id的共同点击量，item1_id点击量，item2_id点击量
    returns:
        [item1,(item2,simil)]:分别为item1_id,item2_id,item1_id与item2_id的cosine相似度
    """
    item2, ((item1, item1_item2_nums, item1_nums), item2_nums) = item_nums
    if item1==item2 or item1_item2_nums < 3:
        simil = 0
    else:
        simil = item1_item2_nums * 1.0 /math.sqrt(item1_nums * item2_nums)
        if simil <SIMIL_FILTER:
            simil=0
    return [item1, (item2, WEIGHTS*simil)]

def check_bool(flags):
    if flags in ['False','F','false','f', False]:
        return False
    elif flags in ['True', 'T', 'true', 't', True]:
        return True


if __name__ == "__main__":
    main()




