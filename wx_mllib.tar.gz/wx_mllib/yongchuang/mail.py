#!/usr/bin/env python
#encoding=utf-8
# -*- coding: utf-8 -*- 
"""
@author: caoyongchuang@didichuxing.com
@file: mail.py.py
@time: 2017/6/27 下午9:02
"""
import smtplib
import sys
from email.mime.text import MIMEText

mailto_list = ["caoyc@tangdou.com"]
mail_host = "smtp.exmail.qq.com"  # 设置服务器
mail_user = "caoyc"  # 用户名
mail_pass = "cyc__RUC1"  # 口令
mail_postfix = "tangdou.com"  # 发件箱的后缀


def send_mail(to_list, sub, content):
    me = "recy" + "<" + mail_user + "@" + mail_postfix + ">"
    msg = MIMEText(content, _subtype='plain', _charset='gb2312')
    msg['Subject'] = sub
    msg['From'] = me
    msg['To'] = ";".join(to_list)
    try:
        server = smtplib.SMTP()
        server.connect(mail_host)
        user = mail_user + "@" + mail_postfix
        server.login(user, mail_pass)
        server.sendmail(me, to_list, msg.as_string())
        server.close()
        return True
    except Exception, e:
        print str(e)
        return False


if __name__ == '__main__':
    send_mail(mailto_list, "推荐-" + sys.argv[1] + ' ' + sys.argv[2], sys.argv[1])
