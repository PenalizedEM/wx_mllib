#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""加大用户的个性化推荐列表
@Time    : '2018/5/17 下午5:37'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'add_personality.py'
"""
import zlib
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from pyspark.sql.types import LongType
from pyspark.sql.functions import udf
from pyspark.sql.types import DoubleType
import hadoop

Flow =[20, 39]

PEASONAL_DIR = "hdfs://Ucluster/olap/da/personal_add/"

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_day = (datetime.datetime.today()- datetime.timedelta(7)).strftime("%Y-%m-%d")
    del_oldhdfs(PEASONAL_DIR, model_day)
    del_oldhdfs(PEASONAL_DIR, del_day)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('cf_personality:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sql ="SELECT diu, vid, rn, modelid FROM ( SELECT r.diu, r.vid, r.pp, ROW_NUMBER() over (partition BY \
    r.diu ORDER BY r.pp DESC)rn, r.modelid FROM ( SELECT p.* FROM \
    (SELECT * FROM da.recy_ltr_predict where dt='%s' )p JOIN (SELECT vid, createtime FROM dw.video \
    WHERE TYPE NOT IN ('10', '12'))q ON (p.vid = q.vid))r WHERE dt='%s')a where a.pp>=0.5 or \
    (a.rn <= 70 and a.pp >=0.43) order by diu, rn desc" %(model_day, model_day)
    diu_personal = spark.sql(sql)
    #sql ="SELECT diu, vid FROM ( SELECT r.diu, r.vid, r.pp, ROW_NUMBER() over (partition BY \
    #r.diu ORDER BY r.pp DESC)rn, r.modelid FROM ( SELECT p.* FROM \
    #(SELECT * FROM da.recy_ltr_predict where dt='%s' )p JOIN (SELECT vid, createtime FROM dw.video \
    #WHERE TYPE NOT IN ('10', '12'))q ON (p.vid = q.vid))r WHERE dt='%s')a where a.pp>=0.5 " %(model_day, model_day)
    #diu_personal = spark.sql(sql)
    #diu_old = spark.sql(sql)
    #diu_old = diu_old.withColumnRenamed('vid','tag')
    #diu_filter = diu_personal.join(diu_old,on='diu',how='left_outer')\
    #    .drop(diu_old['diu'])
    #diu_add = diu_filter.filter(diu_filter['tag'].isNull())
    cols = ['diu', 'vid', 'rn', 'modelid']
    diu_personal.show()
    diu_personal.rdd.map(lambda x: [ x[col] for col in cols]).map(get_ab)\
        .filter(lambda x: x[4]>=Flow[0] and x[4] < Flow[1])\
        .map(lambda x: ",".join(map(str, x[:2]))).repartition(1)\
        .saveAsTextFile(PEASONAL_DIR + model_day)


def get_ab(line):
    diu, vid, rn, modelid =line
    crc = zlib.crc32(diu) & 0xffffffff
    ab_tag = crc %100
    return [diu, vid, rn, modelid, ab_tag]

def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)


if __name__ == "__main__":
    main()

