#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/5/22 下午4:24'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'cal_healthy.py.py'
"""
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession

def main():
    model_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    conf = SparkConf().setAppName("vido")
    spark = SparkSession.builder.master('yarn-client').appName('get_hot_video:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sql = "select b.d_vid, a.click, b.expose from (SELECT d_vid, count(1) expose FROM adm.f_new_video_dv \
          WHERE dt >= '2018-05-21' AND d_abtag>=20 and d_abtag<=39 and\
          d_module IN('舞友广场','为你推荐') and d_modelid='209' group by d_vid )b left outer join \
           (SELECT d_vid, count(1) click FROM adm.f_new_video_vv \
          WHERE dt >= '2018-05-21' AND d_abtag>=20 and d_abtag<=39 and\
          d_module IN('舞友广场','为你推荐') and d_modelid='209' group by d_vid)a on (a.d_vid=b.d_vid)"
    video_click_expose = spark.sql(sql).fillna(0).rdd.map(lambda x: [x['d_vid'], x['click'], x['expose']])\
        .map(test_online).collect()
    vids = load_health()
    print "video nums is %d " %(len(video_click_expose))
    all_healty = check_all(vids, video_click_expose)
    sc.parallelize(all_healty).map(lambda x: "\t".join(map(str, x)))\
        .saveAsTextFile("/user/yongchuang/healthy")

def check_all(vids, video_action):
    action_vids = map(lambda x: x[0], video_action)
    all = []
    for vid, click, expose, ctr, offline in video_action:
        if str(int(float(vid))) in vids:
            all.append([vid, click, expose, ctr, offline])
    return all



def test_online(line):
    vid, click, expose = line
    stats =  is_offline(click, expose)
    offline = -1 if stats else 1
    ctr =0
    if expose >0:
        ctr = click*1.0/expose
    return [vid, click, expose, ctr, offline]


def is_offline(click, expose):
    ctr = 0
    err_ctr  = 0
    if expose > 0:
        ctr = click * 1.0 / expose
    if ctr > 1:
        err_ctr += 1
    if expose > 200 and ctr < 0.015:
        return True
    elif expose > 1000 and ctr < 0.02:
        True
    elif expose > 5000 and ctr < 0.025:
        True
    elif expose > 10000 and ctr < 0.03:
        True
    elif expose > 50000 and ctr < 0.035:
        True
    elif expose > 100000 and ctr < 0.038:
        True
    elif expose > 200000 and ctr < 0.04:
        return True
    return False

def load_health():
    vids=[]
    with open("health_all") as f:
        for line in f:
            vid = line.strip()
            if vid not in vids:
                vids.append(vid)
    return vids


if __name__ =="__main__":
    main()
