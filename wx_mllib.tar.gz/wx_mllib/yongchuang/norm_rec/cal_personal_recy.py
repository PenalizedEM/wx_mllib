#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""统计个性化推荐个人的推荐结果
@Time    : '2018/5/17 下午4:16'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'cal_personal_recy.py'
"""
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today()- datetime.timedelta(15)).strftime("%Y-%m-%d")
    conf = SparkConf().setAppName("vido")
    spark = SparkSession.builder.master('yarn-client').appName('get_hot_video:'+ model_day)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sql = "select a.nums, count(1) freq from ( select diu, count(1) nums from  \
          da.recy_final_out_topk_redis_normal where dt='2018-05-16' group by diu) a group by a.nums"
    diu_rec_nums = spark.sql(sql)
    diu_rec_nums.rdd.map(lambda x: "\t".join(map(str, [x['nums'], x['freq']])))\
        .repartition(1).saveAsTextFile("/user/yongchuang/personal_recnums")

def get_personal_nums():
    model_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.master('yarn-client').appName('get_hot_video:'+ model_day)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    def parse_line(line):
        segment = line.strip().split(",")
        if len(segment)!=2:
            return None
        diu, vid = segment
        return [diu, 1]
    sc = spark.sparkContext
    dir ='hdfs://Ucluster/olap/da/personal_add/2018-05-16'
    personal_data = sc.textFile(dir).map(parse_line).filter(lambda x: x is None)
    personal_data.reduceByKey(lambda a,b : a+b)\
        .map(lambda x: [x[1], 1]).reduceByKey(lambda a,b : a+b)\
        .map(lambda x: "\t".join(map(str, x))).saveAsTextFile("/user/yongchuang/personal_newnum")


if __name__ == "__main__":
    get_personal_nums()

