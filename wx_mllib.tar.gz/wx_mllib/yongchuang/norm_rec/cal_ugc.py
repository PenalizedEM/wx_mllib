#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/12/8 下午7:45'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'cal_zero.py.py'
"""
import datetime
from pyspark.sql import SQLContext
from pyspark.sql.types import DoubleType
from pyspark.sql.types import LongType
from pyspark.sql.functions import udf
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import math
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder
import sys

ugc_numeric = ['total_cnt','oneday_cnt','sevenday_cnt','thirtyday_cnt',\
               #'sum_ufav','max_ufav','mean_ufav',\
               #'oneday_sum_ufav','oneday_max_ufav','oneday_mean_ufav','sevenday_sum_ufav','sevenday_max_ufav',\
               #'sevenday_mean_ufav','thirtyday_sum_ufav','thirtyday_max_ufav','thirtyday_mean_ufav',\
               'sum_ugood', 'max_ugood','mean_ugood','oneday_sum_ugood','oneday_max_ugood','oneday_mean_ugood','sevenday_sum_ugood',\
               'sevenday_max_ugood','sevenday_mean_ugood','thirtyday_sum_ugood','thirtyday_max_ugood','thirtyday_mean_ugood',\
               'sum_ucmt','max_ucmt','mean_ucmt','oneday_sum_ucmt','oneday_max_ucmt','oneday_mean_ucmt','sevenday_sum_ucmt',\
               'sevenday_max_ucmt','sevenday_mean_ucmt','thirtyday_sum_ucmt','thirtyday_max_ucmt','thirtyday_mean_ucmt',\
               'sum_ushare','max_ushare','mean_ushare','oneday_sum_ushare','oneday_max_ushare','oneday_mean_ushare',\
               'sevenday_sum_ushare','sevenday_max_ushare','sevenday_mean_ushare','thirtyday_sum_ushare','thirtyday_max_ushare',\
               'thirtyday_mean_ushare','sum_pt','max_pt','mean_pt','oneday_sum_pt','oneday_max_pt','oneday_mean_pt',\
               'sevenday_sum_pt','sevenday_max_pt','sevenday_mean_pt','thirtyday_sum_pt','thirtyday_max_pt','thirtyday_mean_pt',\
               'sum_uv','max_uv','mean_uv','oneday_sum_uv','oneday_max_uv','oneday_mean_uv','sevenday_sum_uv',\
               'sevenday_max_uv','sevenday_mean_uv','thirtyday_sum_uv','thirtyday_max_uv','thirtyday_mean_uv','sum_udv',\
               'max_udv','mean_udv','oneday_sum_udv','oneday_max_udv','oneday_mean_udv','sevenday_sum_udv','sevenday_max_udv',\
               'sevenday_mean_udv','thirtyday_sum_udv','thirtyday_max_udv','thirtyday_mean_udv','mean_ctr','max_ctr',\
               'oneday_max_ctr','oneday_mean_ctr','sevenday_max_ctr','sevenday_mean_ctr','thirtyday_max_ctr','thirtyday_mean_ctr']


def main():
    if len(sys.argv) == 1:
        inDate = (datetime.datetime.today() -datetime.timedelta(1)).strftime("%Y-%m-%d")
    elif len(sys.argv) > 1:
        inDate= sys.argv[1]
    spark = SparkSession.builder.master('yarn-client') \
        .appName('features_transform:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    ugc_sql = "select uid, %s from da.kol_score_uid_raw_feature where dt='%s' and type not in (10, 12) " % (",".join(ugc_numeric), inDate)
    ugc_features = spark.sql(ugc_sql)
    total = ugc_features.rdd.count()
    features_zero_num = [ugc_features.select(['uid', col]).filter(ugc_features[col]==0).count() for col in ugc_numeric]
    for index in range(len(ugc_numeric)):
        print ugc_numeric[index], features_zero_num[index], features_zero_num[index]*1.0/total


if __name__ == "__main__":
    main()


