#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/12/8 下午7:45'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'cal_zero.py.py'
"""
import datetime
from pyspark.sql import SQLContext
from pyspark.sql.types import DoubleType
from pyspark.sql.types import LongType
from pyspark.sql.functions import udf
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import math
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder
import sys

def main():
    if len(sys.argv) == 1:
        inDate = (datetime.datetime.today() -datetime.timedelta(1)).strftime("%Y-%m-%d")
    elif len(sys.argv) > 1:
        inDate= sys.argv[1]
    spark = SparkSession.builder.master('yarn-client') \
        .appName('features_transform:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sql = "select * from da.wx_cont_itfeature where dt='2018-07-22' and type not in (10, 12)"
    #sql = "select * from da.wx_userprofie_feature where dt='2018-07-18'"
    it_feat = spark.sql(sql)
    cols = it_feat.columns
    nums = it_feat.rdd.count()
    features_zero_num = [it_feat.select(['uid', col]).filter(it_feat[col]==0).count() for col in cols]
    for index in range(len(cols)):
        print cols[index], features_zero_num[index], features_zero_num[index]*1.0/nums



if __name__ == "__main__":
    main()
