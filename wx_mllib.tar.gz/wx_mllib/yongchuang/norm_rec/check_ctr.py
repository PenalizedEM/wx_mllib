#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/5/20 下午3:56'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'check_ctr.py.py'
"""

import redis_memorycache as rmu
import load_quality_talent_tag as lqt
import datetime
import hadoop
import os


REDIS_HOST="10.19.78.74"
REDIS_PORT="6379"
# 优质大v推荐
QUERYFILE= "quality_data"
# 新用户运营
QUALITY_NEWUSER = "quality_user"
# 优质内容推荐
QUALITYFILE = "talent_data"
# 新热数据
HOT_COLDSTART_DIR = "hdfs://Ucluster/olap/da/hot_coldstart/"
HOTFILE = "hot_data"
#历史热门数据
HISTORY_COLDSTART_DIR = "hdfs://Ucluster/olap/da/hot_histroy/"
HISTORYFILE = "history_hot_data"


def main():
    # 优质大V数据
    FilterCtrSave(QUERYFILE)
    loadquery2redis()
    # 新用户运营数据过滤
    FilterCtrSave(QUALITY_NEWUSER)
    loadnewuserdefine2redis()
    # 优质内容
    FilterCtrSave(QUALITYFILE)
    loadquality2redis()
    # 过滤新热数据
    if check_local_files(HOTFILE, HOT_COLDSTART_DIR):
        FilterCtrSave(HOTFILE)
        loadcoldstart(HOTFILE, 'r_hot_coldstart')
    # 过滤历史热门数据
    if check_local_files(HISTORYFILE, HISTORY_COLDSTART_DIR):
        FilterCtrSave(HISTORYFILE)
        loadcoldstart(HISTORYFILE, 'r_history_hot')



def check_local_files(file, hdfs_dir):
    if os.path.exists(file):
        return True
    start_day = datetime.datetime.today()-datetime.timedelta(1)
    end_day = datetime.datetime.today() - datetime.timedelta(15)
    while start_day >= end_day:
        model_day = start_day.strftime("%Y-%m-%d")
        dir = hdfs_dir + model_day + "/_SUCCESS"
        if hadoop.is_file_exist(dir) == 0:
            hadoop.getmerge(hdfs_dir + model_day, file)
            return True
        start_day = start_day - datetime.timedelta(1)
    return False

def FilterCtrSave(ReadFile):
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    vids = get_candi_vid(ReadFile)
    if len(vids)==0:
        print "data missing"
        exit(1)
    print "%s candi data is %d" %(ReadFile, len(vids))
    filter_vids = get_filter_vids(r, vids)
    print "%s filter data is %d" % (ReadFile, len(filter_vids))
    save_filter_vids(filter_vids, ReadFile)

def get_candi_vid(ReadFile):
    vids = []
    with open(ReadFile) as f:
        for line in f:
            vid=line.strip().split(",")[0]
            vids.append(vid)
    return vids

def loadcoldstart(file, key_redis):
    REDIS_HOST = "10.19.159.154"
    REDIS_PORT = "6379"
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    quality_data = loadFile(file, key_redis)
    rmu.loaddata2redis(r, quality_data, key_redis=key_redis)


def loadquery2redis():
    REDIS_HOST = "10.19.159.154"
    REDIS_PORT = "6379"
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    tag='query'
    key_redis="r_query_vids"
    quality_data = loadFile(QUERYFILE, key_redis)
    rmu.loaddata2redis(r, quality_data, tag)

def loadnewuserdefine2redis():
    REDIS_HOST = "10.19.112.202"
    REDIS_PORT = "6379"
    KEY_PREFIX = 'r_user_define'
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    quality_data = loadFile(QUALITY_NEWUSER, KEY_PREFIX)
    rmu.loaddata2redis(r,quality_data ,tag=KEY_PREFIX, key_redis=KEY_PREFIX)


def loadquality2redis():
    REDIS_HOST = "10.19.159.154"
    REDIS_PORT = "6379"
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    tag='talent'
    key_redis="r_quality_vids"
    quality_data = loadFile(QUALITYFILE, key_redis)
    rmu.loaddata2redis(r, quality_data, tag)

def loadFile(ReadFile, key_redis):
    vids = []
    quality_data = []
    with open(ReadFile, "r") as f:
        for line in f:
            vid = line.strip().split(",", 1)[0]
            if vid not in vids:
                vids.append(vid)
                quality_data.append((key_redis, line.strip()))
    return quality_data


def check_file_ctr():
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    g=open("healty_ctr", "w")
    with open("zuopang.ctr") as f:
        for line in f:
            vid = line.strip()
            expose_dict = r.hgetall("CTR_sliding_E_" + vid)
            click_dict = r.hgetall("CTR_sliding_C_" + vid)
            expose = get_value(expose_dict)
            click = get_value(click_dict)
            ctr =0
            if expose >0:
                ctr = click*1.0/expose
            g.write(",".join(map(str, [vid, expose, click, ctr]))+"\n")


def save_filter_vids(fiter_vids, saveFile):
    data=[]
    with open(saveFile) as f:
        for line in f:
            vid=line.strip().split(",", 1)[0]
            if vid not in fiter_vids:
                data.append(line.strip())
    with open(saveFile, "w") as g:
        for line in data:
            g.write(line+"\n")
    print "%s save data is %d" %(saveFile, len(data))


def get_filter_vids(r, vids):
    filter_vids = []
    err_ctr =0
    for vid in vids:
        expose_dict = r.hgetall("CTR_sliding_E_"+vid)
        click_dict = r.hgetall("CTR_sliding_C_" + vid)
        expose = get_value(expose_dict)
        click = get_value(click_dict)
        ctr = 0
        if expose >0:
            ctr = click*1.0/expose
        if ctr >1:
             err_ctr +=1
             if err_ctr >1.1 and expose>100:
                 filter_vids.append(vid)
        #print "vid is :%s, expose is :%d, click is :%d, ctr is %.4f" %(vid, expose,click, ctr)
        if expose > 200 and ctr <0.015:
            filter_vids.append(vid)
        elif expose > 1000 and ctr <0.02:
            filter_vids.append(vid)
        elif expose > 5000 and ctr <0.025:
            filter_vids.append(vid)
        elif expose > 10000 and ctr < 0.03:
            filter_vids.append(vid)
        elif expose > 50000 and ctr < 0.035:
            filter_vids.append(vid)
        elif expose > 100000 and ctr < 0.038:
            filter_vids.append(vid)
        elif expose > 200000 and ctr < 0.04:
            filter_vids.append(vid)
    #print "error vid is %d" %err_ctr
    return filter_vids


def get_value(ctr):
    value = 0
    if ctr is not None and len(ctr) >0 :
        for k, v in ctr.iteritems():
            value += float(v)
    return value




if __name__ =="__main__":
    main()
    #check_file_ctr()




