#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/5/20 下午5:23'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'check_healty.py.py'
"""

def main():
    raw_healty = loadFile("raw_health")
    vids_candi = loadFile("quality_data")
    if len(vids_candi) >0:
        healty_data = vids_candi & raw_healty
        print "healty_data is %d" %len(healty_data)
        for i in healty_data:
	    print i


def loadFile(file):
    vids =[]
    with open(file) as f:
        for line in f:
            vid = line.strip().split(",")[0]
            vids.append(vid)
    return set(vids)


if __name__ == "__main__":
    main()
