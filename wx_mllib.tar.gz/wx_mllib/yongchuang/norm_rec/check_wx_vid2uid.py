# -*- coding: utf-8 -*-
"""
@Time    : '2018/8/14 下午3:32'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'check_wx_vid2uid.py.py'
"""
import os
import db
import hadoop
MYSQL_HOST = "10.10.115.174"
MYSQL_USER="weixin"
MYSQL_PWD = 'tangdouapp#123'

def recommend2hdfs(cate="gcw"):
    """加载广场舞数据到hdfs
    """
    db.init(host=MYSQL_HOST, user=MYSQL_USER, passwd=MYSQL_PWD, db='offline', database='lite_weixin')
    if cate=="gcw":
        sql = "SELECT vid, type FROM home_recommend where type=1 order by uptime desc"
        recommend_hdfs = "/olap/da/gcw_rec/"
    elif cate=="life":
        sql = "select vid, type FROM home_recommend where type in (2,3,4,5,6,10,11) order by uptime desc"
        recommend_hdfs = "/olap/da/life_rec/"
    vids = db.query(sql)
    file = "recommed"
    i =0
    with open("./" + file, "w") as f:
        for vid, uptime in vids:
            i +=1
            f.write("\t".join(map(str, [vid, uptime])) + "\n")
    if hadoop.is_file_exist(recommend_hdfs + file) ==0:
        hadoop.rm_dir(recommend_hdfs+file)
    print "job %s nums is %d" %(cate, i)
    hadoop.put(file, recommend_hdfs)
    os.system("rm -fr %s" %file)

if __name__ == "__main__":
    recommend2hdfs()
