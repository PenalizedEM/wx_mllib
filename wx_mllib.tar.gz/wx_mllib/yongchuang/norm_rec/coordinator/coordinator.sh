#!/bin/sh

#source /etc/profile
export PATH=${PATH}
HADOOP_HOME=/home/hadoop/hadoop-2.6.0
########################################
########################################

date=`date +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
datebuf=$1

if [ -z "$1" ] ;then
date=`date -d "1 days ago" +"%Y-%m-%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
exit 0
fi
fi

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf



########################################
echo "`date` [INFO] ----------- 1��distcp video to weixin  to cluster begin ---------"
########################################
{
${HADOOP_HOME}/bin/hadoop distcp -overwrite hdfs://10.10.186.203:8020/olap/db/video hdfs://10.42.55.58:8020/olap/da/video
} >> ../log/distcp_video_${datebuf}.log 2>&1



########################################
echo "`date` [INFO] ----------- 2��distcp icf similarity topn to weixin cluster begin ---------"
########################################
{
${HADOOP_HOME}/bin/hadoop distcp -overwrite hdfs://10.10.186.203:8020/Ucluster/user/hive/warehouse/da.db/recy_icf_similarity_topn_b hdfs://10.42.55.58:8020/olap/da/recy_icf_similarity_topn_b
} >> ../log/distcp_recy_icf_similarity_topn_b_${datebuf}.log 2>&1


########################################
echo "`date` [INFO] ----------- 3��distcp wx recy uvm to weixin cluster begin ---------"
########################################
{
${HADOOP_HOME}/bin/hadoop distcp -overwrite hdfs://10.10.186.203:8020/olap/da/wx_recy_uvm/dt=${datebuf} hdfs://10.42.55.58:8020/olap/da/wx_recy_uvm/dt=${datebuf}
} >> ../log/distcp_wx_recy_uvm_${datebuf}.log 2>&1


########################################
echo "`date` [INFO] ----------- 4��distcp wx f_wx_video_dv cluster begin ---------"
########################################
{
${HADOOP_HOME}/bin/hadoop distcp -overwrite hdfs://10.10.186.203:8020/Ucluster/dw/adm/f_wx_video_dv/dt=${datebuf} hdfs://10.42.55.58:8020/olap/da/f_wx_video_dv/dt=${datebuf}
} >> ../log/distcp_f_wx_video_dv_${datebuf}.log 2>&1


########################################
echo "`date` [INFO] ----------- 5��distcp wx f_wx_video_click cluster begin ---------"
########################################
{
${HADOOP_HOME}/bin/hadoop distcp -overwrite hdfs://10.10.186.203:8020/Ucluster/dw/adm/f_wx_video_click/dt=${datebuf} hdfs://10.42.55.58:8020/olap/da/f_wx_video_click/dt=${datebuf}
} >> ../log/distcp_f_wx_video_dv_${datebuf}.log 2>&1
