#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/5/18 下午9:04'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'filter_user.py.py'
"""

import zlib
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession

Flow =[30, 39]

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.master('yarn-client') \
        .appName('cf_personality:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    cols =['diu_1', 'diu_2', 'num_1', 'num_2', 'num_12', 'similarity']
    sql ="select %s from da.recy_ucf_similarity_topn_mid " %",".join(cols)
    diu2diu = spark.sql(sql).rdd.map(lambda x: [x[col] for col in cols])\
        .map(get_ab).filter(lambda x: x is not None)
    diu2diu=diu2diu.map(lambda x: Row(diu_1=x[0], diu_2=x[1], num_1=x[2], num_2= x[3], num_12=x[4], similarity=x[5]))
    diu2diu_filter = spark.createDataFrame(diu2diu)
    diu2diu_filter.createOrReplaceTempView("diu2diu")
    sql = "drop table if exists da.recy_ucf_similarity_topn_mid_filter"
    spark.sql(sql)
    sql ="create table da.recy_ucf_similarity_topn_mid_filter as select %s from diu2diu" %",".join(cols)
    print sql
    spark.sql(sql)
    spark.stop()


def get_ab(line):
    diu_1, diu_2, num_1, num_2, num_12, similarity =line
    crc = zlib.crc32(diu_1) & 0xffffffff
    ab_tag = crc %100
    if ab_tag >=Flow[0] and ab_tag <=Flow[1]:
        return [diu_1, diu_2, num_1, num_2, num_12, similarity]
    else:
        return None

if __name__ == "__main__":
    main()

