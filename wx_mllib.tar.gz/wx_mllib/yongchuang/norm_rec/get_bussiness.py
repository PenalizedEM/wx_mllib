#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""给运营对外提供的数据，秀舞优质数据
@Time    : '2018/4/24 下午8:54'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_business.py'
"""
import datetime
import hadoop
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession

BUSSINESS_DIR= "hdfs://Ucluster/olap/da/business/"
VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_it_score/"


def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today() - datetime.timedelta(20)).strftime("%Y-%m-%d")
    model_date = (datetime.datetime.today() - datetime.timedelta(15)).strftime("%Y-%m-%d")
    del_oldhdfs(BUSSINESS_DIR, delDate)
    del_oldhdfs(BUSSINESS_DIR, inDate)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('get_business:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    # 获取非独家达人数据
    uidlist = filter_daren(spark)
    # 获取候选集
    candi_video = get_candi_video(spark, model_date)
    # 获取得分数据
    vid_scores = load_video_score(spark)
    if vid_scores is None:
        print "score data lose"
        exit(1)
    # 过滤达人数据
    candi_video_score = candi_video.join(uidlist, candi_video['uid']==uidlist['userid'], how='left_outer')
    candi_video_score2=candi_video_score.filter(candi_video_score['userid'].isNull()).drop(candi_video_score['userid'])\
        .join(vid_scores, candi_video_score['vid']==vid_scores['vid'], how='inner')\
        .drop(vid_scores['vid'])
    # 获取历史数据
    history_day = get_history_day()
    bussiness_history = load_bussiness_history(spark, history_day)
    fitler_score = filter_candi_score(spark, candi_video_score2, bussiness_history)
    fitler_score.createOrReplaceTempView("bussiness")
    sql = "select vid, score from bussiness order by score desc limit 1000"
    top_socore = spark.sql(sql)
    print "final video nums %d" %top_socore.count()
    top_socore.rdd.map(lambda x: [x['vid'], x['score']])\
        .repartition(1)\
        .map(lambda x: ",".join(map(str, x)))\
        .saveAsTextFile(BUSSINESS_DIR + inDate)
    spark.stop()

def filter_candi_score(spark, video_candi_score, history_talent):
    """过滤候选视频
    """
    if history_talent is None:
        return video_candi_score
    else:
        history_rdd = spark.createDataFrame(history_talent.map(lambda x: Row(vid=x[0], tag=x[1])))
        candi_filter = video_candi_score.join(history_rdd, on='vid', how='left_outer')\
            .drop(history_rdd['vid'])
        return candi_filter.filter(candi_filter['tag'].isNull())

def get_history_day():
    inDate = datetime.datetime.today() - datetime.timedelta(1)
    i =1
    model_day=[]
    while i < 16:
        inDate = inDate - datetime.timedelta(1)
        model_day.append(inDate.strftime("%Y-%m-%d"))
        i +=1
    return model_day

def load_bussiness_history(spark, model_day):
    history_data = []
    sc = spark.sparkContext
    for day in model_day:
        data =load_bussiness_day(spark, day)
        if data is not None:
            history_data.append(data)
    if len(history_data) >0:
        return sc.union(history_data)
    else:
        return None


def load_bussiness_day(spark, day):
    def parse_bussiness(line):
        segment = line.encode("utf-8").strip().split(",")
        if len(segment)!=2:
            return None
        else:
            vid, score = segment
            return [vid, score]
    dir = BUSSINESS_DIR + day
    sc = spark.sparkContext
    if hadoop.is_file_exist(dir+"_SUCCESS")==0:
        return sc.textFile(dir).map(parse_bussiness).filter(lambda x: x is not None)
    else:
        return None


def filter_daren(spark):
    """获取推广uidlist,独家或者官方
    """
    sc = spark.sparkContext
    sql = "select userid from dw.playlist where level>4 or level=1"
    uidlist = spark.sql(sql)
    uidadd = [[834259], [206694]]
    uid_rdd = spark.createDataFrame(sc.parallelize(uidadd)\
                                   .map(lambda x: Row(userid=x[0])))
    return uidlist.union(uid_rdd)


def get_candi_video(spark, dt):
    sql ="select vid,uid \
    FROM dw.video where duration<300 and parent_category<45 and (hits_total>=150 and type=8)\
    and to_date(createtime)>'%s' " %dt
    return spark.sql(sql)

def load_video_score(spark):
    inDate = datetime.datetime.today() - datetime.timedelta(1)
    i=0
    while i < 15:
        dir = VIDEO_SCORE_DIR + inDate.strftime("%Y-%m-%d")
        if hadoop.is_file_exist(dir+"/_SUCCESS") == 0:
            return spark.read.load(dir).select(['vid', 'score'])
        else:
            i+=1
            inDate = inDate - datetime.timedelta(1)
    return None

def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)


if __name__ =="__main__":
    main()

