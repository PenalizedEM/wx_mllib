#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取历史的热门视频
@Time    : '2018/5/11 下午4:21'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_history_hot.py'
"""

from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
import datetime
import pyspark.sql.functions as F
import hadoop

VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_it_score/"
HISTORY_COLDSTART_DIR = "hdfs://Ucluster/olap/da/hot_histroy/"
QUALITY_DIR = "hdfs://Ucluster/olap/da/quality_talent/"
QUALITY_TAG_DIR = "hdfs://Ucluster/olap/da/quality_query/"
TOPN=400
MODEL_ID='207'

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today()- datetime.timedelta(15)).strftime("%Y-%m-%d")
    del_oldhdfs(HISTORY_COLDSTART_DIR, delDate)
    del_oldhdfs(HISTORY_COLDSTART_DIR, model_day)
    conf = SparkConf().setAppName("vido")
    spark = SparkSession.builder.master('yarn-client').appName('get_history_hot_video:'+ model_day)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    candi_video = load_candi_video(spark)
    #过滤历史数据
    history_days = get_history_day(14)
    history_data = load_history(spark, history_days, HISTORY_COLDSTART_DIR)
    video_history_filter = filter_candi_score(spark, candi_video, history_data)
    video_filter= filter_quality(spark, video_history_filter)
    vido_score = load_video_score(spark)
    filter_video_score = video_filter.join(vido_score, video_filter['vid'] == vido_score['vid'], how='inner') \
        .drop(vido_score['vid'])
    video_score_final = filter_video_score.rdd.map(lambda x: [x['vid'], x['score']]).collect()
    sorted_video_score = sorted(video_score_final, key=lambda x: x[1], reverse=True)[:TOPN]
    video_save = [[vid, score, index, MODEL_ID] for index, (vid, score) in enumerate(sorted_video_score)]
    sc.parallelize(video_save, 1).map(lambda x: ",".join(map(str, x))) \
        .saveAsTextFile(HISTORY_COLDSTART_DIR + model_day)



def load_candi_video(spark):
    """加载大视频
    """
    start_day = (datetime.datetime.today() - datetime.timedelta(14)).strftime("%Y-%m-%d")
    end_day = (datetime.datetime.today() - datetime.timedelta(45)).strftime("%Y-%m-%d")
    sql = "select vid, duration from dw.video where type not in (10,12) and status =0 and uid >0 \
    and sync=0 and to_date(createtime) >='%s' and to_date(createtime) <='%s'" %(end_day, start_day)
    return spark.sql(sql)

def filter_quality(spark, video_candi):
    """过滤当天优质内容，优质大v数据
    """
    model_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
    model_day = [model_day]
    talent_history = load_history(spark,model_day,QUALITY_DIR)
    query_history = load_history(spark,model_day,QUALITY_TAG_DIR)
    history = talent_history
    if talent_history is None:
        history = query_history
    elif query_history is not None:
        history=talent_history.union(query_history)
    if history is None:
        return video_candi
    else:
        return filter_candi_score(spark, video_candi, history)


def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)


def load_history(spark, history_days, hdfs_dir):
    sc = spark.sparkContext
    history_data = []
    for day in history_days:
        dir = hdfs_dir + day
        if hadoop.is_dir_exist(dir) ==0:
            rdd = sc.textFile(hdfs_dir + day).map(parse_history).filter(lambda x: x is not None)
            history_data.append(rdd)
    if len(history_data) > 0 :
        rdd= sc.union(history_data)
        if rdd.count() >0:
            return rdd
    return None

def parse_history(line):
    segment = line.encode("utf-8").strip().split(",")
    if len(segment) < 4:
        return None
    else:
        [vid, simil, rank, model_id] = segment[:4]
        return [vid, -1]

def filter_candi_score(spark, video_candi_score, history_talent):
    """过滤候选视频
    """
    if history_talent is None:
        return video_candi_score
    else:
        history_rdd = spark.createDataFrame(history_talent.map(lambda x: Row(vid=x[0], tag=x[1])))
        candi_filter = video_candi_score.join(history_rdd, on='vid', how='left_outer')\
            .drop(history_rdd['vid'])
        return candi_filter.filter(candi_filter['tag'].isNull()).drop(candi_filter['tag'])

def load_video_score(spark):
    inDate = datetime.datetime.today() - datetime.timedelta(1)
    i=0
    while i < 15:
        dir = VIDEO_SCORE_DIR + inDate.strftime("%Y-%m-%d")
        if hadoop.is_file_exist(dir+"/_SUCCESS") == 0:
            return spark.read.load(dir).select(['vid', 'score'])
        else:
            i+=1
            inDate = inDate - datetime.timedelta(1)
    return None

def get_history_day(day_nums=7):
    dt =0
    mode_days  = []
    start_day = datetime.datetime.today() - datetime.timedelta(4)
    while dt < day_nums:
        start_day = start_day - datetime.timedelta(1)
        mode_days.append(start_day.strftime("%Y-%m-%d"))
        dt +=1
    return mode_days

if __name__ == "__main__":
    main()
