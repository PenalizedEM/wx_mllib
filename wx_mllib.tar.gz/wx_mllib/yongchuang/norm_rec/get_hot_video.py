#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取热门视频
@Time    : '2018/5/10 下午1:53'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_hot_video.py'
"""

from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
import datetime
import pyspark.sql.functions as F
VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_it_score/"
HOT_COLDSTART_DIR = "hdfs://Ucluster/olap/da/hot_coldstart/"
QUALITY_DIR = "hdfs://Ucluster/olap/da/quality_talent/"
QUALITY_TAG_DIR = "hdfs://Ucluster/olap/da/quality_query/"
import hadoop
import math
MODEL_ID ='206'
TOPN=200

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today()- datetime.timedelta(14)).strftime("%Y-%m-%d")
    del_oldhdfs(HOT_COLDSTART_DIR, delDate)
    del_oldhdfs(HOT_COLDSTART_DIR, model_day)
    conf = SparkConf().setAppName("vido")
    spark = SparkSession.builder.master('yarn-client').appName('get_hot_video:'+ model_day)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    candi_video = load_candi_video(spark)
    print 'candi video is %d' %candi_video.count()
    #过滤历史数据
    history_days = get_history_day(7)
    history_data = load_history(spark, history_days, HOT_COLDSTART_DIR)
    video_history_filter = filter_candi_score(spark, candi_video, history_data)
    print 'filter history video is %d' %video_history_filter.count()
    # 过滤当天的优质内容，大V数据
    video_filter= filter_quality(spark, video_history_filter)
    # sort
    vido_score = load_video_score(spark)
    video_pt = load_video_pt(spark)
    total_video_score = video_filter.join(vido_score, video_filter['vid']==vido_score['vid'] ,how='inner')\
        .drop(vido_score['vid']).join(video_pt, video_filter['vid']==video_pt['d_vid'], how='left_outer')\
        .fillna(0)
    print 'video scores is %d' %total_video_score.count()
    max_value = max(1, math.log(1+max_count))
    video_score_final = total_video_score.rdd\
        .map(lambda x: [x['vid'], x['score']*(1+0.5*math.log(1+x['good_score'])* 1.0/max_value)]).collect()
    sorted_video_score = sorted(video_score_final, key=lambda x: x[1], reverse=True)[:TOPN]
    video_save = [[vid, score, index, MODEL_ID] for index,(vid, score) in enumerate(sorted_video_score)]
    sc.parallelize(video_save, 1).map(lambda x: ",".join(map (str, x)))\
        .saveAsTextFile(HOT_COLDSTART_DIR + model_day)

def filter_quality(spark, video_candi):
    """过滤当天优质内容，优质大v数据
    """
    model_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
    model_day = [model_day]
    talent_history = load_history(spark, model_day, QUALITY_DIR)
    query_history = load_history(spark, model_day, QUALITY_TAG_DIR)
    history = talent_history
    if talent_history is None:
        history = query_history
    elif query_history is not None:
        history=talent_history.union(query_history)
    if history is None:
        return video_candi
    else:
        return filter_candi_score(spark, video_candi, history)
    


def load_video_score(spark):
    inDate = datetime.datetime.today() - datetime.timedelta(1)
    i=0
    while i < 15:
        dir = VIDEO_SCORE_DIR + inDate.strftime("%Y-%m-%d")
        if hadoop.is_file_exist(dir+"/_SUCCESS") == 0:
            return spark.read.load(dir).select(['vid', 'score'])
        else:
            i+=1
            inDate = inDate - datetime.timedelta(1)
    return None

def load_video_pt(spark):
    end_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
    start_day = (datetime.datetime.today()-datetime.timedelta(14)).strftime("%Y-%m-%d")
    sql = "select d_vid, count(1) good_score from adm.f_video_pt \
    where dt>='%s' and dt <='%s' and m_pp>=97 group by d_vid" %(start_day, end_day)
    video_good_nums = spark.sql(sql)
    global max_count
    max_count = video_good_nums.agg(F.max("good_score").alias("max")).rdd.map(lambda x: x['max']).collect()[0]
    print 'max_count is %d' %max_count
    return video_good_nums


def load_candi_video(spark):
    """加载大视频
    """
    start_day = (datetime.datetime.today() - datetime.timedelta(14)).strftime("%Y-%m-%d")
    sql = "select vid, duration from dw.video where type not in (10,12) and \
    status=0 and sync=0 and duration > 180 and uid >0 and to_date(createtime) >='%s'" %(start_day)
    return spark.sql(sql)


def get_history_day(day_nums=7):
    dt =0
    mode_days  = []
    start_day = datetime.datetime.today() - datetime.timedelta(1)
    while dt < day_nums:
        start_day = start_day - datetime.timedelta(1)
        mode_days.append(start_day.strftime("%Y-%m-%d"))
        dt +=1
    return mode_days


def load_history(spark, history_days, hdfs_dir):
    sc = spark.sparkContext
    history_data = []
    for day in history_days:
        dir = hdfs_dir + day
        if hadoop.is_dir_exist(dir) ==0:
            rdd = sc.textFile(hdfs_dir + day).map(parse_history).filter(lambda x: x is not None)
            history_data.append(rdd)
    if len(history_data) > 0 :
        rdd= sc.union(history_data)
        if rdd.count() >0:
            return rdd
    return None


def parse_history(line):
    segment = line.encode("utf-8").strip().split(",")
    if len(segment) < 4:
        return None
    else:
        [vid, simil, rank, model_id] = segment[:4]
        return [vid, -1]


def filter_candi_score(spark, video_candi_score, history_talent):
    """过滤候选视频
    """
    if history_talent is None:
        return video_candi_score
    else:
        history_rdd = spark.createDataFrame(history_talent.map(lambda x: Row(vid=x[0], ftag=x[1])))
        candi_filter = video_candi_score.join(history_rdd, on='vid', how='left_outer')\
            .drop(history_rdd['vid'])
        return candi_filter.filter(candi_filter['ftag'].isNull()).drop(candi_filter['ftag'])

def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)


if __name__ == '__main__':
    main()


