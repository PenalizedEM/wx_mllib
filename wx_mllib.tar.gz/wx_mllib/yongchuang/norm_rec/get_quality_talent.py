#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""将大v生产的数据，按照品类进行提取 导入redis中
@Time    : '2018/4/18 下午4:30'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'load_quality_talent.py'
"""

import datetime
from pyspark.sql import Row, SparkSession
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from collections import defaultdict
import hadoop

VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_it_score/"
QUALITY_DIR = "hdfs://Ucluster/olap/da/quality_talent/"

# 1:广场舞,2:双人舞,16:健身操,20:民族舞,21:拉丁舞,22:形体舞
CATE = [1,2,16,20,21,22]

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    model_date = (datetime.datetime.today() - datetime.timedelta(60)).strftime("%Y-%m-%d")
    del_oldhdfs(QUALITY_DIR, delDate)
    del_oldhdfs(QUALITY_DIR, inDate)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('get_quality_talent:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    video_score = load_video_score(spark, inDate)
    #video_score = load_video_score(spark, inDate)
    #video_candi = get_quality_file(spark, "quality_user")
    video_candi = get_quality_video(spark, model_date)
    video_candi_score = video_score.join(video_candi,on="vid",how="inner")\
        .drop(video_candi['vid'])
    print "candi1 is %d" %video_candi_score.count()
    history_days = get_history_day(1)
    history_talent = load_history_talent(spark, history_days)
    filter_candi = filter_candi_score(spark, video_candi_score, history_talent)
    print "candi2 is %d" %filter_candi.count()
    candi_cols = ['vid','score','parent_category', 'uid']
    filter_candi.rdd.map(lambda x:[x['child_category'], tuple([x[col] for col in candi_cols]) ])\
        .filter(lambda x:x[1][2] in CATE)\
        .groupByKey().flatMap(get_cate_balance).map(lambda x: ",".join(map(str, x)))\
        .repartition(10).saveAsTextFile(QUALITY_DIR + inDate)


def filter_candi_score(spark, video_candi_score, history_talent):
    """过滤候选视频
    """
    if history_talent is None:
        return video_candi_score
    else:
        history_rdd = spark.createDataFrame(history_talent.map(lambda x: Row(vid=x[0], tag=x[1])))
        candi_filter = video_candi_score.join(history_rdd, on='vid', how='left_outer')\
            .drop(history_rdd['vid'])
        return candi_filter.filter(candi_filter['tag'].isNull())


def get_cate_balance(line):
    child_category, vidset = line
    vidset = sorted(vidset, key=lambda x: x[1], reverse=True)
    topn=40
    uid_nums = 3
    cate_balance = []
    uid_set= defaultdict(int)
    rank =0
    model_id='201'
    for vid, score, parent_category, uid in vidset:
        if uid_set[uid] <= uid_nums and rank < topn:
            uid_set[uid] += 1
            cate_balance.append((vid, score, rank, parent_category))
            rank +=1
    return [[vid, score, rank, model_id, parent_category, child_category] \
            for vid, score, rank, parent_category in cate_balance]




def load_video_score(spark, dt):
    return spark.read.load(VIDEO_SCORE_DIR + dt)


def get_quality_video(spark, model_date):
    sql = "select a.vid, a.type from dw.video_recommend a join dw.video b on (a.vid=b.vid) where a.type=1 \
    and b.status =0 and b.sync =0 and b.uid >0 and to_date(a.uptime) >= '%s' order by a.uptime " %model_date
    return spark.sql(sql)

def get_quality_file(spark, file):
    """本地加载人工筛选的样本
    """
    vids = dict()
    vid_type = []
    with open(file) as f:
        for line in f:
            segment = line.strip().split(",")
            vid = segment[0]
            type = segment[1] if len(segment) > 1 else '1'
            if vid not in vids.keys():
                vid_type.append((vid, type))
    sc = spark.sparkContext
    return spark.createDataFrame(sc.parallelize(vid_type, 10).map(lambda x: Row(vid=x[0], type=x[1])))


def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)

def get_history_day(day_nums=2):
    dt =0
    mode_days  = []
    start_day = datetime.datetime.today() - datetime.timedelta(1)
    while dt < day_nums:
        start_day = start_day - datetime.timedelta(1)
        mode_days.append(start_day.strftime("%Y-%m-%d"))
        dt +=1
    return mode_days


def load_history_talent(spark, history_days, topn=12):
    def parse_history(line):
        segment = line.encode("utf-8").strip().split(",")
        if len(segment)!=6:
            return  None
        else:
            [vid, simil, rank, model_id, cate1, cate2] = segment
            return [vid, int(rank)]
    sc = spark.sparkContext
    history_data = []
    for day in history_days:
        dir = QUALITY_DIR + day
        if hadoop.is_dir_exist(dir) ==0:
            rdd = sc.textFile(QUALITY_DIR + day).map(parse_history).filter(lambda x: x is not None and x[1]<topn)
            history_data.append(rdd)
    if len(history_data) > 0 :
        rdd= sc.union(history_data)
        if rdd.count() >0:
            return rdd
    return None





if __name__ == "__main__":
    main()

