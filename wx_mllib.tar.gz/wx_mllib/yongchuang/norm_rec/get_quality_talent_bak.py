#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""将大v生产的数据，按照品类进行提取 导入redis中
@Time    : '2018/4/18 下午4:30'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'load_quality_talent.py'
"""

import datetime
from pyspark.sql import Row, SparkSession
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from collections import defaultdict
import hadoop

VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_it_score/"
QUALITY_DIR = "hdfs://Ucluster/olap/da/quality_talent/"

# 1:广场舞,2:双人舞,16:健身操,20:民族舞,21:拉丁舞,22:形体舞
CATE = [1,2,16,20,21,22]

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    model_date = (datetime.datetime.today() - datetime.timedelta(45)).strftime("%Y-%m-%d")
    del_oldhdfs(QUALITY_DIR, delDate)
    del_oldhdfs(QUALITY_DIR, inDate)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('quality_score:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    video_score = load_video_score(spark, inDate)
    #video_candi = get_quality_file(spark, "quality_user")
    video_candi = get_quality_video(spark, model_date)
    candi_cols = ['vid','score','parent_category', 'uid']
    video_candi_score = video_score.join(video_candi,on="vid",how="inner")\
        .drop(video_candi['vid'])\
        .rdd.map(lambda x:[x['child_category'], tuple([x[col] for col in candi_cols]) ])\
        .filter(lambda x:x[1][2] in CATE)\
        .groupByKey().flatMap(get_cate_balance).map(lambda x: ",".join(map(str, x)))\
        .repartition(10).saveAsTextFile(QUALITY_DIR + inDate)


def get_cate_balance(line):
    child_category, vidset = line
    vidset = sorted(vidset, key=lambda x: x[1], reverse=True)
    topn=30
    uid_nums = 3
    cate_balance = []
    uid_set= defaultdict(int)
    rank =0
    model_id='201'
    for vid, score, parent_category, uid in vidset:
        if uid_set[uid] <= uid_nums and rank < topn:
            uid_set[uid] += 1
            cate_balance.append((vid, score, rank, parent_category))
            rank +=1
    return [[vid, score, rank, model_id, parent_category, child_category] \
            for vid, score, rank, parent_category in cate_balance]




def load_video_score(spark, dt):
    return spark.read.load(VIDEO_SCORE_DIR + dt)


def get_quality_video(spark, model_date):
    sql = "select vid, type from dw.video_recommend where type=1 and to_date(uptime) >= '%s' order by uptime " %model_date
    return spark.sql(sql)

def get_quality_file(spark, file):
    """本地加载人工筛选的样本
    """
    vids = dict()
    vid_type = []
    with open(file) as f:
        for line in f:
            segment = line.strip().split(",")
            vid = segment[0]
            type = segment[1] if len(segment) > 1 else '1'
            if vid not in vids.keys():
                vid_type.append((vid, type))
    sc = spark.sparkContext
    return spark.createDataFrame(sc.parallelize(vid_type, 10).map(lambda x: Row(vid=x[0], type=x[1])))


def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)


if __name__ == "__main__":
    main()

