#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""基于视频的行为特征给视频进行打分
@Time    : '2018/4/19 下午2:49'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_video_score.py'
"""

import json
import hadoop
import datetime
from pyspark.sql import SQLContext
from pyspark.sql.types import DoubleType
from pyspark.sql.types import StringType
from pyspark.sql.types import LongType
from pyspark.sql.functions import udf
from pyspark import SparkContext, SparkConf
from pyspark.sql import Window
from pyspark.sql.functions import percent_rank
from pyspark.sql import Row, SparkSession
import math
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder
from pyspark.sql.functions import log1p
import sys
import numpy as np

video_numeric = ["hits_total", "comment_total", "SHARE","fav_count", "flower_uv", \
               "onedayctr", "onedayclick", "onedaygood", "onedaycomment", "onedayshare", \
               "allctr", "sevendayctr", "sevendayclick", "sevendaygood", "sevendaycomment",\
               "sevendayshare", "duration", "createhour", "u_exavgtime", "u_exavgpre"]
video_numeric_weight = [3,2,4,3,2,
                        3,3,2,2,3,
                        6,4,4,3,2,
                        3,0, -2, 2,2]

video_cate = ["TYPE", "child_category", "degree", "genre", "parent_category"]
video_id = ["uid", "vid"]
VIDEO_FEATURES_DIR = "hdfs://Ucluster/olap/da/recy_raw_itfeature/"
VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_it_score/"


import datetime

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    del_oldhdfs(VIDEO_SCORE_DIR, inDate)
    del_oldhdfs(VIDEO_SCORE_DIR, delDate)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('get_video_score:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    # 读取视频特征数据
    raw_features_data = spark.read.load(VIDEO_FEATURES_DIR + inDate)
    raw_features_data = check_validation(spark, raw_features_data)
    # 自定义特征权重
    features_weight = norm_video_weight()
    # 标准化视频特征,计算得分
    feature_range = get_describe(spark, raw_features_data, video_numeric, is_log=True)
    trans_features_data = video_user_Tran_v2(video_id, video_numeric,video_cate,\
                                             raw_features_data, feature_range, \
                                             features_weight, is_log=True)
    # 输出得分
    trans_features_data.createOrReplaceTempView("video_score")
    save_model_dir = VIDEO_SCORE_DIR + inDate
    trans_features_data.write.mode('overwrite').save(save_model_dir, format="parquet")
    spark.stop()

def norm_video_weight():
    total = reduce(lambda a, b: abs(a) + abs(b), video_numeric_weight)
    norm_weight = map(lambda x: x*1.0/total, video_numeric_weight)
    return dict(zip(video_numeric, norm_weight))


def get_describe(spark, raw_features_data, numeric_features, is_log=True):
    feature_range = dict()
    for i in range(len(numeric_features)):
        if is_log:
            raw_features_data = raw_features_data.withColumn(numeric_features[i], log1p(numeric_features[i]))
    index =['summary'] + numeric_features
    features_values = raw_features_data.select(numeric_features)\
        .describe().rdd.map(lambda x:[x[i] for i in index]).collect()
    for value in features_values:
        index_one = value[0]
        index_value = value[1:]
        for i in range(len(numeric_features)):
            k, v = index_one, index_value[i]
            if numeric_features[i] not in feature_range.keys():
                feature_range[numeric_features[i]] = dict()
            feature_range[numeric_features[i]][k] = v
    return feature_range


def video_user_Tran_v2(idlist, numericList, cateList, df, feature_range, features_weight, is_log):
    def max_min(x, x_range):
        indexs = x_range.get("min", 0), x_range.get("max", 0), x_range.get("mean", 0), x_range.get("stddev", 0)
        indexs = map(lambda x: float(x), indexs)
        amin, amax, amean, astd = indexs
        bmin = (amin-amean)*1.0/astd
        bmax = (amax-amean)*1.0/astd
        x = (x-amean)*1.0/astd
        return (x-bmin) *1.0/(bmax - bmin)
    def log_max_min(x, x_range):
        indexs = x_range.get("min", 0), x_range.get("max", 0), x_range.get("mean", 0), x_range.get("stddev", 0)
        indexs = map(lambda x: float(x), indexs)
        amin, amax, amean, astd = indexs
        bmin = (amin-amean)*1.0/astd
        bmax = (amax-amean)*1.0/astd
        x = (math.log1p(max(x,0))-amean)*1.0/astd
        return (x-bmin) *1.0/(bmax - bmin)
    def max_min_tf(x_range):
        return udf(lambda c: max_min(c, x_range), DoubleType())
    def log_max_min_tf(x_range):
        return udf(lambda c: log_max_min(c, x_range), DoubleType())
    def score_tf():
        return udf(get_score, DoubleType())
    def get_score(x):
        score = 0
        for feauture, weights in features_weight.iteritems():
            score += x[feauture]*1.0* weights
        return score
    numeric_tf = log_max_min_tf if is_log else max_min_tf
    vecList = list()
    for raw in idlist:
        vecList.append(raw)
    for raw in numericList:
        min_max_feature = feature_range.get(raw)
        df = df.withColumn(raw, numeric_tf(min_max_feature)(raw))
        vecList.append(raw)
    for raw in cateList:
        vecList.append(raw)
    df = df.withColumn('score', sum(df[col] * weights for col, weights in features_weight.iteritems()))
    vecList.append('score')
    return df.select(vecList)

def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)

def check_validation(spark, candi_video):
    sql = "select vid from dw.video where status =0 and uid >0 and sync=0"
    val_vid = spark.sql(sql)
    return candi_video.join(val_vid, on='vid', how='inner').drop(val_vid['vid'])

if __name__ == "__main__":
    main()

