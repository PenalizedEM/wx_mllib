#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""基于lr模型，给视频打分
@Time    : '2018/5/13 下午4:30'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_video_score_lr.py'
"""

from pyspark.ml.linalg import DenseVector
from pyspark.ml.linalg import Vectors
from pyspark.ml.linalg import SparseVector
from pyspark.sql import Row
from pyspark.sql.functions import log1p
from pyspark.ml.feature import VectorAssembler
from pyspark.sql.functions import lit
import pyspark.sql.functions as F
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder, StandardScaler
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import hadoop
import datetime
import math

lr_path = "hdfs://Ucluster/olap/da/recy_ltr_model/"
usPath = "hdfs://Ucluster/olap/da/recy_ltr_usfeature/"
itPath = "hdfs://Ucluster/olap/da/recy_ltr_itfeature/"
VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_lr_score/"
CB_QUALITY_DIR = "hdfs://Ucluster/olap/da/cb_quality_score/"
relate_dir = "hdfs://Ucluster/olap/da/related/"
relate_dir_high = "hdfs://Ucluster/olap/da/related_high/"
WX_FEED_UIDREC_DIR = "hdfs://Ucluster/olap/da/wx_uid_rec/"
WX_FEED_VID2UID_DIR = "hdfs://Ucluster/olap/da/wx_vid2uid/"
WX_FEED_CANDI_DIR = "/olap/da/gcw_recommend"
WX_RELATE_UIDREC_DIR = "hdfs://Ucluster/olap/da/wx_relate_uid_rec/"
WX_RELATE_VID2UID_DIR = "hdfs://Ucluster/olap/da/wx_relate_vid2uid/"
LIFE_RELATE_CANDI_DIR = "/olap/da/life_recommend"
LIFE_RELATE_UIDREC_DIR = "hdfs://Ucluster/olap/da/life_relate_uid_rec/"
LIFE_RELATE_VID2UID_DIR = "hdfs://Ucluster/olap/da/life_relate_vid2uid/"
MODEL_ID = '233'
FEED_MODEL = '308'



def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    days2del = [inDate, delDate]
    hdfs2del = [VIDEO_SCORE_DIR, CB_QUALITY_DIR, relate_dir, WX_RELATE_VID2UID_DIR,\
    WX_RELATE_UIDREC_DIR, WX_FEED_UIDREC_DIR, WX_FEED_VID2UID_DIR, relate_dir_high,\
    LIFE_RELATE_UIDREC_DIR, LIFE_RELATE_VID2UID_DIR]
    del_hdfs(hdfs2del, days2del)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('merge_score:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    video_good_rate = load_video_pt(spark)
    lr_model = load_model(lr_path)
    global total_size
    total_size = lr_model.coefficients.size
    it_features = load_features(spark, itPath)
    it_features = check_validation(spark, it_features)
    global it_size
    it_size = it_features.select(['features']).take(1)[0]['features'].size
    global us_size
    us_size = total_size - it_size
    predictData = get_lr_features(spark, it_features)
    lr_score = predict_score(spark,lr_model, predictData)
    lr_score_good = lr_score.join(video_good_rate, lr_score['vid']== video_good_rate['d_vid'], how='left_outer').fillna(0)
    outPath = VIDEO_SCORE_DIR + inDate
    lr_score_good.write.mode('overwrite').save(outPath, format="parquet")
    lr_score_good.select(['vid','scores', 'click_num']).withColumnRenamed('vid', 'd_vid').createOrReplaceTempView("lr_score")
    sql = "select b.vid from lr_score a join dw.video b on (a.d_vid =b.vid) \
    where b.uid >0  and b.sync =0 and b.status =0 and b.type not in (10,12, 9, 1) order by a.scores desc limit 10000"
    lr_data = spark.sql(sql)
    lr_data.rdd.map(lambda x: x['vid']).saveAsTextFile(relate_dir+inDate)
    sql = "select b.vid from lr_score a join dw.video b on (a.d_vid =b.vid) \
    where a.click_num > 1000 and b.uid >0  and b.sync =0 and b.status =0 and \
    b.type not in (10,12) order by a.scores desc limit 10000"
    lr_data = spark.sql(sql)
    lr_data.rdd.map(lambda x: x['vid']).saveAsTextFile(relate_dir_high+inDate)
    # 基于uid rec
    build_feed_rec(spark, lr_score, inDate)
    build_feed_rec(spark, lr_score, inDate, type="life")
    build_related_rec(spark, lr_score, inDate, lr_data)
    ## cf合并cb,lr,好评度得分
    #cb_quality_score = merge_score_lr(spark, lr_score_good)
    ## cf 合并 视频质量得分
    cf_quality_score = merge_cf_quality(spark, video_good_rate)
    cf_quality_score.rdd.map(lambda x:[x['vid1'], (x['vid2'], x['score'])]).groupByKey().flatMap(sorted_item)\
        .map(lambda x: ",".join(map(str, x)))\
        .repartition(100).saveAsTextFile(CB_QUALITY_DIR + inDate)

def build_feed_rec(spark, lr_score, inDate, type="gcw"):
    def sorted_uid(line):
        uid, vidlist = line
        vidlist = sorted(vidlist, key=lambda x: float(x[1]), reverse=True)[:15]
        return [[uid, vid, score, index, FEED_MODEL] for index, (vid, score) in enumerate(vidlist)]
    sc = spark.sparkContext
    if type=='gcw':
        candi_dir = WX_FEED_CANDI_DIR
        vid2uid_dir = WX_FEED_VID2UID_DIR
        uidrec_dir = WX_FEED_UIDREC_DIR
    elif type=="life":
        candi_dir = LIFE_RELATE_CANDI_DIR
        vid2uid_dir = LIFE_RELATE_VID2UID_DIR
        uidrec_dir = LIFE_RELATE_UIDREC_DIR
    feed_data =sc.textFile(candi_dir)\
        .map(lambda x: x.strip().encode("utf-8").split("\t"))\
        .filter(lambda x: len(x)==2)\
        .map(lambda x: Row(fvid=x[0], feed_type=x[1]))
    feed_dt = spark.createDataFrame(feed_data)
    feed_dt.createOrReplaceTempView("feed_dt")
    sql = "select b.vid,b.uid ,a.scores from lr_score a join feed_dt c on (a.d_vid =c.fvid) \
    join dw.video b on (a.d_vid =b.vid) where a.click_num >= 30 and b.uid >0  and b.sync =0 and \
    b.status =0 and b.type not in (10,12)"
    feed_data = spark.sql(sql)
    feed_data.rdd.map(lambda x: [x['vid'], x['uid']])\
        .map(lambda x: ",".join(map(str, x))) \
        .repartition(1) \
        .saveAsTextFile(vid2uid_dir + inDate)
    feed_data.rdd.map(lambda x: [x['uid'], (x['vid'], x['scores'])])\
        .groupByKey().flatMap(sorted_uid)\
        .map(lambda x: ",".join(map(str, x))) \
        .repartition(1) \
        .saveAsTextFile(uidrec_dir + inDate)

def build_related_rec(spark, lr_score, inDate, relate_data):
    def sorted_uid(line):
        uid, vidlist = line
        vidlist = sorted(vidlist, key=lambda x: float(x[1]), reverse=True)[:10]
        return [[uid, vid, score, index, FEED_MODEL] for index, (vid, score) in enumerate(vidlist)]
    sc = spark.sparkContext
    feed_data =sc.textFile(WX_FEED_CANDI_DIR)\
        .map(lambda x: x.strip().encode("utf-8").split("\t")[0])
    feed_data_all = feed_data.union(relate_data.rdd.map(lambda x:str(x['vid']))).distinct()
    feed_dt = spark.createDataFrame(feed_data_all.map(lambda x: Row(fvid=x)))
    feed_dt.createOrReplaceTempView("feed_dt")
    sql = "select b.vid,b.uid ,a.scores from lr_score a join feed_dt c on (a.d_vid =c.fvid) \
    join dw.video b on (a.d_vid =b.vid) where a.click_num > 300 and b.uid >0  and b.sync =0 and \
    b.status =0 and b.type not in (10,12)"
    feed_data = spark.sql(sql)
    feed_data.rdd.map(lambda x: [x['vid'], x['uid']])\
        .map(lambda x: ",".join(map(str, x))) \
        .repartition(1) \
        .saveAsTextFile(WX_RELATE_VID2UID_DIR + inDate)
    feed_data.rdd.map(lambda x: [x['uid'], (x['vid'], x['scores'])])\
        .groupByKey().flatMap(sorted_uid)\
        .map(lambda x: ",".join(map(str, x))) \
        .repartition(1) \
        .saveAsTextFile(WX_RELATE_UIDREC_DIR + inDate)


def sorted_item(line):
    vid1, rec_vids = line
    sorted_rec = sorted(rec_vids, key=lambda x: x[1], reverse=True)[:30]
    return [[vid1, value[0], value[1], index, MODEL_ID] for index, value in enumerate(sorted_rec)]

def merge_cf_quality(spark, video_good_rate):
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    sql = "select vid_1, vid_2, similarity  from da.recy_icf_similarity_topn_b where vid_1!=vid_2"
    cf_simil = spark.sql(sql)
    # 自定义的得分
    # quality_dir = "hdfs://Ucluster/olap/da/recy_it_score/"
    # quality_score = load_features(spark, quality_dir)
    # quality_good_score = quality_score.join(video_good_rate, quality_score['vid'] == video_good_rate['d_vid'],
    #                               how='left_outer').fillna(0)
    # cf_score = cf_simil.join(quality_good_score, cf_simil['vid_2']==quality_good_score['vid'], how='left_outer').fillna(0)
    ## lr得分
    quality_dir = "hdfs://Ucluster/olap/da/recy_lr_score/"
    quality_score = load_features(spark, quality_dir)
    quality_good_score= quality_score.withColumnRenamed('scores', 'score')
    cf_score = cf_simil.join(quality_good_score, cf_simil['vid_2'] == quality_good_score['vid'],
                             how='left_outer').fillna(0)
    cf_merge_score = cf_score.rdd\
        .map(lambda x: [x['vid_1'], x['vid_2'], x['similarity'],x['score'], x['good_rate'] ])\
        .map(get_total_score)
    cols = ['vid1', 'vid2', 'score']
    return spark.createDataFrame(cf_merge_score, cols)



def merge_score_lr(spark, lr_score_good):
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    sql = "select vid1, vid2, similarity  from da.recy_vid_merge_sim where dt='%s'" %(inDate)
    cb_simil = spark.sql(sql)
    cb_score = cb_simil.join(lr_score_good, cb_simil['vid2']==lr_score_good['vid'], how='left_outer').fillna(0)
    cb_merge_score = cb_score.rdd.map(lambda x: [x['vid1'], x['vid2'], x['similarity'],x['scores'], x['good_rate'] ])\
        .map(get_total_score)
    cols = ['vid1', 'vid2', 'score']
    return spark.createDataFrame(cb_merge_score, cols)

def get_total_score(line):
    vid1, vid2, simi, score, good_rate = line
    return [vid1, vid2, simi* (1+math.log(1+score)) * (1+math.log(1+good_rate))]

def predict_score(spark, lrModel, predictData):
    """基于lr模型对每一个视频打分
    """
    result = lrModel.transform(predictData).select("vid", "probability")
    result = result.rdd.map(lambda x: [x['vid'], x['probability'], x['probability'].values.tolist()[1]])
    result = spark.createDataFrame(result, ['vid', 'probability', 'scores'])
    #result = result.withColumn('scores', result['probability'].values[1])
    return result

def get_lr_features(spark, it_features):
    """获取lr模型features，使用lr模型预测
    """
    it_features = it_features.rdd.map(lambda x: [x['vid'], x['features'], SparseVector(us_size, {0:0})]).filter(lambda x: x[1].size==it_size)
    it_features =spark.createDataFrame(it_features, ['vid', 'itfeatures', 'usfeatures'])
    rawFeaList = ['itfeatures', 'usfeatures']
    scaledData = handleVec(rawFeaList, it_features)
    filter_data = scaledData.rdd.map(lambda x:[x['vid'], x['features']])\
        .filter(lambda x: x[1].size==total_size)
    return spark.createDataFrame(filter_data,['vid', 'features'])

def load_model(dir):
    """加载模型
    """
    start_day = datetime.datetime.today()
    end_day = datetime.datetime.today() - datetime.timedelta(15)
    while start_day >= end_day:
        obj_dir = dir + start_day.strftime("%Y-%m-%d") + "/data/_SUCCESS"
        if hadoop.is_file_exist(obj_dir) == 0:
            return LogisticRegressionModel.load(dir + start_day.strftime("%Y-%m-%d"))
        else:
            start_day = start_day - datetime.timedelta(1)
    return None


def load_features(spark, dir):
    """加载特征
    """
    #dir ="hdfs://Ucluster/olap/da/recy_ltr_itfeature/2018-05-13/part-r-00576-6c8e46f7-031d-4660-a01c-be74dd1050f5.snappy.parquet"
    #return  spark.read.load(dir)
    start_day = datetime.datetime.today()
    end_day = datetime.datetime.today() - datetime.timedelta(15)
    while start_day >=end_day:
        obj_dir = dir + start_day.strftime("%Y-%m-%d")+"/_SUCCESS"
        if hadoop.is_file_exist(obj_dir) == 0:
            return spark.read.load(dir + start_day.strftime("%Y-%m-%d"))
        else:
            start_day = start_day- datetime.timedelta(1)
    return None


def handleVec(rawFeaList, data):
    assembler = VectorAssembler(inputCols=rawFeaList, outputCol="rawfeatures")
    output = assembler.transform(data)
    scaler = StandardScaler(inputCol="rawfeatures", outputCol="features",
                            withStd=True, withMean=False)
    scalerModel = scaler.fit(output)
    scaledData = scalerModel.transform(output)
    return scaledData

def load_video_pt(spark):
    """获取视频近期点击及好评的点击数
    """
    end_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
    start_day = (datetime.datetime.today()-datetime.timedelta(45)).strftime("%Y-%m-%d")
    sql = "select a.d_vid, a.click_num, b.good_click from( \
    select d_vid, count(1) click_num from adm.f_new_video_vv  \
    where dt>='%s' and dt <='%s' group by d_vid ) a left outer join \
    (select d_vid, count(1) good_click from adm.f_video_pt \
    where dt>='%s' and dt <='%s' and m_pp>=97 group by d_vid) b \
    on (a.d_vid=b.d_vid)" %(start_day, end_day, start_day, end_day)
    video_click_good = spark.sql(sql).fillna(0)
    video_click_good = video_click_good.withColumn('good_rate', video_click_good['good_click'] *1.0/video_click_good['click_num'])
    return video_click_good

def get_describe(spark, raw_features_data, numeric_features, feature_range_dir, is_log):
    feature_range = dict()
    for i in range(len(numeric_features)):
        if is_log:
            raw_features_data = raw_features_data.withColumn(numeric_features[i], log1p(numeric_features[i]))
    index =['summary'] + numeric_features
    features_values = raw_features_data.select(numeric_features).describe().rdd.map(lambda x:[x[i] for i in index]).collect()
    for value in features_values:
        index_one = value[0]
        index_value = value[1:]
        for i in range(len(numeric_features)):
            k, v = index_one, index_value[i]
            if numeric_features[i] not in feature_range.keys():
                feature_range[numeric_features[i]] = dict()
            feature_range[numeric_features[i]][k] = v
    return feature_range


def del_hdfs(dirs, dts):
    """将路径对应时间下的文件删除
    """
    for dir in dirs:
        for dt in dts:
            del_oldhdfs(dir, dt)

def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)

def check_validation(spark, candi_video):
    sql = "select vid from dw.video where status =0 and uid >0 and sync=0"
    val_vid = spark.sql(sql)
    return candi_video.join(val_vid, on='vid', how='inner').drop(val_vid['vid'])

if __name__ == "__main__":
    main()




