#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""将用户表倒入到redis中
@Time    : '2018/4/27 下午3:41'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'getuser2redis.py.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import hadoop
import datetime

USER_DIR = "hdfs://Ucluster/olap/da/user2redis/"

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    ModelDate = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    del_oldhdfs(USER_DIR, inDate)
    del_oldhdfs(USER_DIR, ModelDate)
    spark = SparkSession.builder.master('yarn-client') \
        .appName('loaduser2redis:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sql ="select u_diu, u_timestamp_f from dw.uibigger where dt='%s'" %inDate
    spark.sql(sql).rdd.map(lambda x: [x['u_diu'], x['u_timestamp_f']])\
        .map(lambda x: ",".join(map(str, x))).repartition(200)\
        .saveAsTextFile(USER_DIR + inDate)
    spark.stop()




def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)


if __name__ == "__main__":
    main()
