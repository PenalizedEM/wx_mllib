# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
File:'hadoop.py'
Author:'caoyongchuang(caoyongchuang@mia.com)'
Date:'2015/12/30 14:50'
"""

import os

HADOOP_BIN='/home/hadoop/hadoop-2.6.0/bin/hadoop'
STREAMING_DIR='/home/hadoop/hadoop-2.6.0/share/hadoop/tools/lib/hadoop-streaming-2.6.0-cdh5.4.9.jar'
PYTHON = "/tools/jum.tar.gz"
DEFAULT_MAP_NUM = 100
DEFAULT_MAP_CAP = 100
DEFAULT_REDUCE_CAP = 30
DEFAULT_REDUCE_NUM = 30
DEFAULT_MEMORY_LIMIT = 1200


def is_dir_exist(hadoop_dir):
    """
    判断hadoop目录是否存在，如果存在返回0，否则返回1
    """
    cmd = "%s fs -test -d %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8


def is_file_exist(hadoop_dir):
    """
    判断hadoop文件是否存在，如果存在返回0，否则返回1
    """
    cmd = "%s fs -test -e %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8


def rm_dir(hadoop_dir):
    """
    递归删除目录，成功返回0，失败返回255
    """
    cmd = "%s fs -rm -r %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8


def mkdir(hadoop_dir):
    """
    新建目录，成功返回0，失败返回255
    """
    cmd = "%s fs -mkdir %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8


def get(hadoop_dir, local_dir):
    """
    将一个hadoop文件或者目录拷贝到本地local_dir，成功返回0，失败返回255
    """
    cmd = "%s fs -get %s %s" % (HADOOP_BIN, hadoop_dir, local_dir)
    ret = os.system(cmd)
    return ret >> 8

def getmerge(hadoop_dir, local_file):
    """
    将一个hadoop文件或者目录拷贝到本地文件，成功返回0，失败返回255
    """
    cmd = "%s fs -getmerge %s %s" % (HADOOP_BIN, hadoop_dir, local_file)
    ret = os.system(cmd)
    return ret >> 8


def put(local_dir, hadoop_dir):
    """
    将一个本地local_dir的目录或者文件上传到hadoop_dir，成功返回0，失败返回255
    """
    cmd = "%s fs -put %s %s" % (HADOOP_BIN, local_dir, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8


def cp(hdfs_file1, hdfs_file2):
    """
    将hdfs文件从hdfs_file1复制到hdfs_file2，成功返回0，失败返回255
    """
    cmd = "%s fs -cp %s %s" % (HADOOP_BIN, hdfs_file1, hdfs_file2)
    ret = os.system(cmd)
    return ret >> 8


def streaming(job_name,
              mapper,
              reducer,
              inputL,
              output,
              fileL=None,
              cacheFileL=None,
              cacheFileNameL=None,
              cacheArchiveL=None,
              cacheArchiveNameL=None,
              memory_limit=DEFAULT_MEMORY_LIMIT,
              map_num=DEFAULT_MAP_NUM,
              map_capacity=DEFAULT_MAP_CAP,
              reduce_num=DEFAULT_REDUCE_NUM,
              reduce_capacity=DEFAULT_REDUCE_CAP,
              comparator=None,
              keyfieldbasedcomparator=None,
              num_key_for_partition=None,
              num_map_output_key_fields=None
              ):
    """
    执行hadoop streaming
    """

    # 判断输出目录是否存在，如果存在则删除
    ret = is_dir_exist(output)
    if 0 == ret:
        ret = rm_dir(output)

        # 如果删除目录失败，则退出
        if 0 != ret:
            return ret

    # 构建hadoop streaming命令
    #cmd = '%s streaming ' % HADOOP_BIN
    cmd = '%s jar %s ' % (HADOOP_BIN, STREAMING_DIR)

    # mapper参数
    cmd += "-mapper '%s' " % mapper

    # reducer参数
    cmd += "-reducer '%s' " % reducer

    # 输入hdfs路径列表参数
    for input in inputL:
        cmd += "-input %s " % input

    # 输出hdfs路径参数
    cmd += "-output %s " % output

    # 本地文件参数
    if fileL is not None:
        for file in fileL:
            cmd += "-file %s " % file

    # HDFS文件参数
    if cacheFileL:
        for i in range(len(cacheFileL)):
            cmd += "-cacheFile %s#%s " % (cacheFileL[i], cacheFileNameL[i])

    # HDFS压缩文件参数
    if cacheArchiveL:
        for i in range(len(cacheArchiveL)):
            cmd += "-cacheArchive %s#%s " % (cacheArchiveL[i], cacheFileNameL[i])
    #cmd += '-cacheArchive %s#py27 ' % PYTHON # 默认加入python2.7

    # jobconf参数
    cmd += '-jobconf mapreduce.job.name=%s ' % job_name
    cmd += '-jobconf mapred.job.priority=NORMAL '
    cmd += '-jobconf stream.memory.limit=%s ' % memory_limit
    cmd += '-jobconf mapred.job.map.capacity=%s ' % map_capacity
    cmd += '-jobconf mapred.map.tasks=%s ' % map_num
    cmd += '-jobconf mapred.job.reduce.capacity=%s ' % reduce_capacity
    cmd += '-jobconf mapred.reduce.tasks=%s ' % reduce_num
    cmd += '-jobconf abaci.split.optimize.enable=False '

    if comparator is not None:
        cmd += '-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner '
        cmd += '-jobconf mapred.output.key.comparator.class'
        cmd += '=org.apache.hadoop.mapred.lib.KeyFieldBasedComparator '
        cmd += '-jobconf mapred.text.key.comparator.options=%s ' % comparator
        cmd += '-jobconf mapred.text.key.partitioner.options=-k1,1 '

    if keyfieldbasedcomparator is not None:
        cmd += '-jobconf mapred.output.key.comparator.class=org.apache.hadoop.mapred.lib.KeyFieldBasedComparator '
        cmd += '-jobconf mapred.text.key.comparator.options="%s" '% keyfieldbasedcomparator
        cmd += '-jobconf map.output.key.field.separator=" " '

    #streaming关联控制分区字段
    if num_key_for_partition is not None:
        cmd +='-jobconf num.key.fields.for.partition=%d '%(int(num_key_for_partition))

    #streaming关联控制排序字段
    if num_map_output_key_fields is not None:
        cmd += '-jobconf stream.num.map.output.key.fields=%d '%(int(num_map_output_key_fields))
        cmd += '-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner '

    #输出streaming
    print cmd

    # 执行streaming
    ret = os.system(cmd)
    return ret >> 8


if __name__ == '__main__':
    input = '/user/rp-rd/idf/part-00000'
    output = '/user/rp-rd/test'

