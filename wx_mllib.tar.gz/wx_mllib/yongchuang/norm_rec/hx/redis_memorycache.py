#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""redis、memorycahe工具
@Time    : '2017/12/27 下午2:59'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'redis_memorycache.py'
"""
import redis
import datetime
import sys
import os

REDIS_HOST= "10.10.191.217"
REDIS_PORT = "6379"



def init_redis_online(host=REDIS_HOST, port=REDIS_PORT):
    r = redis.StrictRedis(host = host, port = port, socket_timeout=1000)
    return r


def loaddata2redis(r, data, tag='talent', overwrite=True, key_redis = None):
    """将data的数据倒入到redis
    """
    p = r.pipeline(transaction=False)
    if key_redis is None:
        if tag == 'talent':
            key_redis = "r_quality_vids"
        elif tag == 'query':
            key_redis = "r_query_vids"
    if overwrite and key_redis is not None:
        r.delete(key_redis)
    num = 0
    start_job = datetime.datetime.now()
    print "job start %s" % (start_job.strftime("%Y-%m-%d %H:%m:%s"))
    for key, value in data:
        p.lpush(key, value)
        num += 1
        if num % 1000 == 0:
            print "%d num done %s\n" % (num, datetime.datetime.now().strftime("%Y-%m-%d %H:%m:%s"))
            p.execute()
            p.expire(key, 60*60*24*7)
    p.execute()
    end_job = datetime.datetime.now()
    print "job has %d,eclapse %f hours" % (num, (end_job - start_job).seconds * 1.0 / 3600)


