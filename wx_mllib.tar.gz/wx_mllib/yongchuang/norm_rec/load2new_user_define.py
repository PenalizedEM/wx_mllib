#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""基于运营的数据，给新用户进行数据展现
@Time    : '2018/5/17 上午10:39'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'load2new_user_define.py'
"""
import redis_memorycache as rmu
QUALITY_NEWUSER = "quality_user"
REDIS_HOST='10.19.112.202'
REDIS_PORT="6379"
KEY_PREFIX = 'r_user_define'

def load_quality_newuser(inFile):
    quality = []
    vidset = []
    with open(inFile) as f:
        for line in f:
            vid = line.strip()
            if vid not in vidset:
                vidset.append(vid)
                quality.append((KEY_PREFIX,vid))
    return quality

def load2redis():
    r = rmu.init_redis_online(host=REDIS_HOST, port=REDIS_PORT)
    new_quality = load_quality_newuser(QUALITY_NEWUSER)
    rmu.loaddata2redis(r, new_quality, tag=KEY_PREFIX, key_redis=KEY_PREFIX)


if __name__ == '__main__':
    load2redis()
