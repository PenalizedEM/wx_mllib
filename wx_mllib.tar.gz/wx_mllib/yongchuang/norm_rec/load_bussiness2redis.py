#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/4/26 下午7:51'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'load_bussiness2redis.py.py'
"""
import datetime
import redis_memorycache as rmu
import hadoop
import db
REDIS_HOST="10.10.7.37"
REDIS_PORT="6379"
BUSS_DIR = "hdfs://Ucluster/olap/da/business/"

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    key_redis = "r_bussiness"
    dir = BUSS_DIR + inDate
    hadoop.getmerge(dir, "./bussiness_data")
    quality_data = []
    rank = 0
    with open("./bussiness_data", "r") as f:
        for line in f:
            quality_data.append((key_redis, line.strip(), rank))
            rank +=1
    sorted_quality = sorted(quality_data, key=lambda x:x[2], reverse=True)
    quality_redis = map(lambda x: (x[0], x[1]), sorted_quality)
    rmu.loaddata2redis(r, quality_redis, key_redis =key_redis)

def load():
    rmu.loadhdfs2redis(BUSS_DIR,key_redis='r_bussiness',filename='./bussiness_data',host=REDIS_HOST, port=REDIS_PORT)

if __name__ == "__main__":
    load()
    #main()
