#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/4/19 下午9:28'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'load_quality_talent_tag.py'
"""
import datetime
import redis_memorycache as rmu
import hadoop
import db
import redis_memorycache as rmu
REDIS_HOST="10.19.159.154"
REDIS_PORT="6379"
QUALITY_DIR = "hdfs://Ucluster/olap/da/quality_talent/"
QUALITY_TAG_DIR = "hdfs://Ucluster/olap/da/quality_query/"

import os
import sys
import random
import hashlib

def main():
    if len(sys.argv)==1:
        tag = 'talent'
        inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    elif len(sys.argv) ==2:
        tag = sys.argv[1]
        inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    else:
        tag= sys.argv[1]
        inDate = sys.argv[2]
    load_data2redis(inDate, tag)

def get_healty():
    key_redis='r_query_vids'
    quality_data = []
    with open("health_all") as f:
        for line in f:
            vid = line.strip()
            segment = [vid, '0', random.randint(0, 10),'209','0','0', get_md5_value('healty'+str(random.randint(1,40)))]
            segment = ",".join(map(str,segment))
            quality_data.append((key_redis, segment))
    return quality_data

def get_md5_value(src):
    myMd5 = hashlib.md5()
    myMd5.update(src)
    myMd5_Digest = myMd5.hexdigest()
    return myMd5_Digest


def load_data2redis(inDate, tag='talent'):
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    dir = QUALITY_DIR if tag == 'talent' else QUALITY_TAG_DIR
    qualityfile = 'talent_data' if tag == 'talent' else 'quality_data' 
    key_redis = "r_quality_vids" if tag == 'talent' else "r_query_vids"
    dir = dir + inDate
    hadoop.getmerge(dir, qualityfile)
    quality_data = []
    with open(qualityfile, "r") as f:
        for line in f:
            quality_data.append((key_redis, line.strip()))
    healty_data = get_healty()
    print "healty, quality data is %d, %d" %(len(healty_data), len(quality_data))
    #if tag!='talent':
    #    quality_data.extend(healty_data)
    #    with open(qualityfile, "a") as g:
    #        for key, line in healty_data:
    #            g.write(line.strip()+"\n")
    #print "all data is %d" %(len(quality_data))
    rmu.loaddata2redis(r, quality_data, tag)
    #os.system("rm -fr quality_data")

if __name__ == "__main__":
    main()


