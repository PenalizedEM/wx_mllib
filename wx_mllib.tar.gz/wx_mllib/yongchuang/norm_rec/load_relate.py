#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""将相关视频兜底策略倒入redis中
@Time    : '2018/5/25 下午5:17'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'load_relate.py.py'
"""
import datetime
import redis_memorycache as rmu
import hadoop
import db
REDIS_HOST="10.19.159.154"
GCW_REDIS_HOST= '10.19.34.74'
REDIS_PORT="6379"
RELATED_COLDSTART_DIR = "hdfs://Ucluster/olap/da/related/"
RELATED_COLDSTART_HIGH_DIR = "hdfs://Ucluster/olap/da/related_high/"

import os

def load():
    dir =RELATED_COLDSTART_DIR
    model_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    filename = "related_coldstart"
    hadoop.getmerge(dir+model_day, filename)
    key_redis = 'r_related_coldstart'
    loadfile2redis(r, filename, key_redis=key_redis)
    os.system("rm -fr %s" %filename)
    r = rmu.init_redis_online(GCW_REDIS_HOST, REDIS_PORT)
    dir = RELATED_COLDSTART_HIGH_DIR
    filename = "related_coldstart_high"
    hadoop.getmerge(dir+model_day, filename)
    key_redis = 'r_related_high'
    loadfile2redis(r, filename, key_redis=key_redis)
    os.system("rm -fr %s" %filename)


def loadfile2redis(r, file, key_redis="r_diu_"):
    """到文件导入到redis中
    """
    p = r.pipeline(transaction=False)
    num =0
    start_job = datetime.datetime.now()
    print "job start %s" %(start_job.strftime("%Y-%m-%d %H:%m:%s"))
    r.delete(key_redis)
    with open(file) as f:
        for line in f:
            vid= line.strip().split(",", 1)[0]
            r.sadd(key_redis, vid)
            num +=1
            if num %1000==0:
                print "%d num done %s\n" %(num, datetime.datetime.now().strftime("%Y-%m-%d %H:%m:%s"))
                p.execute()
        p.execute()
    end_job = datetime.datetime.now()
    print "job has %d,eclapse %f hours" %(num, (end_job-start_job).seconds*1.0/3600)

if __name__ == "__main__":
    load()

