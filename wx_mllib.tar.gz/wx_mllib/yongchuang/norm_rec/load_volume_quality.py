#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""针对新的优质视频进行流量保护
@Time    : '2018/4/18 下午2:38'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'get_volume_quality.py'
"""
import db
import redis_memorycache as rmu
REDIS_HOST="10.19.112.202"
REDIS_PORT="6379"
import datetime
TOPN = 36 

def get_quality_flow(n):
    """获取流量保护的精品新数据
    """
    db.init(db='online')
    sql = "select vid from video_recommend where type=1 order by uptime desc limit %d" %n
    quality_flow = db.query(sql)
    all_video = [("r_new_quality", str(vid[0])) for vid in quality_flow]
    all_video = all_video[::-1]
    return all_video

def get_zero_video():
    db.init(db='online')
    sql = "select vid from playlistvideo where pid=1521464796"
    quality_zero = db.query(sql)
    all_video = [("r_zero_quality", str(vid[0])) for vid in quality_zero]
    return all_video

def get_user_define():
    dt= datetime.datetime.today()
    start = datetime.datetime.strptime("2018-05-17","%Y-%m-%d")
    day = (dt-start).days
    data=[]
    with open("health") as f:
        for line in f:
            data.append(("r_new_quality", line.strip()))
    return data[2*(day-1): (2*day)]

def merge_flow(new_quality):
    user_flow = get_user_define()
    if len(user_flow)==0:
        return new_quality
    else:
        user_flow.extend(new_quality)
    return user_flow



def main():
    r = rmu.init_redis_online(host=REDIS_HOST, port=REDIS_PORT)
    new_quality = get_quality_flow(TOPN)
    #new_quality = merge_flow(new_quality)
    for k, v in new_quality:
        print k, v
    print "new_quality nums is %d" %len(new_quality)
    rmu.loaddata2redis(r, new_quality, tag='flow', key_redis='r_new_quality')
    ## 获取零基础数据
    zero_quality = get_zero_video()
    rmu.loaddata2redis(r, zero_quality, tag='flow', key_redis='r_zero_quality')


if __name__ == "__main__":
    main()



