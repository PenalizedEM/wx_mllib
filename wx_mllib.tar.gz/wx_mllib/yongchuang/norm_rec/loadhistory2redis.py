#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/5/10 下午6:06'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'loadhot2redis.py'
"""
import datetime
import redis_memorycache as rmu
import hadoop
import db
REDIS_HOST="10.19.159.154"
REDIS_PORT="6379"
HOT_COLDSTART_DIR = "hdfs://Ucluster/olap/da/hot_histroy/"

def load():
    rmu.loadhdfs2redis(HOT_COLDSTART_DIR, key_redis='r_history_hot', \
                       filename='./history_hot_data',host=REDIS_HOST, port=REDIS_PORT)

if __name__ == "__main__":
    load()
