#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""将个性化数据倒入到redis中
@Time    : '2018/5/17 下午8:07'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'loadpersonal2redis.py'
"""
import hadoop
REDIS_HOST="10.19.132.124"
REDIS_PORT="6379"
PERSONAL_DIR = "hdfs://Ucluster/olap/da/personal_add/"
import datetime
import  redis_memorycache as rmu
import os
def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    r = rmu.init_redis(REDIS_HOST, REDIS_PORT)
    key_redis = None
    dir = PERSONAL_DIR + inDate
    hadoop.getmerge(dir, "./personal_data")
    rmu.loadfile2redis(r, "personal_data", key_redis, is_set=False)
    os.system("rm -fr personal_data")

if __name__ == "__main__":
    main()
