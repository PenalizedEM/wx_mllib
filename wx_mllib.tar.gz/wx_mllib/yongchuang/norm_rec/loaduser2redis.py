#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/4/27 下午5:31'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'loaduser2redis.py.py'
"""
import hadoop
REDIS_HOST="10.19.112.202"
REDIS_PORT="6379"
USER_DIR = "hdfs://Ucluster/olap/da/user2redis/"
import datetime
import  redis_memorycache as rmu
import sys
import os
def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT)
    key_redis = "r_all_diu_"
    dir = USER_DIR + inDate
    hadoop.getmerge(dir, "./user_data")
    rmu.loadfile2redis(r, "user_data", key_redis, is_set=True)
    os.system("rm -fr user_data")
    
if __name__ == "__main__":
    main()

    
