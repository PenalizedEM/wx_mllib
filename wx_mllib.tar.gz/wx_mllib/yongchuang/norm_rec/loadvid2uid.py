#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/5/10 下午6:06'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'loadhot2redis.py'
"""
import datetime
import redis_memorycache as rmu
import hadoop
import db
REDIS_HOST="10.19.34.74"
REDIS_PORT="6379"
VID2UID_DIR = "hdfs://Ucluster/olap/da/wx_vid2uid/"
WX_RELATE_VID2UID_DIR = "hdfs://Ucluster/olap/da/wx_relate_vid2uid/"
LIFE_RELATE_VID2UID_DIR = "hdfs://Ucluster/olap/da/life_relate_vid2uid/"
LIFE_HOST="10.19.144.223"

def load():
    dt = (datetime.datetime.today() -datetime.timedelta(1)).strftime("%Y-%m-%d")
    r = rmu.init_redis_online(REDIS_HOST, REDIS_PORT) 
    hadoop.getmerge(VID2UID_DIR + dt, './vid2uid_data')
    rmu.loadfile2redis(r, prefix='vid2uid_', \
                       file='./vid2uid_data',is_set=True)
    hadoop.getmerge(WX_RELATE_VID2UID_DIR + dt, './relate_vid2uid_data')
    rmu.loadfile2redis(r, prefix='relate_vid2uid_', \
                       file='./relate_vid2uid_data',is_set=True)
    r = rmu.init_redis_online(LIFE_HOST, REDIS_PORT)
    hadoop.getmerge(LIFE_RELATE_VID2UID_DIR + dt, './life_vid2uid_data')
    rmu.loadfile2redis(r, prefix='life_vid2uid_', \
                       file='./life_vid2uid_data',is_set=True)

if __name__ == "__main__":
    load()
