#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/6/7 下午6:21'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'log.py.py'
"""
import logging
import logging.handlers
import os
import commands
import datetime

class mylog():
    def __init__(self, logName='log', logLevel=logging.INFO, logFile="log"):
        self.logger = logging.getLogger(logName)
        self.logger.setLevel(logLevel)
        formatter = logging.Formatter('%(asctime)s %(levelname)-8s: %(message)s')
        file_handler = logging.FileHandler(logFile)
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logLevel)
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
    def get_log(self):
        return self.logger


def check_sucess(log_dir, log_file, cmd):
    """检测任务是否成功，3次错误 退出
    """
    if not log_dir.endswith("/"):
        log_dir +="/"
    log_dir_file =  log_dir + log_file
    logger = mylog(logFile=log_dir_file).get_log()
    logger.info('%s job start' % log_file)
    cmd += ' >> %s 2>&1 ' % (log_dir_file)
    retime = 0
    threhlod=2
    while retime < threhlod:
        logger.info('%s job start %d time' %(log_file, retime+1))
        print cmd
        status, output = commands.getstatusoutput(cmd)
        if status == 0:
            logger.info('%s job sucess' % log_file)
            break
        else:
            retime +=1
    if retime >=threhlod:
        logger.info('%s job error' % log_file)
        return 1
    return 0


