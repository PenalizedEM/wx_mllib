#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/8/17 下午3:54'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'lrmodel2redis.py.py'
"""
import sys
import datetime
from pyspark.sql import Row,SparkSession
from optparse import OptionParser
from pyspark.mllib.linalg import DenseVector

LR_MODEL_DIR = "hdfs://Ucluster/olap/da/gl_feat/gbdt_model/"
#LR_MODEL_DIR = "hdfs://Ucluster/olap/da/wx_gl_model/"
PORT = "6379"
EXPIRE=60*60*24*3
NODES=["10.19.14.247", "10.19.85.61"]

def rdd2redis(rdd, key='r_coefficients'):
    """将rdd数据导入到redis数据库中
    """
    import redis
    from random import choice

    # redis  连接方式可以提高性能
    def storeToRedis(item, key):
        index = 0
        while(index <3):
            try:
                index = index + 1
                r = redis.StrictRedis(host = choice(NODES), port = PORT,socket_timeout=1000)
                r.set(key,str(item))
                r.expire(key,EXPIRE)
                break
            except Exception, e:
                print 'storeToRedis error, index : %s, msg : %s'%(index,e)
    print rdd
    for item in rdd :
        storeToRedis(item,key)


def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_lrmodel2text:'+inDate)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    parser = OptionParser()
    parser.add_option("--model_day", dest="model_day", default=inDate, help="model day")
    parser.add_option("--dir", dest="dir", default=LR_MODEL_DIR, help="model dir")
    args = map(lambda x: x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    (flags, args) = parser.parse_args(args)
    mPath = flags.dir + flags.model_day + "/data/"
    ltr_model_df = spark.read.parquet(mPath)
    ltr_model_df.show()
    rdd = ltr_model_df.select("intercept").rdd.map(lambda p : p[0]).collect()
    rdd2redis(rdd, 'r_intercept')
    rdd = ltr_model_df.select("coefficients").rdd.map(lambda x:DenseVector(x).tolist()[0]).collect()
    rdd2redis(rdd)

if __name__ == '__main__':
    main()

