#!/bin/sh
mypython='/home/hadoop/anaconda2/bin/python'
python='/usr/bin/python'
day=`date -d "yesterday" +%Y-%m-%d`
hadoop='/home/hadoop/hadoop-2.6.0/bin/hadoop'
${hadoop} distcp -overwrite hdfs://10.19.35.252:8020/olap/dm/recy_icf_similarity_recently/dt=${date} hdfs://10.10.186.203:8020/olap/da/recy_icf_similarity_recently_real
${python} spark.py -m realitem2item.py
dir='hdfs://Ucluster/olap/da/recy_icf_similarity_add/'${day}
${python} spark.py -m redis_online.py -a r--input ${dir} r--prefix r_quality_
