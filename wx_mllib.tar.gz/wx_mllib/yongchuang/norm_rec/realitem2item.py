#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""将实时的数据倒入
@Time    : '2018/5/26 下午4:48'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'realitem2item.py.py'
"""
import hadoop
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
real_item2item_dir = "/olap/da/recy_icf_similarity_recently_real/"
add_item2item_dir = "/olap/da/recy_icf_similarity_add/"
MODEL_ID='234'
topn=5

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_oldhdfs(add_item2item_dir, model_day)
    spark = SparkSession.builder.master('yarn-client').appName('realitem2item:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    if hadoop.is_dir_exist(real_item2item_dir) != 0:
        print "real item data has not exist"
        exit(1)
    item2item = sc.textFile(real_item2item_dir)\
        .map(parse_item)\
        .filter(lambda x: x is not None)
    spark.createDataFrame(item2item).createOrReplaceTempView("item2item")
    sql = "select b.vid_1,b.vid_2, b.similarity \
    from item2item b join dw.video a on (a.vid =b.vid_1) \
    join dw.video c on (c.vid=b.vid_2) where a.type not in (10, 12) \
    and c.type not in (10, 12)  \
    and c.status=0 and c.sync=0 and c.uid > 0"
    real_item2item = spark.sql(sql)
    offline_item2item = loadoffline(spark)
    real_offline = real_item2item.join(offline_item2item, real_item2item['vid_1']==offline_item2item['vid_cf1'], how='left_outer')
    add_item2item = real_offline.filter(real_offline['vid_cf2'].isNull())
    num = add_item2item.count()
    print "new item2item is %d" %num
    if num==0:
        print "real data has zero result"
        exit(1)
    sorted_add = add_item2item.rdd.map(lambda x: [x['vid_1'], (x['vid_2'], x['similarity'])])\
        .groupByKey().flatMap(sorted_item)
    print "sorted item2item is %d" %sorted_add.count()
    sorted_add.map(lambda x: ",".join(map(str, x))).repartition(1).saveAsTextFile(add_item2item_dir + model_day)
    del_oldhdfs(real_item2item_dir)




def sorted_item(line):
    vid1,items = line
    sorted_item = sorted(items, key=lambda x: x[1], reverse=True)[:topn]
    return [[vid1, vid2, simil, rank, MODEL_ID] for rank,(vid2, simil) in enumerate(sorted_item)]




def loadoffline(spark):
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    sql = "select vid_1 vid_cf1, vid_2 vid_cf2  from da.recy_icf_similarity_topn_b"
    cf_simil = spark.sql(sql)
    return cf_simil

def parse_item(line):
    segment = line.strip().encode("utf-8").split("\001")
    if len(segment)!=7:
        return None
    else:
        vid_1,vid_2,num_1,num_2, num_12,similarity,hour = segment
        if float(num_12) < 3 and float(similarity) < 0.005 :
            return None
        return Row(vid_1=vid_1, vid_2=vid_2, similarity=float(similarity))

def del_oldhdfs(dir, dt=None):
    if dt is not None:
        dir = dir + dt
    if hadoop.is_dir_exist(dir) == 0:
        hadoop.rm_dir(dir)


if __name__ == "__main__":
    main()


