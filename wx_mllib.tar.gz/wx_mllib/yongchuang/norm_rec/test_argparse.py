#!/usr/bin/env python
#encoding=utf-8
# -*- coding: utf-8 -*-
import sys
import argparse

def main():
    parse = argparse.ArgumentParser()
    parse.add_argument("--input", default=None, help="load hdfs dir 2 redis")
    parse.add_argument("--host",  default="10.19.112.202", help="redis host")
    parse.add_argument("--port", default="6379", help="redis port")
    parse.add_argument("--expire", default=3,type=int ,help="key expire days")
    parse.add_argument("--sep", default=",", help="field segmentation")
    parse.add_argument("--key_filed", default=1, help="the number of  field for key")
    parse.add_argument("--prefix", default="", help="key prfex to redis")
    parse.add_argument("--user", default="caoyc", help="user email to submit job")
    flags, unparsed = parse.parse_known_args(sys.argv[1:])
    if flags.input is None:
        print "please input hdfs dir to redis"
        sys.exit(-1)
    print flags.user


if __name__ =="__main__":
    main()
