#!/usr/bin/env python
from optparse import OptionParser
def main():
    parser = OptionParser()
    parser.add_option("-i", "--infile", dest="filename", default=",",
                      help="write report to FILE", metavar="FILE")
    parser.add_option("-o", "--output", dest="outfile",
                      help="write report to FILE", metavar="FILE")
    parser.add_option("-q", "--quiet",
                      action="store_false", dest="verbose", default=True,
                      help="don't print status messages to stdout")
    (options, args) = parser.parse_args()
    print options.filename
    print options.outfile
    print  args

if __name__ =="__main__":
    main()
