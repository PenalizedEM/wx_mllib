#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""自动抓取优质内容进入分发
@Time    : '2018/5/19 上午11:37'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'user_quality.py.py'
"""

import sys
reload(sys)
sys.setdefaultencoding('utf8')
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from collections import defaultdict
import datetime
import jieba
import hadoop
import hashlib
QUALITY_TAG_DIR = "hdfs://Ucluster/olap/da/quality_query/"
VIDEO_FEATURES_DIR = "hdfs://Ucluster/olap/da/recy_raw_itfeature/"
VIDEO_SCORE_DIR = "hdfs://Ucluster/olap/da/recy_lr_score/"

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    delDate = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    del_oldhdfs(QUALITY_TAG_DIR, delDate)
    del_oldhdfs(QUALITY_TAG_DIR, inDate)
    model_date = (datetime.datetime.today() - datetime.timedelta(45)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.master('yarn-client') \
        .appName('user select quality:' + inDate) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    # 读取视频特征数据,获取候选的视频
    raw_features_data = load_video(spark, VIDEO_FEATURES_DIR)
    candi_video = get_candi_video(spark, raw_features_data)
    candi_video = check_validation(spark, candi_video)
    history_days = [(datetime.datetime.today() - datetime.timedelta(2)).strftime("%Y-%m-%d")]
    query_history = load_history_tag(spark, history_days, topn=20)
    filter_candi = filter_candi_score(spark, candi_video, query_history)
    print "candi vid is %d" %filter_candi.count()
    # 加载得分
    video_score = load_video(spark, VIDEO_SCORE_DIR)
    candi_cols = ['child_category', 'vid', 'scores', 'parent_category', 'uid']
    video_candi_score = video_score.join(filter_candi, on="vid", how="inner") \
        .drop(filter_candi['vid']) \
        .rdd.map(lambda x: [x[col] for col in candi_cols]) \
        .map(lambda x: [x[0], tuple(x[1:])]) \
        .groupByKey().flatMap(get_cate_balance).map(lambda x: ",".join(map(str, x))) \
        .repartition(1).saveAsTextFile(QUALITY_TAG_DIR + inDate)

def get_cate_balance(line):
    child_category, vidset = line
    vidset = sorted(vidset, key=lambda x: float(x[1]), reverse=True)
    topn = 15
    uid_nums = 3
    cate_balance = []
    uid_set = defaultdict(int)
    rank = 0
    model_id = '202'
    query_md5 = get_md5_value(str(child_category))
    for vid, score, parent_category, uid in vidset:
        if uid_set[uid] <= uid_nums and rank < topn:
            uid_set[uid] += 1
            cate_balance.append((vid, score, rank, parent_category, child_category))
            rank += 1
    return [[vid, score, rank, model_id, parent_category, child_category, query_md5] \
            for vid, score, rank, parent_category, child_category in cate_balance]


def load_video(spark, fdir):
    inDate = datetime.datetime.today() - datetime.timedelta(1)
    i=0
    while i < 15:
        dir = fdir + inDate.strftime("%Y-%m-%d")
        if hadoop.is_file_exist(dir+"/_SUCCESS") == 0:
            return spark.read.load(dir)
        else:
            i+=1
            inDate = inDate - datetime.timedelta(1)
    return None


def get_candi_video(spark, raw_data):
    cols =['hits_total', 'TYPE','parent_category', 'child_category','allctr','sevendayctr','vid','uid']
    filter_data = raw_data.rdd.map(lambda x: [x[col] for col in cols])\
        .filter(lambda x: x[1] not in (10, 12) and x[0] > 20000 and float(x[4]) >0.044)
    filter_rdd = spark.createDataFrame(filter_data).toDF(*cols)
    return filter_rdd


def del_oldhdfs(dir, dt):
    if hadoop.is_dir_exist(dir + dt) == 0:
        hadoop.rm_dir(dir + dt)

def get_md5_value(src):
    myMd5 = hashlib.md5()
    myMd5.update(src)
    myMd5_Digest = myMd5.hexdigest()
    return myMd5_Digest

def filter_candi_score(spark, video_candi_score, history_talent):
    """过滤候选视频
    """
    if history_talent is None:
        return video_candi_score
    else:
        history_rdd = spark.createDataFrame(history_talent.map(lambda x: Row(vid=x[0], tag=x[1])))
        candi_filter = video_candi_score.join(history_rdd, on='vid', how='left_outer')\
            .drop(history_rdd['vid'])
        return candi_filter.filter(candi_filter['tag'].isNull())

def load_history_tag(spark, history_days, topn=300):
    def parse_history(line):
        segment = line.encode("utf-8").strip().split(",")
        if len(segment)<=4:
            return  None
        else:
            [vid, simil, rank, model_id] = segment[:4]
            return [vid, int(rank)]
    sc = spark.sparkContext
    history_data = []
    for day in history_days:
        dir = QUALITY_TAG_DIR + day
        if hadoop.is_dir_exist(dir) ==0:
            rdd = sc.textFile(QUALITY_TAG_DIR + day).map(parse_history)\
                .filter(lambda x: x is not None and x[1]<topn)
            history_data.append(rdd)
    if len(history_data) > 0 :
        rdd= sc.union(history_data)
        if rdd.count() >0:
            return rdd
    return None

def check_validation(spark, candi_video):
    sql = "select vid from dw.video where status =0 and uid >0 and sync=0"
    val_vid = spark.sql(sql)
    return candi_video.join(val_vid, on='vid', how='inner').drop(val_vid['vid'])

if __name__ == "__main__":
    main()

