select a.parent_category,a.cate1_name, a.child_category,a.cate2_name,count(1)
from 
(select a.vid, a.parent_category,b.name cate1_name, a.child_category,c.name cate2_name
from video a
join video_category b on (a.parent_category=b.id)
join video_category c on (a.child_category=c.id)
where a.type not in (10, 12)
)a
group by a.parent_category,a.cate1_name, a.child_category,a.cate2_name
order by a.parent_category
;
