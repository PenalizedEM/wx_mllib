#!/bin/sh
mypython='/home/hadoop/anaconda2/bin/python'
python='/usr/bin/python'
hadoop='/home/hadoop/hadoop-2.6.0/bin/hadoop'
day=`date -d "1 days ago" +%Y-%m-%d`
#${hadoop} distcp hdfs://10.42.55.58:8020/olap/da/gcw_recommend /olap/da
#${hadoop} distcp hdfs://10.42.55.58:8020/olap/da/life_recommend /olap/da
#${python} spark.py -m get_video_score_lr.py
dir='hdfs://Ucluster/olap/da/cb_quality_score/'${day}
${python} spark.py -m redis_online.py -a r--input ${dir} r--prefix r_quality_
${mypython} load_relate.py
dir='hdfs://Ucluster/olap/da/wx_uid_rec/'${day}
${python} spark.py -m redis_online.py -a r--input ${dir} r--prefix uid_ r--save_nums 1 r--host 10.19.34.74,10.19.42.186,10.19.54.190
dir='hdfs://Ucluster/olap/da/wx_relate_uid_rec/'${day}
${python} spark.py -m redis_online.py -a r--input ${dir} r--prefix relate_uid_ r--save_nums 1 r--host 10.19.34.74,10.19.42.186,10.19.54.190
dir='hdfs://Ucluster/olap/da/life_relate_uid_rec/'${day}
${python} spark.py -m redis_online.py -a r--input ${dir} r--prefix life_uid_ r--save_nums 1 r--host 10.19.144.223,10.19.63.146
${mypython} loadvid2uid.py

