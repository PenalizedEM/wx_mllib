#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/9/27 下午4:40'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'real_cf.py.py'
"""

import hadoop
import util
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import pyspark.sql.functions as sf
import datetime
from optparse import OptionParser
import sys
import math
SIMIL_FILTER=0.001

LIFE_REAL_ITEM2ITEM_DIR="/olap/da/life_real_item2item/"
LIFE_ITEM2ITEM_DIR = "/olap/da/life_item2item/"

LIFE_SIMIL_MODE_ID="17"



def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    mode_date = datetime.datetime.today().strftime("%Y-%m-%d")
    spark = SparkSession.builder.master('yarn-client') \
        .appName('item_cf:' + mode_date) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.addPyFile("util.py")
    sc.addPyFile("hadoop.py")
    save_dir = LIFE_REAL_ITEM2ITEM_DIR + mode_date
    hadoop.rm_dir(save_dir)
    real_df = load_realdata(spark, mode_date)
    item2item_simil = cf_item_simil(spark, real_df)
    life_feed_simil_all = build_business_item2item(sc, item2item_simil, type='life')\
        .map(lambda (item1, item2, simil, rank):[item1, (item2, simil, rank)])
    life_item2item= util.load_item2item(sc, LIFE_ITEM2ITEM_DIR)\
        .map(lambda (item1, item2, simil, rank):[item1, (item2, simil, rank)])
    real_life_feed_simil = life_feed_simil_all.subtractByKey(life_item2item)\
        .map(lambda (item1, (item2, simil, rank)):[item1, item2, simil, rank]).filter(lambda x: x[3]<10)
    real_life_feed_simil.map(lambda x: util.add_mode_id(x, LIFE_SIMIL_MODE_ID)) \
        .coalesce(200).saveAsTextFile(save_dir)



def load_realdata(spark, mode_day):
    sql = "select u_uuid diu, u_vid vid from edw.wx_video_click  where u_appname in ('yangsheng','gaoxiao') \
    and dt ='%s' and u_uuid is not null" %(mode_day)
    return spark.sql(sql).rdd.map(lambda x:[x['diu'], x['vid']])


def cf_item_simil(spark, user_item_ID):
    """计算item2item 的cosine相似度
    Args:
        user_item_ID:用户-视频数据
    Returns:
        item2item_simil:(item1,(item2,simil))分别为item1,item2,cosine相似度
    """
    user_item_item = user_item_ID.join(user_item_ID).map(lambda (uid, (item1, item2)): [(item1, item2), uid]).repartition(4000)
    #item_item_nums = user_item_item.map(lambda ((item1, item2), uid): [(item1, item2), set([uid])])\
    #    .reduceByKey(lambda a, b: a | b).map(lambda ((item1, item2), uidlist): [(item1, item2), len(uidlist)])
    item_item_nums = user_item_item.map(lambda ((item1, item2), uid): [(item1, item2), 1])\
        .reduceByKey(lambda a, b: a+ b)
    item_user_nums = item_item_nums.map(lambda ((item1, item2),co_nums): [item1, int(co_nums)])\
        .reduceByKey(lambda a, b: a + b)
    item1_nums = item_item_nums.map(lambda ((item1, item2), co_nums): [item1, (item2, co_nums)]).join(item_user_nums)
    item2_nums = item1_nums.map(lambda (item1, ((item2, co_nums), nums_item1)):
                                [item2, (item1, co_nums, nums_item1)]).join(item_user_nums)
    item2item_simil = item2_nums.map(cosine_simil).filter(lambda (item1, (item2, simil)): simil > 0)
    return item2item_simil


def cosine_simil(item_nums):
    """计算cosine相似度
    Args:
        [item2,((item1,item1_item2_nums,item1_nums),item2_nums)]:分别是item2_id,item1_id,
            item1_id与item2_id的共同点击量，item1_id点击量，item2_id点击量
    returns:
        [item1,(item2,simil)]:分别为item1_id,item2_id,item1_id与item2_id的cosine相似度
    """
    item2, ((item1, item1_item2_nums, item1_nums), item2_nums) = item_nums
    if item1==item2 or item1_item2_nums < 3:
        simil = 0
    else:
        simil = item1_item2_nums * 1.0 /math.sqrt(item1_nums * item2_nums)
        if simil <SIMIL_FILTER:
            simil=0
    return [item1, (item2, simil)]

def build_business_item2item(sc, item2item_simil, type="gcw"):
    """过滤gcw item2item相似度
    """
    def load_gcw(sc, dir):
        all_videos = sc.textFile(dir)\
            .map(lambda x: x.strip().split("\t")[:2]).collectAsMap()
        return all_videos
    if type=="gcw":
        dir = "/olap/da/gcw_recommend/recommed"
    elif type=="life":
        dir = "/olap/da/life_recommend/recommed"
    feed_video = load_gcw(sc, dir)
    feed_video_dict = sc.broadcast(feed_video)
    item2item_filter= item2item_simil.filter(lambda x: x[1][0] in feed_video_dict.value.keys())
    item2item_topn = util.sorted_recommed(item2item_filter)
    return item2item_topn

if __name__ == "__main__":
    main()
