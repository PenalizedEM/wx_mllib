#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/6/5 上午10:48'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recommder.py.py'
"""
import util
def recommed_user(sc, item2item_simil_topn, user_item_date, recommed_nums):
    """依据用户的历史点击数据、 视频到视频的相似度计算用户的推荐列表
    Args:
        item2item_simil_topn(item1,item2,simil,rank):视频到视频的相似度
        user_item_date[uid,item,weights]:用户、视频、偏好得分
        recommed_nums:对用户推荐视频个数
    Returns:
        uid:用户id
        item_id:视频id
        pref:用户对商品得分
        rank:rank值
    """
    item2item_simil = item2item_simil_topn.map(lambda (item1, item2, simil, rank): [item1, (item2, simil)])
    user_item2_simil_date = user_item_date.map(lambda (uid, item_id, weights): [item_id, (uid, weights)])\
        .join(item2item_simil)
    user_item2_pref = user_item2_simil_date.map(lambda (item1, ((uid, weights), (item2, simil))): [(uid, item2), weights * simil])
    # 用户的推荐列表
    user_item_pref = user_item2_pref.reduceByKey(lambda x, y: x + y).map(lambda x: list(x))
    # 过滤用户的历史购买记录
    user_recommed_list = user_item_pref.subtractByKey(user_item_date.map(lambda (uid, item_id, weights): [(uid, item_id), weights]))
    user_recommed = user_recommed_list.map(lambda ((uid, item_id), pref): [uid, (item_id, pref)])
    # 推荐列表topN过滤
    user_item_pref_rank = util.sorted_recommed(user_recommed, topn=recommed_nums)
    return user_item_pref_rank

def recommed_ucf(sc, user2user_simil_topn, user_item_date, recommed_nums):
    """依据用户的历史点击数据、 用户到用户的相似度计算用户的推荐列表
    Args:
        user2user_simil_topn(uid1, uid2,simil,rank):用户到用户的相似度
        user_item_date[uid,item,weights]:用户、视频、偏好得分
        recommed_nums:对用户推荐视频个数
    Returns:
        uid:用户id
        item_id:视频id
        pref:用户对商品得分
        rank:rank值
    """
    user2user_simil = user2user_simil_topn.map(lambda (uid1, uid2, simil, rank): [uid2, (uid1, simil)])
    user_item2_simil_date = user_item_date.map(lambda (uid, item_id, weights): [uid, (item_id, weights)])\
        .join(user2user_simil)
    user_item2_pref = user_item2_simil_date.map(lambda (uid2, ((item_id, weights), (uid1, simil))): [(uid1, item_id), weights * simil])
    # 用户的推荐列表
    user_item_pref = user_item2_pref.reduceByKey(lambda x, y: x + y).map(lambda x: list(x))
    # 过滤用户的历史购买记录
    user_recommed_list = user_item_pref.subtractByKey(user_item_date.map(lambda (uid, item_id, weights): [(uid, item_id), weights]))
    user_recommed = user_recommed_list.map(lambda ((uid, item_id), pref): [uid, (item_id, pref)])
    # 推荐列表topN过滤
    user_item_pref_rank = util.sorted_recommed(user_recommed, topn=recommed_nums)
    return user_item_pref_rank
