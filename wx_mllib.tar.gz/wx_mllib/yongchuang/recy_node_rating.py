#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取ucf数据源
@Time    : '2018/09/01 下午3:15'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recy_node_rating.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import datetime
import util
import hadoop

NODE2VEC="hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/"

def main():
    mode_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder \
        .appName('recy_node_rating:' + mode_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    hadoop.del_oldhdfs(NODE2VEC)
    last_model_day = (datetime.datetime.today()-datetime.timedelta(31)).strftime("%Y-%m-%d")
    # sql = "drop table if exists da.recy_node_rating"
    # spark.sql(sql)
    # create_sql = "CREATE TABLE da.recy_node_rating (diu string, vid string, pref double) \
    # ROW FORMAT DELIMITED  FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' STORED AS TEXTFILE;"
    sql = "insert overwrite table da.recy_node_rating select u_uuid diu, u_vid vid,\
    if(f_rating=0, 0.5, f_rating)*exp(-0.049*datediff('%s', from_unixtime(f_timestamp, 'yyyy-MM-dd'))) pref \
    from da.wx_recy_uvm \
    where dt= '%s' and u_appname='yangsheng' and to_date(from_unixtime(f_timestamp)) >= '%s' \
    and to_date(from_unixtime(f_timestamp)) <= '%s'" %(mode_day, mode_day, last_model_day, mode_day)
    spark.sql(sql)
    spark.stop()




if __name__ == "__main__":
    main()


