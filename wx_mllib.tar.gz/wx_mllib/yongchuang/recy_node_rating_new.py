#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取ucf数据源
@Time    : '2018/09/01 下午3:15'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recy_node_rating.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import datetime
import math
import util
import hadoop

SIMIL_FILTER=0.001
NODE2VEC="hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/"

def main():
    mode_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder \
        .appName('recy_node_rating:' + mode_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    hadoop.del_oldhdfs(NODE2VEC)
    last_model_day = (datetime.datetime.today()-datetime.timedelta(31)).strftime("%Y-%m-%d")
    # sql = "drop table if exists da.recy_node_rating"
    # spark.sql(sql)
    # create_sql = "CREATE TABLE da.recy_node_rating (diu string, vid string, pref double) \
    # ROW FORMAT DELIMITED  FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' STORED AS TEXTFILE;"
    # insert overwrite table da.recy_node_rating
    sql = "select u_uuid diu, u_vid vid,\
    if(f_rating=0, 0.5, f_rating)*exp(-0.049*datediff('%s', from_unixtime(f_timestamp, 'yyyy-MM-dd'))) pref \
    from da.wx_recy_uvm \
    where dt= '%s' and u_appname in ('yangsheng', 'gaoxiao', 'squaredance') and to_date(from_unixtime(f_timestamp)) >= '%s' \
    and to_date(from_unixtime(f_timestamp)) <= '%s'" %(mode_day, mode_day, last_model_day, mode_day)
    user_vid_pref = spark.sql(sql).rdd.map(lambda x:[x['diu'], x['vid']])
    item2item_simil = cf_item_simil(spark, user_vid_pref)\
        .map(lambda (item1, (item2, simil)): Row(item1=item1, item2=item2, simil=simil))
    item2item_df = spark.createDataFrame(item2item_simil)
    item2item_df.createOrReplaceTempView("item2item")
    sql = "insert overwrite table da.recy_node_rating \
        select item1 diu, item2, simil from item2item"
    spark.sql(sql)
    spark.stop()



def cf_item_simil(spark, user_item_ID):
    """计算item2item 的cosine相似度
    Args:
        user_item_ID:用户-视频数据
    Returns:
        item2item_simil:(item1,(item2,simil))分别为item1,item2,cosine相似度
    """
    user_item_item = user_item_ID.join(user_item_ID).map(lambda (uid, (item1, item2)): [(item1, item2), uid]).repartition(4000)
    #item_item_nums = user_item_item.map(lambda ((item1, item2), uid): [(item1, item2), set([uid])])\
    #    .reduceByKey(lambda a, b: a | b).map(lambda ((item1, item2), uidlist): [(item1, item2), len(uidlist)])
    item_item_nums = user_item_item.map(lambda ((item1, item2), uid): [(item1, item2), 1])\
        .reduceByKey(lambda a, b: a+ b)
    item_user_nums = item_item_nums.map(lambda ((item1, item2),co_nums): [item1, int(co_nums)])\
        .reduceByKey(lambda a, b: a + b)
    item1_nums = item_item_nums.map(lambda ((item1, item2), co_nums): [item1, (item2, co_nums)]).join(item_user_nums)
    item2_nums = item1_nums.map(lambda (item1, ((item2, co_nums), nums_item1)):
                                [item2, (item1, co_nums, nums_item1)]).join(item_user_nums)
    item2item_simil = item2_nums.map(cosine_simil).filter(lambda (item1, (item2, simil)): simil > 0)
    return item2item_simil


def cosine_simil(item_nums):
    """计算cosine相似度
    Args:
        [item2,((item1,item1_item2_nums,item1_nums),item2_nums)]:分别是item2_id,item1_id,
            item1_id与item2_id的共同点击量，item1_id点击量，item2_id点击量
    returns:
        [item1,(item2,simil)]:分别为item1_id,item2_id,item1_id与item2_id的cosine相似度
    """
    item2, ((item1, item1_item2_nums, item1_nums), item2_nums) = item_nums
    if item1==item2 or item1_item2_nums < 3:
        simil = 0
    else:
        simil = item1_item2_nums * 1.0 /math.sqrt(item1_nums * item2_nums)
        if simil <SIMIL_FILTER:
            simil=0
    return [item1, (item2, simil)]


if __name__ == "__main__":
    main()
