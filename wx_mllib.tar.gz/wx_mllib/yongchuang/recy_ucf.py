#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""由user2user相似度，计算user topn相似度，同时计算个性化推荐列表
@Time    : '2018/6/13 下午2:37'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recy_ucf.py.py'
"""
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import random
import util
import hadoop
import sys
import recommder

# user2user用户的相似邻居的个数
NEIGHBOURS = 60
# 用户推荐商品个数
RECOMMED_NUMS = 100
# 用于个性化计算用户的相似度
HIGH_NEIGHBOURS= 30
# user cf视频相似度模型id
SIMIL_MODE_ID = "12"
# user cf个性化推荐列表
PERSONAL_MODE_ID = "22"
# user2user 相似度表
USER2USER_DIR= "/olap/da/ucf_item2item/"
# user cf个性化列表
USERPERSONAL_DIR="/olap/da/ucf_personal/"
UPDATE_USER_SIMIL=True


INPUT_DIR=""
from optparse import OptionParser


def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--uvr_dir", dest="uvr_dir", default=INPUT_DIR, help="user item pref dir")
    parser.add_option("--user2user_dir", dest="user2user_dir", default=USER2USER_DIR, help="user cf  simil dir")
    parser.add_option("--is_dt", dest="is_dt", default=True, help="whether item simil dir add date")
    parser.add_option("--personal_dir", dest="personal_dir", default=USERPERSONAL_DIR, help="user cf personal dir")
    parser.add_option("--update_simil", dest="update_simil", default=UPDATE_USER_SIMIL, help="whether update user simil")
    (flags, args) = parser.parse_args(args)
    if flags.update_simil in ['False','F','false','f']:
        flags.update_simil = False
    if flags.is_dt in ['False','F','false','f']:
        flags.is_dt = False
    cf_user_dir = flags.user2user_dir
    cf_personal_dir = flags.personal_dir
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_day = (datetime.datetime.today()- datetime.timedelta(3)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.appName('recy_ucf:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.addPyFile("recommder.py") 
    sc.addPyFile("hadoop.py") 
    sc.addPyFile("util.py")
    cf_del_dir = [cf_personal_dir]
    if flags.update_simil:
        cf_del_dir.append(cf_user_dir)
    hadoop.del_hdfs(cf_del_dir, [model_day, del_day])
    # 输入数据源
    util.update_table(spark)
    user_item_weight = util.load_file(spark, INPUT_DIR, method='ucf').map(lambda x: x[:3])
    if flags.update_simil:
        user2user_simil_topn=get_ucf_simil(spark)
        user2user_simil_topn.map(lambda x: util.add_mode_id(x, SIMIL_MODE_ID)). \
            coalesce(200).saveAsTextFile(USER2USER_DIR + model_day)
    else:
        # 加载item2item的相似度数据
        user2user_simil_topn = util.load_item2item(sc, cf_user_dir, flags.is_dt)
    # 个性化推荐列表,过滤点击过的视频
    user_recommed_list = recommder.recommed_ucf(sc,
                                                 user2user_simil_topn.filter(lambda x: x[3]<HIGH_NEIGHBOURS),
                                                 user_item_weight, RECOMMED_NUMS*5)
    # 个性化推荐列表, 需过滤历史推荐数据
    filter_user_recommed = util.filter_recommed_history(sc, user_recommed_list, USERPERSONAL_DIR)
    # 过滤曝光数据
    filter_recommed = util.filter_exposure(spark, filter_user_recommed)
    user_recommed_save = util.sorted_recommed(filter_recommed, topn=RECOMMED_NUMS)
    user_recommed_save.map(lambda x: util.add_mode_id(x, PERSONAL_MODE_ID)).\
        coalesce(200).saveAsTextFile(cf_personal_dir + model_day)
    spark.stop()



def get_ucf_simil(spark):
    user_simil_mid = load_ucf_simil_mid(spark)
    user2user_simil = user_simil_mid.map(get_simil) \
        .filter(lambda x: x is not None)
    user2user_simil_topn = util.sorted_recommed(user2user_simil, topn=NEIGHBOURS)
    return user2user_simil_topn


def load_ucf_simil_mid(spark):
    """加载user cf的相似度计算表
    """
    cols = ['diu_1', 'diu_2', 'num_1', 'num_2','num_12']
    sql = "select %s from da.recy_ucf_similarity_mid " %",".join(cols)
    df = spark.sql(sql)
    return df.rdd.map(lambda x: [x[col] for col in cols])

def get_simil(line):
    diu_1, diu_2, num_1, num_2, num_12 = line
    if num_12 < 4 or diu_1==diu_2:
        return None
    else:
        simil = num_12 *1.0/(num_1 *num_2)
        if simil < 0.003:
            return None
    return [diu_1, (diu_2, simil)]

if __name__ == "__main__":
    main()
