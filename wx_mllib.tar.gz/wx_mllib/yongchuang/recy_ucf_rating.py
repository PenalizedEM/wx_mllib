#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""获取ucf数据源
@Time    : '2018/6/22 下午3:15'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recy_ucf_rating.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import datetime
import util

def main():
    mode_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder \
        .appName('recy_ucf_rating:' + mode_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    util.update_table(spark)
    last_model_day = (datetime.datetime.today()-datetime.timedelta(11)).strftime("%Y-%m-%d")
    sql = "select u_uuid diu, u_vid vid, if(f_rating=0, 0.5, f_rating) pref,\
    from_unixtime(f_timestamp, 'yyyy-MM-dd') actdate\
    from da.wx_recy_uvm \
    where dt='%s' and u_appname='squaredance' and to_date(from_unixtime(f_timestamp)) >= '%s' \
    and to_date(from_unixtime(f_timestamp)) <= '%s' " %(mode_day, last_model_day, mode_day)
    user_item_pref = spark.sql(sql)
    #user_item_pref = util.load_file(spark, input_dir, method='ucf')
    diu_nums = user_item_pref.rdd\
        .map(lambda x: [x['diu'], set([x['vid']])])\
        .reduceByKey(lambda a, b: a|b)\
        .map(lambda x:Row(diu=x[0], pv=len(x[1])))
    diu_pv = spark.createDataFrame(diu_nums)
    vid_nums = user_item_pref.rdd\
        .map(lambda x: [x['vid'], 1])\
        .reduceByKey(lambda a, b: a+b)\
        .map(lambda x:Row(vid=x[0], uv=x[1]))
    vid_uv = spark.createDataFrame(vid_nums)
    ucf_df = user_item_pref.join(diu_pv, on='diu')\
        .drop(diu_pv['diu']).join(vid_uv, on='vid')\
        .drop(vid_uv['vid'])
    cols = ['diu', 'vid', 'pref', 'uv', 'pv', 'actdate']
    ucf_df.createOrReplaceTempView("ucf_rating")
    sql = "drop table if exists da.recy_ucf_rating"
    spark.sql(sql)
    sql= "create table da.recy_ucf_rating as select %s from ucf_rating" %",".join(cols)
    spark.sql(sql)
    spark.stop()


if __name__ == "__main__":
    main()


