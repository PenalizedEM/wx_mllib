#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ucf相似度计算
@Time    : '2018/5/29 下午3:02'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recy_ucf_similarity_mid.py'
"""
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import random

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_day = (datetime.datetime.today()- datetime.timedelta(7)).strftime("%Y-%m-%d")
    #spark = SparkSession.builder.master('yarn-client') \
    spark = SparkSession.builder.appName('recy_ucf_similarity_mid:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", 4000)
    spark.conf.set("spark.default.parallelism", 1000)
    spark.conf.set("spark.shuffle.memoryFraction", "0.3")
    spark.conf.set("spark.shuffle.consolidateFiles", "true")
    spark.conf.set("spark.shuffle.io.maxRetries", 6)
    #spark.conf.set("spark.yarn.executor.memoryOverhead", 4096)
    #high_sql_filter = "select diu, vid, rating, uv, pv, actdate from da.recy_ucf_rating2 where uv < 50000 and uv >5000"
    #high_data_filter = spark.sql(high_sql_filter)
    #high_data_filter.createOrReplaceTempView("recy_ucf_rating_high")
    #high_sql = "select a.diu diu_1 ,b.diu diu_2 ,a.pv num_1, b.pv num_2, count(1) num_12 \
    #from recy_ucf_rating_high a join recy_ucf_rating_high b on (a.vid=b.vid and a.actdate=b.actdate) \
    #where a.diu<b.diu group by a.diu,b.diu, a.pv, b.pv"
    #head_data = spark.sql(high_sql)
    ### tail 数据
    #tail_sql_filter = "select a.diu diu_1 ,b.diu diu_2 ,a.pv num_1, b.pv num_2, count(1) num_12 \
    #from (select diu, vid, pv  \
    #from da.recy_ucf_rating \
    #where uv <= 5000 and uv >100 and pv > 10 limit 20000) a \
    #join (select diu, vid, pv \
    #from da.recy_ucf_rating \
    #where uv <= 5000 and uv > 100 and pv > 10 limit 20000) b on (a.vid=b.vid) \
    #where  a.diu <> b.diu  group by a.diu,b.diu, a.pv, b.pv"
    #tail_data = spark.sql(tail_sql_filter)
    #### head 数据
    cols = [ 'vid', 'diu', 'pv', 'actdate']
    head_sql_filter = "select %s from da.recy_ucf_rating where uv > 10000 and uv <=40000 and pv >20" %",".join(cols)
    head_sql_filter = spark.sql(head_sql_filter)
    head_data = head_sql_filter.rdd.map(lambda x:[x[col] for col in cols]).repartition(10000)
    npart = 30
    head_left = head_data.map(lambda x: ["_".join([str(x[0]),x[3],str(random.randint(0, npart))]), tuple(x[1:3])])
    head_right = head_data.flatMap(lambda x: [["_".join([str(x[0]), x[3],str(i)]), tuple(x[1:3])] for i in range(npart)])
    head_rdd = head_left.join(head_right).map(get_head_part)\
        .filter(lambda x: x is not None)\
        .reduceByKey(lambda a, b: a|b).map(get_co_nums)
    ##head_data.unpersist()
    head_data_out = spark.createDataFrame(head_rdd)
    #all_data = tail_data.union(head_data_out).rdd.map(lambda x: ["\001".join([x['diu_1'], x['diu_2'], str(x['num_1']), str(x['num_2'])]), x['num_12']])\
    all_data = head_data_out.rdd.map(lambda x: ["\001".join([x['diu_1'], x['diu_2'], str(x['num_1']), str(x['num_2'])]), x['num_12']])\
        .reduceByKey(lambda a,b : a+b)\
        .map(get_total_num)
    total_data = spark.createDataFrame(all_data)
    total_data.createOrReplaceTempView("ucf_similarity")
    cols_out =['diu_1', 'diu_2', 'num_1', 'num_2','num_12']
    sql ="insert overwrite table da.recy_ucf_similarity_mid select %s from ucf_similarity" %",".join(cols_out)
    print sql
    spark.sql(sql)
    spark.stop()

def get_total_num(line):
    diu1_diu2, num_12 = line
    diu_1, diu_2, num_1, num_2 = diu1_diu2.strip().split("\001")[:4]
    num_1 = int(float(num_1))
    num_2 = int(float(num_2))
    return Row(diu_1=diu_1, diu_2=diu_2, num_1=num_1, num_2=num_2, num_12=num_12)


def get_total_num2(line):
    diu1_diu2, nums = line
    num_1=0
    num_2=0
    num_12=0
    for num_1_t, num_2_t, num_12_t in nums:
        num_1 +=num_1_t
        num_2 += num_2_t
        num_12 += num_12_t
    diu_1, diu_2 = diu1_diu2.strip().split("_")[:2]
    return Row(diu_1=diu_1, diu_2=diu_2, num_1=num_1, num_2=num_2, num_12=num_12)

def get_head_part(line):
    vid_part, (diu1_part, diu2_part) = line
    diu1, pv1= diu1_part
    diu2, pv2 = diu2_part
    if diu1==diu2:
        return None
    vid = vid_part.split("_")[0]
    return ["\001".join(map(str,[diu1, diu2, pv1, pv2])), set([vid])]

def get_co_nums(line):
    diu2diu , vids =line
    n = len(vids)
    diu1, diu2, pv1, pv2 = diu2diu.split("\001")[:4]
    pv1=int(float(pv1))
    pv2 =int(float(pv2))
    return Row(diu_1=diu1, diu_2=diu2, num_1=pv1, num_2=pv2, num_12=n)


if __name__ == "__main__":
    main()

