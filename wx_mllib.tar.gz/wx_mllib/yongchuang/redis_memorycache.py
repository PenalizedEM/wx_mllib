#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""redis、memorycahe工具
@Time    : '2017/12/27 下午2:59'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'redis_memorycache.py'
"""
import redis
#import memcache
import datetime
import sys
import hadoop
import os

REDIS_HOST= "10.10.191.217"
REDIS_PORT = "6379"

MC_HOST="10.10.191.217"
MC_PORT = "11211"

def init_redis(host = REDIS_HOST, port = REDIS_PORT):
    pool = redis.ConnectionPool(host=host, port=port, decode_responses=True)
    r = redis.Redis(connection_pool=pool)
    return r

def init_redis_online(host=REDIS_HOST, port=REDIS_PORT):
    r = redis.StrictRedis(host = host, port = port, socket_timeout=1000)
    return r

def init_mc():
    mc = memcache.Client([":".join([MC_HOST, MC_PORT])], debug=0)
    return mc


def loadhdfs2redis(dir, model_day=None, dir_need_day=True ,\
                   filename='./data2redis', key_redis='r_', host=REDIS_HOST, port=REDIS_HOST):
    if not dir.endswith("/") and dir_need_day:
        dir += "/"
    if dir_need_day and model_day is None:
        model_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
        dir += model_day
    r = init_redis_online(host, port)
    hadoop.getmerge(dir, filename)
    quality_data = []
    rank = 0
    with open(filename, "r") as f:
        for line in f:
            quality_data.append((key_redis, line.strip(), rank))
            rank += 1
    sorted_quality = sorted(quality_data, key=lambda x: x[2], reverse=True)
    quality_redis = map(lambda x: (x[0], x[1]), sorted_quality)
    loaddata2redis(r, quality_redis, key_redis=key_redis)
    #os.system("rm -fr %s" %filename)


def loaddata2redis(r, data, tag='talent', overwrite=True, key_redis = None):
    """将data的数据倒入到redis
    """
    p = r.pipeline(transaction=False)
    if key_redis is None:
        if tag == 'talent':
            key_redis = "r_quality_vids"
        elif tag == 'query':
            key_redis = "r_query_vids"
    if overwrite and key_redis is not None:
        r.delete(key_redis)
    num = 0
    start_job = datetime.datetime.now()
    print "job start %s" % (start_job.strftime("%Y-%m-%d %H:%m:%s"))
    for key, value in data:
        p.lpush(key, value)
        num += 1
        if num % 1000 == 0:
            print "%d num done %s\n" % (num, datetime.datetime.now().strftime("%Y-%m-%d %H:%m:%s"))
            p.execute()
            p.expire(key, 60*60*24*7)
    p.execute()
    end_job = datetime.datetime.now()
    print "job has %d,eclapse %f hours" % (num, (end_job - start_job).seconds * 1.0 / 3600)


def loadfile2redis(r, file, prefix="r_diu_", is_set=False):
    """到文件导入到redis中
    """
    p = r.pipeline(transaction=False)
    num =0
    start_job = datetime.datetime.now()
    print "job start %s" %(start_job.strftime("%Y-%m-%d %H:%m:%s"))
    with open(file) as f:
        for line in f:
            [key, value]= line.strip().split(",", 1)
            if prefix and is_set:
                p.lpush(prefix+key, value)
            elif prefix:
                p.set(prefix+key, value)
            elif is_set:
                p.lpush(key, value)
            else:
                p.set(key, value)
            num +=1
            if num %1000==0:
                print "%d num done %s\n" %(num, datetime.datetime.now().strftime("%Y-%m-%d %H:%m:%s"))
                p.execute()
        p.execute()
    end_job = datetime.datetime.now()
    print "job has %d,eclapse %f hours" %(num, (end_job-start_job).seconds*1.0/3600)

def loadfile2redisset(r, filename, set_loc, prefix=None, is_overwrite=True):
    p = r.pipeline(transaction=False)
    num =0
    start_job = datetime.datetime.now()
    print "job start %s" %(start_job.strftime("%Y-%m-%d %H:%m:%s"))
    if is_overwrite and set_loc:
        r.delete(set_loc)
    with open(filename) as f:
        for line in f:
            key = line.strip().split(",")[0]
            if prefix:
                key += prefix
            p.sadd(set_loc, key)
            num +=1
            if num %1000==0:
                print "%d num done %s\n" %(num, datetime.datetime.now().strftime("%Y-%m-%d %H:%m:%s"))
                p.execute()
        p.execute()
    end_job = datetime.datetime.now()
    print "job has %d,eclapse %f hours" %(num, (end_job-start_job).seconds*1.0/3600)


def loadfile2mc(mc, file, prefix="r_vid_"):
    num =0
    start_job = datetime.datetime.now()
    print "job start %s" %(start_job.strftime("%Y-%m-%d %H:%m:%s"))
    with open(file) as f:
        for line in f:
            [key, value]= line.strip().split(",", 1)
            mc.set(prefix+key, value)
            num +=1
            if num %1000==0:
                print "%d num done %s\n" %(num, datetime.datetime.now().strftime("%Y-%m-%d %H:%m:%s"))
        end_job = datetime.datetime.now()
        print "job has %d,eclapse %f hours" %(num, (end_job-start_job).seconds*1.0/3600)

def main():
    if len(sys.argv)!=3:
        print " errr, please input file and service"
    else:
        mode, file = sys.argv
        if mode=="redis":
            r=init_redis()
            loadfile2redis(r, file)
        else:
            mc = init_mc()
            loadfile2mc(mc, file)




if __name__ == "__main__":
    main()


