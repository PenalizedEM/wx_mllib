#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/4/21 上午11:41'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'redis_online.py'
"""

import sys
import argparse
import hadoop
from optparse import OptionParser
import datetime
from pyspark.sql import Row,SparkSession
import redis
from random import choice
from ast import literal_eval

def hdfs2redis_set(rdd, nums, nodes, port, expire, is_key_overwrite, save_nums):
    def storeToRedis(rdd):
        index = 0
        while (index < 3):
            try:
                index = index + 1
                r = redis.StrictRedis(host=choice(nodes), port=port, socket_timeout=10000)
                p = r.pipeline(transaction=False)
                for uid_list in rdd:
                    uid, item_list = uid_list
                    if is_key_overwrite:
                        r.delete(uid)
                    if save_nums > 1:
                        item_save = ",".join(item_list[:save_nums])
                    elif save_nums == 1:
                        item_save = item_list[0]
                    elif save_nums == -1:
                        item_save = ",".join(item_list[::save_nums])
                    p.set(uid, item_save)
                    p.expire(uid, expire)
                    p.execute()
                break
            except Exception as e:
                print 'storeToRedis error, index :' + str(index)
                sys.stderr.write("%s \n" % e)
    return rdd.repartition(nums).foreachPartition(storeToRedis)

def hdfs2redis_new(rdd, nums, nodes, port, expire, is_key_overwrite, size, save_nums):
    def storeToRedis(rdd):
        index = 0
        while (index < 3):
            try:
                index = index + 1
                r = redis.StrictRedis(host=choice(nodes), port=port, socket_timeout=10000)
                p = r.pipeline(transaction=False)
                for uid_list in rdd:
                    uid, item_list = uid_list
                    if is_key_overwrite:
                        r.delete(uid)
                    nn = 0
                    for item in item_list:
                        if save_nums < 0 or save_nums >1:
                            p.lpush(uid, ",".join(item[:save_nums]))
                        elif save_nums==1:
                            p.lpush(uid, item[0])
                        nn += 1
                        if nn % 200 == 0:
                            p.expire(uid, expire)
                            p.execute()
                    if size > 2:
                        p.ltrim(uid, 0, size-1)
                    p.expire(uid, expire)
                    p.execute()
                break
            except Exception as e:
                print 'storeToRedis error, index :' + str(index)
                sys.stderr.write("%s \n" % e)
    return rdd.repartition(nums).foreachPartition(storeToRedis)

def hdfs2redis(rdd, nums, nodes, port, expire, is_key_overwrite):
    def storeToRedis(rdd):
        index = 0
        while (index < 3):
            try:
                index = index + 1
                r = redis.StrictRedis(host=choice(nodes), port=port, socket_timeout=10000)
                p = r.pipeline(transaction=False)
                for uid_list in rdd:
                    uid, item_list = uid_list
                    if is_key_overwrite:
                        r.delete(uid)
                    nn = 0
                    for item in item_list:
                        p.lpush(uid, ",".join(item))
                        nn += 1
                        if nn % 200 == 0:
                            p.expire(uid, expire)
                            p.execute()
                    p.expire(uid, expire)
                    p.execute()
                break
            except Exception as e:
                print 'storeToRedis error, index :' + str(index)
                sys.stderr.write("%s \n" % e)
    return rdd.repartition(nums).foreachPartition(storeToRedis)



def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--input", dest="input", default=None, help="load hdfs dir 2 redis")
    parser.add_option("--host", dest="host", default="10.19.159.154,10.19.86.178", help="redis host, comma partition for hosts")
    parser.add_option("--port",dest="port" ,default="6379", help="redis port")
    parser.add_option("--expire",dest="expire" ,default=7,type="int" ,help="key expire days")
    parser.add_option("--sep", dest="sep", default=",", help="field segmentation")
    parser.add_option("--key_field",dest="key_field",default=1,type="int",help="the number of  field for key")
    parser.add_option("--key_overwrite",dest="key_overwrite",default=True,help="whether overwrite key: defalut True")
    parser.add_option("--sort_field",dest="sort_field",default=4, type="int", help="the number of  field for sorted")
    parser.add_option("--asc",dest="asc", default=True, help="short field True:ASC, False:desc")
    parser.add_option("--prefix", dest="prefix", default="", help="key prfex to redis")
    parser.add_option("--partition_num",dest="partition_num",default=200,type="int", help="redis nums")
    parser.add_option("--user", dest= "user",default="caoyc", help="user email to submit job")
    parser.add_option("--size", dest= "size",default=0, help="list size")
    parser.add_option("--save_nums", dest= "save_nums",default=4, help="save to redis fields nums")
    parser.add_option("--is_set", dest= "is_set",default=False, help="setget redis data")
    (flags, args) = parser.parse_args(args)
    if flags.sep=="001" or flags.sep=="\001":
        flags.sep=literal_eval("'%s'" %"\001")
    elif flags.sep=="b" or flags.sep=="black":
        flags.sep=" "
    print flags.sep
    if flags.asc =="False" or flags.asc =="F":
        flags.asc=False
    print flags.asc
    if flags.key_overwrite in ['F', 'False','f']:
        flags.key_overwrite = False
    if flags.is_set in ['F', 'False','f']:
        flags.is_set = False
    elif flags.is_set in ['T', 'True','t']:
        flags.is_set = True
    ## parse = argparse.ArgumentParser()
    # parse.add_argument("--input", default=None, help="load hdfs dir 2 redis")
    # parse.add_argument("--host",  default="10.19.112.202", help="redis host, comma partition for hosts")
    # parse.add_argument("--port", default="6379", help="redis port")
    # parse.add_argument("--expire", default=3,type=int ,help="key expire days")
    # parse.add_argument("--sep", default=",", help="field segmentation")
    # parse.add_argument("--key_field", default=1, help="the number of  field for key")
    # parse.add_argument("--sort_field", default=4, help="the number of  field for sorted")
    # parse.add_argument("--asc", default=True,type=str2bool, help="short field True:ASC, False:desc")
    # parse.add_argument("--prefix", default="", help="key prfex to redis")
    # parse.add_argument("--partition_num", default=200,type=int, help="redis nums")
    # parse.add_argument("--user", default="caoyc", help="user email to submit job")
    # flags, unparsed = parse.parse_known_args(sys.argv[1:])
    if flags.input is None:
        print "please input hdfs dir to redis"
        sys.exit(-1)
    spark = SparkSession.builder.master('yarn-client')\
        .appName('load2redis:' + inDate).config('spark.sql.warehouse.dir','/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    #if hadoop.is_file_exist(flags.input+"/_SUCCESS") !=0:
    #    print "input hdfs dir is not exist, please check it"
    dir = flags.input
    print "job start %s" %(dir)
    hosts = flags.host.strip().split(",")
    expire = int(float(flags.expire))*60*60*24
    if flags.is_set:
        sorted_data = load_data(spark, dir, flags.key_field, flags.prefix, flags.sep)
        hdfs2redis_set(sorted_data, flags.partition_num, hosts, \
                       flags.port, expire, flags.key_overwrite, int(float(flags.save_nums)))
    else:
        sorted_data = load_sort_data(spark, dir, flags.key_field, flags.sort_field, flags.asc, flags.prefix, flags.sep)
        hdfs2redis_new(sorted_data, flags.partition_num, hosts, \
               flags.port, expire, flags.key_overwrite, int(float(flags.size)), int(float(flags.save_nums)))

def load_data(spark, dir, key_num, prefix, sep):
    def parse_data(line):
        segment = line.encode("utf-8").strip().split(sep)
        if len(segment)< key_num:
            return None
        if prefix:
            key = prefix + segment[key_num -1]
        else:
            key = segment[key_num -1]
        index = range(len(segment))
        index.remove(key_num-1)
        value = [segment[i] for i in index]
        return [key, list(value)]
    sc = spark.sparkContext
    filter_data = sc.textFile(dir).map(parse_data)\
        .filter(lambda x: x is  not None)
    return filter_data



def load_sort_data(spark, dir, key_num, sorted_num,is_asc, prefix, sep):
    def parse_data(line):
        segment = line.encode("utf-8").strip().split(sep)
        if len(segment)< max(key_num, sorted_num):
            return None
        if prefix:
            key = prefix + segment[key_num -1]
        else:
            key = segment[key_num -1]
        index = range(len(segment))
        index.remove(key_num-1)
        value = [segment[i] for i in index]
        return [key, tuple(value)]
    def sorted_data(line):
        key, items = line
        sorted_item = sorted(items, key=lambda x: float(x[sorted_filed]), reverse=is_asc)
        return [key, sorted_item]
    sc = spark.sparkContext
    sorted_filed =  sorted_num -1 if sorted_num < key_num else sorted_num -2
    filter_data = sc.textFile(dir).map(parse_data)\
        .filter(lambda x: x is  not None)
    # 数据为空要判断
    return filter_data.groupByKey().map(sorted_data)


def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')




if __name__ == '__main__':
    main()

