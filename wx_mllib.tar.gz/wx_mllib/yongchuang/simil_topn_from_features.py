#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""基于视频及提取的features,计算每个视频的topn相似度列表
@Time    : '2018/7/9 下午3:45'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'simil_topn_from_features.py'
"""
import hadoop
from optparse import OptionParser
import datetime
import sys
import datetime
import os
import hadoop
from annoy import AnnoyIndex
import log


WORD2VEC_SIMIL_DIR = "/olap/da/word2vec_item2item/"
WORD2VEC_FEATURE_DIR = "/olap/da/word2vec_feature/"
LIFE_WORD2VEC_SIMIL_DIR = "/olap/da/life_word2vec_item2item/"
LIFE_WORD2VEC_FEATURE_DIR = "/olap/da/life_word2vec_feature/"
SVD_FEATURE_DIR = "/olap/da/svd_itfeature/"
SVD_SIMIL_DIR = "/olap/da/svd_item2item/"
NODE2VEC_FEATURE_DIR = "/olap/da/node2vec_feature/"
NODE2VEC_SIMIL_DIR = "/olap/da/node2vec_item2item/"
LIFE_NODE2VEC_FEATURE_DIR = "/olap/da/life_node2vec_feature/"
LIFE_NODE2VEC_SIMIL_DIR = "/olap/da/life_node2vec_item2item/"
MODEL= 'word2vec'
SIZE= 64
TOPN= 18


def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    mode_day = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    parser = OptionParser()
    parser.add_option("--feature_dir", dest="feature_dir", default=None, help="item features dir")
    parser.add_option("--item2item_dir", dest="item2item_dir", default=None, help="item simil dir")
    parser.add_option("--date", dest="date", default=mode_day, help="features date")
    parser.add_option("--model", dest="model", default=MODEL, help="which model features to load")
    parser.add_option("--size", dest="size", default=SIZE, help="feature size")
    parser.add_option("--topn", dest="topn", default=TOPN, help="item simil nums")
    (flags, args) = parser.parse_args(args)
    if flags.feature_dir:
        feature_hdfs = flags.feature_dir + flags.date
    else:
        if flags.model == "word2vec":
            feature_hdfs = WORD2VEC_FEATURE_DIR + flags.date
        elif flags.model == "svd":
            feature_hdfs = SVD_FEATURE_DIR + flags.date
        elif flags.model == "node2vec":
            feature_hdfs = NODE2VEC_FEATURE_DIR + flags.date
        elif flags.model == "life_word2vec":
            feature_hdfs = LIFE_WORD2VEC_FEATURE_DIR + flags.date
        elif flags.model == "life_node2vec":
            feature_hdfs = LIFE_NODE2VEC_FEATURE_DIR + flags.date
    old_day = (datetime.datetime.today() - datetime.timedelta(3)).strftime("%Y-%m-%d")
    if flags.item2item_dir:
        item2item_hdfs = flags.item2item_hdfs + flags.date
        item2item_hdfs_old = flags.item2item_hdfs + old_day
    else:
        if flags.model == "word2vec":
            item2item_hdfs_old = WORD2VEC_SIMIL_DIR + old_day
            item2item_hdfs = WORD2VEC_SIMIL_DIR + flags.date
        elif flags.model == "svd":
            item2item_hdfs_old = SVD_SIMIL_DIR + old_day
            item2item_hdfs = SVD_SIMIL_DIR + flags.date
        elif flags.model == "node2vec":
            item2item_hdfs_old = NODE2VEC_SIMIL_DIR + old_day
            item2item_hdfs = NODE2VEC_SIMIL_DIR + flags.date
        elif flags.model == "life_word2vec":
            item2item_hdfs_old = LIFE_WORD2VEC_SIMIL_DIR + old_day
            item2item_hdfs = LIFE_WORD2VEC_SIMIL_DIR + flags.date
        elif flags.model == "life_node2vec":
            item2item_hdfs_old = LIFE_NODE2VEC_SIMIL_DIR + old_day
            item2item_hdfs = LIFE_NODE2VEC_SIMIL_DIR + flags.date
    global model_id
    if flags.model in ["word2vec", "life_word2vec"]:
        model_id='14'
    elif flags.model == "svd":
        model_id = '15'
    elif flags.model in ['node2vec', "life_node2vec"]:
        model_id = '16'
    log_file= "simil_topn_from_features_"+ flags.date
    log_dir_file ="./log/" + log_file
    logger = log.mylog(logFile=log_dir_file).get_log()
    logger.info('%s job start' % log_file)
    prefix = "./data/"
    local_file = prefix + flags.model+"_" + flags.date
    hadoop.getmerge(feature_hdfs, local_file)
    if not os.path.exists(local_file):
        logger.error("local file don't exist")
        exit(1)
    model_dir = prefix + flags.model+ "_" + flags.date + "_model"
    topn_dir = prefix + flags.model+ "_" + flags.date + "_topn"
    logger.info("model train job start")
    index2vid = build_model(local_file, model_dir, int(float(flags.size)))
    logger.info("model train job end")
    logger.info("vids nums is %d " %len(index2vid.keys()))
    logger.info("topn simil job start")
    build_simil_topn(index2vid, model_dir,topn_dir,feature_size=int(float(flags.size)),topn=int(float(flags.topn)))
    logger.info("topn simil job end")
    hadoop.rm_dir(item2item_hdfs)
    hadoop.rm_dir(item2item_hdfs_old)
    hadoop.mkdir(item2item_hdfs)
    if hadoop.put(topn_dir, item2item_hdfs)==0:
        os.system("rm %s" %local_file)
        os.system("rm %s" %topn_dir)
    logger.info('%s job end' %log_file)


def build_model(local_data, model_dir,feature_size, num_tree=10):
    model = AnnoyIndex(feature_size)
    vid2index = dict()
    index2vid = dict()
    index =0
    with open(local_data) as f:
        for line in f:
            vid,feature = line.strip().split("\t")[:2]
            if vid not in vid2index.keys():
                vid2index[vid] = index
                index2vid[index]=vid
            else:
                continue
            features = feature.strip().split(",")
            if len(features)!= feature_size:
                continue
            else:
                index +=1
                features = map(lambda x: float(x), features)
                model.add_item(vid2index[vid], features)
    model.build(num_tree)
    model.save(model_dir)
    return index2vid


def build_simil_topn(index2vid, model_dir, save_dir, feature_size ,topn):
    model = AnnoyIndex(feature_size)
    model.load(model_dir)
    print "num is %d " %model.get_n_items()
    with open(save_dir, "w") as f:
        for index, vid in index2vid.iteritems():
            topn_simil = model.get_nns_by_item(index, topn, search_k=300 ,include_distances=True)
            vid_nei, simil = topn_simil
            vid_simil = zip(vid_nei, simil)
            vid_simil = filter(lambda x: x[0]!=index, vid_simil)
            vid_simil =sorted(vid_simil, key=lambda x: x[1],reverse=False)
            rank = 0
            for vid_nei, simil in vid_simil:
                f.write("\t".join(map(str, [vid, index2vid[vid_nei], simil, rank, model_id])) +"\n")
                rank +=1

if __name__ == "__main__":
    main()



