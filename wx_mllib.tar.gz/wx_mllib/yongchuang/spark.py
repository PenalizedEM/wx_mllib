# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
File:'spark.py'
Author:'caoyongchuang(caoyongchuang@mia.com)'
Date:'2016/1/10 22:53'
"""
import logging
import os
import sys
from optparse import OptionParser
import log
import datetime


SPARK_BIN = '/home/hadoop/spark/bin/spark-submit '
EXE_MEMORY = '15G'
NUM_EXE = 50
EXE_CORES = 8
DRIVER_MEMORY = '2G'

#yarn 集群 或者standalone 集群
MASTER = {"yarn": "yarn", "recommend": "spark://recommend-18:7077"}

def spark_submit(master=MASTER.get("yarn"),
                 py_files=None,
                 name=None,
                 conf=None,
                 exe_memory=EXE_MEMORY,
                 exe_cores=EXE_CORES,
                 num_exe=NUM_EXE,
                 main_file=None,
                 main_argv=None,
                 files=None,
                 driver_memory=DRIVER_MEMORY
                 ):
    log_file = main_file.strip().split(".")[0] + "_" +datetime.datetime.today().strftime("%Y-%m-%d")
    log_dir = "./log/"
    cwd = os.getcwd() + "/"
    cmd = SPARK_BIN + ' '
    cmd += "--master %s " %master
    cmd += "--deploy-mode client "
    cmd += "--queue %s " %"root.spark"
    cmd += "--executor-memory %s " %exe_memory
    cmd += "--driver-memory %s " %driver_memory
    #cmd += "--conf 'spark.executor.extraJavaOptions=-XX:+PrintGCDetails -XX:+PrintGCTimeStamps' "
    #cmd +="--conf spark.memory.fraction=0.85 "
    #cmd +="--conf spark.memory.storageFraction=0.3 "
    #cmd += "--conf spark.yarn.executor.memoryoverhead=6140 "
    #cmd +="--conf '%s' " %"spark.executor.extraJavaOptions=-XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled -XX:+ParallelRefProcEnabled -XX:+CMSClassUnloadingEnabled -XX:MaxTenuringThreshold=31 -XX:SurvivorRatio=8 -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintGCTimeStamps -XX:+PrintHeapAtGC -XX:+HeapDumpOnOutOfMemoryError -verbose:gc"
    if name:
        cmd += "--name %s " %name
    if exe_cores:
        cmd += "--executor-cores %s " %exe_cores
    if num_exe:
        cmd += "--num-executors %s " %num_exe
    if files:
        cmd += "--files %s " %files
    if py_files:
        cmd += "--py-files %s " % ",".join(map(lambda x: cwd + x, py_files))
    if conf:
        for conf_one in conf:
         cmd += "--conf %s " %conf_one
    if main_file:
        cmd += "%s" %cwd + main_file
        if main_argv:
            cmd +=" %s" %" ".join(main_argv)
    #cmd += '>> %s 2>&1 ' %(log_dir+log_file)
    print cmd
    #os.system(cmd)
    log.check_sucess(log_dir, log_file, cmd)


def main():
    if len(sys.argv) == 2:
        main_file_input = sys.argv[1]
        spark_submit(main_file=main_file_input)
    elif len(sys.argv) == 3:
        main_file_input = sys.argv[1]
        py_files_input = None
        if sys.argv[2] != '1':
            py_files_input = sys.argv[2].split(",")
        spark_submit(main_file=main_file_input, py_files=py_files_input)
    else:
        main_file_input = sys.argv[1]
        py_files_input = None
        if sys.argv[2] != '1':
            py_files_input = sys.argv[2].split(",")
        print "pyfiles %s" %py_files_input
        main_argv_input = sys.argv[3:]
        spark_submit(main_file=main_file_input, py_files=py_files_input, main_argv=main_argv_input)

def use():
    useage = """
    %prog [options] main_file py_files main_argv files
    """
    parser = OptionParser(usage=useage)
    parser.add_option("-m", "--main_file", dest="main_file", default=False,
                      help="main python file to execute")
    parser.add_option("-f", "--files", dest="files", default=None,
                      help="other python files to load")
    parser.add_option("-p", "--pyfiles", dest="py_files", default=None,
                      help="dependent python files to load")
    parser.add_option("-a", "--main_argv", dest="main_argv", default=None,
                      help="main argv")
    parser.add_option("-c", "--conf_argv", dest="conf_argv", default=None,
                      help="conf argv")
    parser.add_option("-e", "--executor_memory", dest="executor_memory", default=EXE_MEMORY,
                      help="executor-memory")
    parser.add_option("-r", "--exe_cores", dest="executor_cores", default=EXE_CORES,
                      help="executor-cores")
    parser.add_option("-n", "--num_executors", dest="num_executors", default=NUM_EXE,
                      help="num-executors")
    parser.add_option("-d", "--driver_memory", dest="driver_memory", default=DRIVER_MEMORY,
                      help="driver_memory")
    (options, args) = parser.parse_args()
    if options.py_files:
        options.py_files = options.py_files.split(",")
    if options.main_argv:
        options.main_argv = options.main_argv.split(",")
    if options.conf_argv:
        options.conf_argv=options.conf_argv.split(",")
    if len(args) >= 1:
        if not options.main_file:
            options.main_file = args[0]
            args.remove(args[0])
        if len(args) > 0:
            options.main_argv.extend(args)
    spark_submit(main_file=options.main_file,
                 py_files=options.py_files,
                 main_argv=options.main_argv,
                 files=options.files,
                 conf=options.conf_argv,
                 exe_memory=options.executor_memory,
                 exe_cores=options.executor_cores,
                 num_exe=options.num_executors,
                 driver_memory = options.driver_memory
                 )

if __name__ == "__main__":
    use()



