CREATE EXTERNAL TABLE IF NOT EXISTS dw.litebigger(
  u_timestamp STRING COMMENT '东八区时间',
    u_backtime STRING COMMENT 'php层响应时间',
    u_responsetime STRING COMMENT '完整服务响应时间',
    u_host STRING COMMENT '服务器内网ip',
    u_xff STRING COMMENT '客户端ip',
    u_http_host STRING COMMENT '负载均衡',
    u_clientip STRING COMMENT '内网客户ip',
    u_referer STRING COMMENT '请求来源',
    u_status STRING COMMENT 'http状态',
    u_size STRING COMMENT 'http返回大小',
    u_url STRING COMMENT '请求URL头部',
    u_verb STRING COMMENT 'HTTP协议版本号',
    u_method STRING COMMENT 'http方法',
    u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本', -- wv或者version字段
    u_c STRING COMMENT '客户端渠道代码',
    u_userid STRING COMMENT '微信小程序的用户id',
    u_mod STRING COMMENT '服务端接口模块',
    u_ac STRING COMMENT '服务端具体接口',
    u_uuid STRING COMMENT '用户设备号(微信openid)',
    u_agent STRING COMMENT '客户端agent',
    u_key STRING COMMENT '搜索关键词',
    u_source STRING COMMENT '用户来源',
    u_vid STRING COMMENT '视频的id',
    u_sw STRING COMMENT '屏幕尺寸——宽',
    u_sh STRING COMMENT '屏幕尺寸——高',
    u_width STRING COMMENT '可使用窗口宽度',
    u_height STRING COMMENT '可使用窗口高度',
    u_sbh STRING COMMENT '状态栏的高度',
    u_lg STRING COMMENT '微信设置的语言',
    u_wv STRING COMMENT '微信版本号',
    u_wvv STRING COMMENT 'u_wvv',
    u_pr STRING COMMENT 'u_pr',
    u_device STRING COMMENT '操作系统版本',
    u_fs STRING COMMENT '用户字体大小设置。以“我-设置-通用-字体大小”中的设置为准，单位：px',
    u_sdkv STRING COMMENT '客户端基础库版本',
    u_nt STRING COMMENT '网络类型',
    u_no STRING COMMENT '网络运营商',
    u_lon STRING COMMENT '用户位置——经度',
    u_lat STRING COMMENT '用户位置——纬度',
    u_province STRING COMMENT '用户省份',
    u_city STRING COMMENT '用户城市',
    u_model STRING COMMENT '手机型号',
    u_brad STRING COMMENT '手机品牌',
    u_bigger_json STRING COMMENT '其他字段'
)
COMMENT '小程序用户行为大表'
PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dw/litebigger/';
ALTER TABLE dw.litebigger drop IF EXISTS PARTITION (dt='${datebuf}');
ALTER TABLE dw.litebigger ADD IF NOT EXISTS PARTITION (dt='${datebuf}') LOCATION '/olap/dw/litebigger/dt=${datebuf}';
