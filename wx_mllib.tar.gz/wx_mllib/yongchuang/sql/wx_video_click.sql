use edw;

-- 视频点击

CREATE EXTERNAL TABLE IF NOT EXISTS edw.wx_video_click(
    -- 请求信息
    u_timestamp TIMESTAMP COMMENT '东八区时间',
    u_backtime FLOAT COMMENT 'php层响应时间',
    u_responsetime FLOAT COMMENT '完整服务响应时间',
    u_host STRING COMMENT '服务器内网ip',
    u_status STRING COMMENT 'http状态',
    u_size INT COMMENT 'http返回大小',
    u_agent STRING COMMENT '客户端agent',
    u_method STRING COMMENT 'http方法',
    u_http_host string  COMMENT '负载均衡'  ,
    u_clientip  string  COMMENT '客户ip'    ,
    u_url   string  COMMENT '请求URL头部'   ,
    u_verb  string  COMMENT 'HTTP协议版本号' ,

    -- 必传通用字段
    u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
    u_mod STRING COMMENT '服务端接口模块',
    u_ac STRING COMMENT '服务端具体接口',
    u_uuid STRING COMMENT '用户设备号(微信openid)',
    u_userid STRING COMMENT '小程序用户id(后台用户数据库自增id)',
    u_appname STRING COMMENT '小程序应用名,gcw：广场舞 yangsheng 养生 jianfei 减肥 meishi 美食',
    u_dic string  COMMENT '客户端渠道代码-外链'    ,
    u_sw    string  COMMENT '屏幕尺寸——宽'   ,
    u_sh    string  COMMENT '屏幕尺寸——高'   ,
    u_wv    string  COMMENT '微信版本号' ,
    u_client   string  COMMENT '客户端平台' ,
    u_osv STRING COMMENT '操作系统版本',
    u_s_uuid STRING COMMENT '分享人的uuid',
    u_s_appuid STRING COMMENT '分享人的APP的uid，来自u_share_uuid',
    u_s_appdiu STRING COMMENT '分享人的APP的diu，来自u_share_uuid',
    u_lon STRING COMMENT '用户位置——经度',
    u_lat STRING COMMENT '用户位置——纬度',
    u_province STRING COMMENT '用户省份',
    u_city STRING COMMENT '用户城市',
    u_model STRING COMMENT '手机型号',
    u_sdkv  string  COMMENT '客户端基础库版本'  ,
    u_nt    string  COMMENT '网络类型'  ,
    u_brad  string  COMMENT '手机品牌'  ,
    u_lg   string  COMMENT '微信设置的语言'  ,
    u_fs   string  COMMENT '用户字体大小设置。以“我-设置-通用-字体大小”中的设置为准，单位：px'  ,
    u_abtag   string  COMMENT 'AB测试tag对openid取2次hash模100得到'  ,


    -- 接口特有字段
    u_vid STRING COMMENT '视频的id',
    u_page STRING COMMENT '视频所在的页面',
    u_module STRING COMMENT '视频所在的页面模块',
    u_keyword STRING COMMENT '搜索时有:用户搜索的关键词',
    u_page_num STRING COMMENT '用户请求的第几页',
    u_position STRING COMMENT '视频被点击的位置',
    u_rmodelid  string  COMMENT '展现的推荐排序模型id',
    u_rsource  string  COMMENT '展现的推荐排序数据源id',
    u_ruuid  string  COMMENT '展现的推荐排序请求的批次id',
    u_recsid  string  COMMENT '展现的推荐排序推荐位id',
    u_strategyid  string  COMMENT '展现的推荐排序策略id',
    u_rank  string  COMMENT '展现的推荐排序id',
    u_rtag  string  COMMENT '展现的推荐排序的标签',

    -- 其他字段
    u_kv MAP<STRING,STRING> COMMENT '其他字段-map结构',

    -- 预留字段
    u_ptype STRING COMMENT '预留字段1',
    field2 STRING COMMENT '预留字段2',
    field3 STRING COMMENT '预留字段3',
    field4 STRING COMMENT '预留字段4',
    field5 STRING COMMENT '预留字段5'
)
COMMENT 'EDW——小程序视频点击'
PARTITIONED BY(dt STRING)
-- ROW FORMAT DELIMITED
-- FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/edw/wx_video_click';

set mapreduce.map.memory.mb=2048;
insert OVERWRITE table edw.wx_video_click PARTITION(dt='${datebuf}')
select
        -- 请求信息
        u_timestamp,
        u_backtime,
        u_responsetime,
        u_host,
        u_status,
        u_size,
        u_agent,
        u_method,
        u_http_host ,
        u_clientip  ,
        u_url   ,
        u_verb  ,

    -- 必传通用字段
        if(u_div rlike '^\\d+(\\.\\d+)*$',u_div,null) u_div,
        u_mod,
        u_ac,
        if(u_uuid rlike '^[\\w-]{10,50}$',u_uuid,null) u_uuid,
        if(u_userid rlike '^(0|[1-9][0-9]*)$', u_userid, null) u_userid,
        case when get_json_object(u_bigger_json,'$.u_appname') rlike '^[\\w+-]+$'
                then get_json_object(u_bigger_json,'$.u_appname')
           when u_mod in ('jianfei','meishi','yangsheng','gaoxiao','yuer','move') then u_mod
           else 'squaredance'
        end as u_appname,
        if(u_c rlike '^[\\w-]+$', u_c, null) u_dic,
        if(u_sw rlike '^(0|[1-9][0-9]*)$', u_sw, null) u_sw,
        if(u_sh rlike '^(0|[1-9][0-9]*)$', u_sh, null) u_sh,
        if(u_wv rlike '^\\d+(\\.\\d+)*$',u_wv,null) u_wv,
        if(u_wvv rlike '^\\w+$',u_wvv,null) u_client  ,
        if(reflect('java.net.URLDecoder', 'decode', u_device, 'UTF-8') rlike '^[\\d\\s\\w]+(\\.\\d+)*$', 
        reflect('java.net.URLDecoder', 'decode', u_device, 'UTF-8'),null) u_osv ,
        if(get_json_object(u_bigger_json,'$.u_s') rlike '^[\\w+-]+$'and get_json_object(u_bigger_json,'$.u_s') not  like 'uid-%'and 
        get_json_object(u_bigger_json,'$.u_s') not  like 'diu-%', get_json_object(u_bigger_json,'$.u_s'), null)  u_s_uuid ,
        if(get_json_object(u_bigger_json,'$.u_s') rlike '^[\\w+-]+$', split(get_json_object(u_bigger_json,'$.u_s'), 'uid-')[1], null) u_s_appuid ,
        if(get_json_object(u_bigger_json,'$.u_s') rlike '^[\\w+-]+$', split(get_json_object(u_bigger_json,'$.u_s'),'diu-')[1],null) u_s_appdiu ,
        if(u_lon rlike '^(-?\\d+)(\\.\\d+)?$', u_lon, null) u_lon,
        if(u_lat rlike '^(-?\\d+)(\\.\\d+)?$', u_lat, null) u_lat,
        if(reflect('java.net.URLDecoder', 'decode', u_province, 'UTF-8') rlike '^[\\u4e00-\\u9fa5]+$', reflect('java.net.URLDecoder', 'decode', u_province, 'UTF-8'),         null) u_province,
        if(reflect('java.net.URLDecoder', 'decode', u_city, 'UTF-8') rlike '^[\\u4e00-\\u9fa5]+$', reflect('java.net.URLDecoder', 'decode', u_city, 'UTF-8'), 
        null) u_city,
        if(reflect('java.net.URLDecoder', 'decode', u_model, 'UTF-8') rlike '^[\\*\\w\\s+-<>,()\\u4e00-\\u9fa5]+$' , reflect('java.net.URLDecoder', 'decode', 
        u_model,'UTF-8'), null) u_model,
        if(u_sdkv rlike '^\\d+(\\.\\d+)*$',u_sdkv,null) u_sdkv,
        if(u_nt rlike '^\\w+$', u_nt, null) u_nt,
        if(reflect('java.net.URLDecoder', 'decode', u_brad, 'UTF-8') rlike '^[\\*\\w\\s+-<>,()\\u4e00-\\u9fa5]+$' , reflect('java.net.URLDecoder', 'decode',
        u_brad, 'UTF-8'), null) u_brad,
        if(u_lg rlike '^\\w+$',u_lg,null) u_lg,
        if(u_fs rlike '^\\d+$',u_fs,null) u_fs,
        if(get_json_object(u_bigger_json,'$.u_abtag') rlike '^\\d+$',get_json_object(u_bigger_json,'$.u_abtag'),null) u_abtag,

        -- 接口特有字段
        if(u_vid rlike '^(0|[1-9][0-9]*)$', u_vid, null) u_vid,
        if(reflect('java.net.URLDecoder', 'decode', get_json_object(u_bigger_json,'$.u_page'), 'UTF-8') rlike '^[\\u4e00-\\u9fa5]+$', 
        reflect('java.net.URLDecoder', 'decode', get_json_object(u_bigger_json,'$.u_page'), 'UTF-8'), null) u_page ,
        if(reflect('java.net.URLDecoder', 'decode', get_json_object(u_bigger_json,'$.u_module'), 'UTF-8') rlike '^[\\u4e00-\\u9fa5]+$', 
        reflect('java.net.URLDecoder','decode', get_json_object(u_bigger_json,'$.u_module'), 'UTF-8'), null) u_module ,
        if(reflect('java.net.URLDecoder', 'decode', get_json_object(u_bigger_json,'$.u_keyword'), 'UTF-8') rlike '^[\\u4e00-\\u9fa5]+$', 
        reflect('java.net.URLDecoder', 'decode', get_json_object(u_bigger_json,'$.u_keyword'), 'UTF-8'), null) u_keyword ,
        if(get_json_object(u_bigger_json,'$.u_page_num') rlike  '^\\d+$', get_json_object(u_bigger_json,'$.u_page_num'), null) u_page_num ,
        if(get_json_object(u_bigger_json,'$.u_position') rlike  '^\\d+$', get_json_object(u_bigger_json,'$.u_position'), null) u_position ,
        if(get_json_object(u_bigger_json,'$.u_rmodelid') is not null,reflect('java.net.URLDecoder', 'decode', 
        get_json_object(u_bigger_json,'$.u_rmodelid'), 'UTF-8'),'') u_rmodelid,
        if(get_json_object(u_bigger_json,'$.u_rsource') is not null,reflect('java.net.URLDecoder', 'decode', 
        get_json_object(u_bigger_json,'$.u_rsource'), 'UTF-8'),'') u_rsource,
        if(get_json_object(u_bigger_json,'$.u_ruuid') is not null,reflect('java.net.URLDecoder', 'decode',
        get_json_object(u_bigger_json,'$.u_ruuid'), 'UTF-8'),'') u_ruuid,
        if(get_json_object(u_bigger_json,'$.u_recsid') is not null,reflect('java.net.URLDecoder', 'decode', 
        get_json_object(u_bigger_json,'$.u_recsid'), 'UTF-8'),'') u_recsid,
        if(get_json_object(u_bigger_json,'$.u_strategyid') is not null,reflect('java.net.URLDecoder', 'decode',
        get_json_object(u_bigger_json,'$.u_strategyid'), 'UTF-8'),'') u_strategyid,
        if(get_json_object(u_bigger_json,'$.u_rank') is not null,reflect('java.net.URLDecoder', 'decode', 
        get_json_object(u_bigger_json,'$.u_rank'), 'UTF-8'),'') u_rank,
        if(get_json_object(u_bigger_json,'$.u_rtag') is not null,reflect('java.net.URLDecoder', 'decode',
        get_json_object(u_bigger_json,'$.u_rtag'), 'UTF-8'),'') u_rtag,

        -- 其他字段
        str_to_map(''),

        -- 预留字段
        if(get_json_object(u_bigger_json,'$.u_ptype') is not null,reflect('java.net.URLDecoder', 'decode', 
        get_json_object(u_bigger_json,'$.u_ptype'), 'UTF-8'),'') u_ptype,
        '' field2,
        '' field3,
        '' field4,
        '' field5

  from dw.litebigger
  where dt='${datebuf}'
  and  concat(u_mod,'-',u_ac)='log-video_click';

dfs -touchz /dw/edw/wx_video_click/dt=${datebuf}/_SUCCESS ;
