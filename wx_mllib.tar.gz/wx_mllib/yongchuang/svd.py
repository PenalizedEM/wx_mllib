#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""基于svd分解，获取item2item相似度
@Time    : '2018/6/20 上午11:07'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'svd.py.py'
"""

import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import random
import util
import hadoop
import sys
import recommder
import numpy as np
#from pyspark.mllib.recommendation import ALS
from pyspark.ml.recommendation import ALS
from optparse import OptionParser


# als模型相关
# 特征值个数
RANK = 50
# 迭代次数
ITERATIONS_NUMS = 20

# item2item的相似邻居的个数
NEIGHBOURS = 50
# 用户推荐商品个数
RECOMMED_NUMS = 100
# 用于个性化计算用户的相似度
HIGH_NEIGHBOURS= 30

# user cf视频相似度模型id
SIMIL_MODE_ID = "13"
# user cf个性化推荐列表
PERSONAL_MODE_ID = "23"
# svd 特征表
SVD_USFEATURE_DIR = "/olap/da/svd_usfeature/"
SVD_ITFEATURE_DIR = "/olap/da/svd_itfeature/"
# svd item2item 相似度表
SVD_ITEM2ITEM_DIR= "/olap/da/svd_item2item/"
# svd个性化列表
SVD_PERSONAL_DIR="/olap/da/svd_personal/"
UPDATE_ITEM_SIMIL=True

INPUT_DIR=""


def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--uvr_dir", dest="uvr_dir", default=INPUT_DIR, help="user item pref dir")
    parser.add_option("--item2item_dir", dest="item2item_dir", default=SVD_ITEM2ITEM_DIR, help="svd item simil dir")
    parser.add_option("--usfeature_dir", dest="usfeature_dir", default=SVD_USFEATURE_DIR, help="svd user features dir")
    parser.add_option("--itfeature_dir", dest="itfeature_dir", default=SVD_ITFEATURE_DIR, help="svd it features dir")
    parser.add_option("--update_simil", dest="update_simil", default=UPDATE_ITEM_SIMIL, help="whether update item simil")
    parser.add_option("--date_span", dest="date_span", default=45, help="date span for svd model training")
    parser.add_option("--personal_dir", dest="personal_dir", default=SVD_PERSONAL_DIR, help="svd personal dir")
    (flags, args) = parser.parse_args(args)
    svd_item_dir = flags.item2item_dir
    svd_personal_dir = flags.personal_dir
    mode_date = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_date = (datetime.datetime.today() - datetime.timedelta(7)).strftime("%Y-%m-%d")
    # 删除无效的数据:当天及历史数据
    hadoop.del_hdfs([svd_item_dir, svd_personal_dir, flags.itfeature_dir, flags.usfeature_dir], [mode_date, del_date])
    spark = SparkSession.builder.master('yarn-client') \
        .appName('svd:' + mode_date) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    user_item_weight = util.load_file(spark, INPUT_DIR, method='svd', appname='yangsheng', date_span=flags.date_span).map(lambda x: x[:3])
    global itfeatures_dir
    itfeatures_dir = flags.itfeature_dir + mode_date
    global usfeatures_dir
    usfeatures_dir = flags.usfeature_dir + mode_date
    if flags.update_simil:
        item2item_simil_topn=svd_item_simil(spark, user_item_weight, NEIGHBOURS)
        # item2item_simil_topn.map(lambda x: util.add_mode_id(x, SIMIL_MODE_ID)) \
        #     .coalesce(100).saveAsTextFile(svd_item_dir + mode_date)
    else:
        # 加载item2item的相似度数据
        item2item_simil_topn = util.load_item2item(sc, svd_item_dir)
    # user_recommed_list = recommder.recommed_user(sc, item2item_simil_topn, user_item_weight, RECOMMED_NUMS)
    # user_recommed_list.map(lambda x: util.add_mode_id(x, PERSONAL_MODE_ID)) \
    #     .coalesce(100).saveAsTextFile(svd_personal_dir + mode_date)
    spark.stop()



def svd_item_simil(spark, user_item_weight, neighbours):
    """基于奇异值分解计算的相似的商品
    Args:
        user_item(uid,vid, pref):用户视频偏好矩阵
        neighbours:
    Returns:
         item2item_simil(item1,item2,simil,rank):商品到商品的相似度
    """
    user_item_weight = user_item_weight.map(lambda x: Row(diu=x[0], vid=x[1], rating=float(x[2])))
    user_item_df=spark.createDataFrame(user_item_weight)
    diu_user = user_item_df.rdd.map(lambda x: x['diu'])\
        .distinct().zipWithUniqueId()\
        .map(lambda x: Row(diu=x[0], user=x[1]))
    diu_user_tf = spark.createDataFrame(diu_user)
    vid_item = user_item_df.rdd.map(lambda x: x['vid'])\
        .distinct().zipWithUniqueId()\
        .map(lambda x: Row(vid=x[0], item=x[1]))
    vid_item_tf = spark.createDataFrame(vid_item)
    diu_video_tf = user_item_df.join(diu_user_tf, diu_user_tf['diu']==user_item_df['diu']).drop(diu_user_tf['diu'])\
        .join(vid_item_tf, vid_item_tf['vid']==user_item_df['vid']).drop(vid_item_tf['vid'])
    svd_model = ALS(rank=RANK, maxIter=ITERATIONS_NUMS).fit(diu_video_tf)
    it_features = svd_model.itemFactors
    it_features.join(vid_item_tf, vid_item_tf['item']==it_features['id']).drop(it_features['id'])\
        .rdd.map(lambda x: "\t".join([x['vid'], ",".join(map(str, x['features']))]))\
        .repartition(200).saveAsTextFile(itfeatures_dir)
    us_features=svd_model.userFactors
    us_features.join(diu_user_tf, diu_user_tf['user']==us_features['id']).drop(us_features['id'])\
        .rdd.map(lambda x: "\t".join([x['diu'], ",".join(map(str, x['features']))])) \
        .repartition(200).saveAsTextFile(usfeatures_dir)
    # svd_model = ALS.train(user_item_weight, rank=RANK, iterations=ITERATIONS_NUMS)
    # svd_item_id_features = svd_model.productFeatures()
    # svd_item_id_features.map(lambda x:[x[0], ",".join(map(str, list(x[1])))])\
    #     .map(lambda x: "\t".join(x))\
    #     .repartition(200).saveAsTextFile(features_dir)
    # item_item_simil = svd_item_id_features.cartesian(svd_item_id_features).map(Manhattan_simil)
    # # 业务过滤数据
    # filter_item2item = util.filter_item2item(spark, item_item_simil)
    # # 过滤，排序, 小视频top100且 simil>0.01， 大视频top50;小视频35天，大视频7天。最近365天的数据
    # item2item_topN_simil = util.sorted_recommed(filter_item2item)\
    #     .filter(lambda (item1, item2, simil, rank): rank < neighbours)
    # return item2item_topN_simil



def Manhattan_simil(item_item_features):
    """基于svd分解，商品的特征向量来计算商品的曼哈顿距离
    Args:
        item_item_features[(item1, item1_features), (item2, item2_features)]:分别为商品及svd分解后的向量值
    Returns:
        [item1, (item2, simil)]:主商品、推荐商品曼哈顿相似度
    """
    (item1, item1_features), (item2, item2_features) = item_item_features
    item1_features = np.array(item1_features)
    item2_features = np.array(item2_features)
    distance = sum(abs(item1_features - item2_features))
    simil = 1.0 / (1.0 + distance)
    return [item1, (item2, simil)]

if __name__ == "__main__":
    main()

