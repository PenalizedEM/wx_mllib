#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/8/29 下午5:57'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'test_distcp.py.py'
"""
import airflow
from airflow.operators import BashOperator, PythonOperator
from airflow.models import DAG
import datetime
import os
from airflow.operators.python_operator import BranchPythonOperator
import random
HADOOP_BIN='/home/hadoop/bin/hadoop'

start_day=datetime.datetime.now()
model_day = airflow.utils.dates.days_ago(1).strftime("%Y-%m-%d")
#model_day = "2018-08-28"

args = {
    'owner': 'caoyc',
    'depends_on_past': False,
    'email': ['caoyc@tangdou.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': datetime.timedelta(minutes=3),
    'start_date': start_day,
}



dag = DAG(
    dag_id='test_distcp', default_args=args, schedule_interval='@once')


def is_file_exist(hadoop_dir):
    """
    判断hadoop文件是否存在，如果存在返回0，否则返回1
    """
    cmd = "%s fs -test -e %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return ret >> 8

def is_dir_exist(hadoop_dir):
    """
    判断hadoop目录是否存在，如果存在返回0，否则返回1
    """
    cmd = "%s fs -test -d %s" % (HADOOP_BIN, hadoop_dir)
    ret = os.system(cmd)
    return True

dir="hdfs://10.10.186.203:8020/dw/adm/f_wx_video_dv/dt=2018-08-29"

t1 = PythonOperator(
        task_id='t1',
        python_callable=is_dir_exist,
        op_kwargs={'hadoop_dir': dir},
        dag=dag)
