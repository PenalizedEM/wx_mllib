#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/9/4 上午11:18'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'tran_word2vec.py.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from optparse import OptionParser
import datetime
import sys

NODE_PATH="hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/node2vec_result.path"
NODE_INDEX="hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/node2vec_result.n2i"
WORD_INPUT = "hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/word2vec_input_filter"

def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.appName('tran_word2vec:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sql = "select b.vid, b.type from da.video b where b.uid >0  and b.sync =0 and \
    b.status =0 and b.type not in (10,12)"
    norm_vid = spark.sql(sql).rdd.map(lambda x: [str(x['vid']), x['type']])
    node_index = load_nodeindex(sc)
    diu_vid_path = load_path(sc)
    norm_vid.join(node_index)\
        .map(lambda (vid, (type, index)):[index, vid])\
        .join(diu_vid_path)\
        .map(lambda (index,(vid, path)): " ".join([index, path]))\
        .repartition(200).saveAsTextFile(WORD_INPUT)


def load_path(sc):
    def parser(line):
        segment = line.strip().encode("utf-8").split("\t")
        return [segment[0], " ".join(segment[1:])]
    diu_vid_path = sc.textFile(NODE_PATH)\
        .map(parser)
    return diu_vid_path

def load_nodeindex(sc):
    def parser(line):
        segment = line.strip().encode("utf-8").split("\t")
        if len(segment)!=2:
            return None
        return [segment[0], segment[1]]
    node_index = sc.textFile(NODE_INDEX)\
        .map(parser).filter(lambda x: x is not None)
    return node_index



if __name__ == "__main__":
    main()

