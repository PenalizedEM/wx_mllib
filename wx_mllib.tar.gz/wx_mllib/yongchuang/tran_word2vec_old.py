#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/9/4 上午11:18'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'tran_word2vec.py.py'
"""
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from optparse import OptionParser
import datetime
import sys


def main():
    model_day = (datetime.datetime.today()- datetime.timedelta(1)).strftime("%Y-%m-%d")
    spark = SparkSession.builder.appName('recy_ucf:' + model_day) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.textFile("hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/node2vec_result.path")\
        .map(parser).repartition(200).saveAsTextFile("hdfs://Ucluster/user/hive/warehouse/da.db/node2vec/word2vec_input")

def parser(line):
    segment = line.strip().encode("utf-8").split("\t")
    return " ".join(segment)

if __name__ == "__main__":
    main()
