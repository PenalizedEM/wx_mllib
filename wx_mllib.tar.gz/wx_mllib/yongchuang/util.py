# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
File:'util'
Author:'caoyongchuang(caoyongchuang@tangdou.com)'
Date:'2018/06/19 12:50'
"""
import json
import math
import datetime
import re
import numpy as np
import os
import hadoop

from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from py4j.protocol import Py4JJavaError
from pyspark.sql import Row, SparkSession


def update_table(spark):
    """更新分区的table表
    """
    update_uvm(spark)
    update_uvm(spark, "da.f_wx_video_dv", "/olap/da/f_wx_video_dv/dt=", "/part-00000")
    update_uvm(spark, "da.f_wx_video_click", "/olap/da/f_wx_video_click/dt=", "/000000_0.gz")


def update_uvm(spark, table='da.wx_recy_uvm', hdfs='hdfs://Ucluster/olap/da/wx_recy_uvm/dt=', suffix='/000000_*'):
    """更新uvm数据
    """
    def max_dt(table, spark):
        recdf = spark.sql("show partitions " + table)
        res = recdf.rdd.map(lambda v: v.result).collect()
        max_time = max(res)
        return max_time[-10:]
    old_dt = max_dt(table, spark)
    old_date = datetime.datetime.strptime(old_dt, "%Y-%m-%d")
    start_day = datetime.datetime.today()
    day = start_day.strftime("%Y-%m-%d")
    end_day = datetime.datetime.today() - datetime.timedelta(15)
    while start_day >= end_day and start_day > old_date and day!=old_dt:
        if hadoop.is_file_exist(hdfs+day+suffix)==0:
            sql = "alter table %s add partition(dt='%s')" %(table, day)
            spark.sql(sql)
            break
        start_day = start_day - datetime.timedelta(1)
        day = start_day.strftime("%Y-%m-%d")
    return None

def load_file(spark, input_dir, method='cf', date_span=None, appname=None):
    """读取用户视频点击表
    """
    mode_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
    if date_span is not None:
        build_model_day = (datetime.datetime.today() - datetime.timedelta(int(float(date_span)))).strftime("%Y-%m-%d")
    elif method =='cf':
        build_model_day = (datetime.datetime.today()-datetime.timedelta(30)).strftime("%Y-%m-%d")
    elif method in ['ucf', 'word2vec']:
        build_model_day = (datetime.datetime.today()-datetime.timedelta(15)).strftime("%Y-%m-%d")
    cols =['diu', 'vid', 'pref', 'act_day', 'act_dt']
    if appname is None:
        sql = "select u_uuid diu, u_vid vid,\
        if(f_rating=0, 0.5, f_rating)*exp(-0.049*datediff('%s', from_unixtime(f_timestamp, 'yyyy-MM-dd'))) pref,\
        from_unixtime(f_timestamp, 'yyyy-MM-dd') act_day,\
        from_unixtime(f_timestamp, 'yyyy-MM-dd HH:mm:ss') act_dt \
        from da.wx_recy_uvm \
        where dt='%s' and u_appname in ('yangsheng', 'squaredance', 'gaoxiao') and to_date(from_unixtime(f_timestamp)) >= '%s' \
        and to_date(from_unixtime(f_timestamp)) <= '%s' " %(mode_day,mode_day,build_model_day, mode_day)
    else:
        sql = "select u_uuid diu, u_vid vid,\
                if(f_rating=0, 0.5, f_rating)*exp(-0.049*datediff('%s', from_unixtime(f_timestamp, 'yyyy-MM-dd'))) pref,\
                from_unixtime(f_timestamp, 'yyyy-MM-dd') act_day,\
                from_unixtime(f_timestamp, 'yyyy-MM-dd HH:mm:ss') act_dt \
                from da.wx_recy_uvm \
                where dt='%s' and u_appname = '%s' and to_date(from_unixtime(f_timestamp)) >= '%s' \
                and to_date(from_unixtime(f_timestamp)) <= '%s' " % (mode_day, mode_day, appname, build_model_day, mode_day)
    print sql
    return spark.sql(sql).rdd.map(lambda x: [x[col] for col in cols]).filter(lambda x: x[0] not in ['-', ''])


#def load_file(spark, input_dir, method='cf', date_span=None):
#    """读取用户视频点击表
#    """
#    mode_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
#    if date_span is not None:
#        build_model_day = datetime.datetime.today() - datetime.timedelta(int(float(date_span)))
#    elif method =='cf':
#        build_model_day = (datetime.datetime.today()-datetime.timedelta(30)).strftime("%Y-%m-%d")
#    elif method in ['ucf', 'word2vec']:
#        build_model_day = (datetime.datetime.today()-datetime.timedelta(15)).strftime("%Y-%m-%d")
#    build_model_day = build_model_day.strftime("%Y-%m-%d")
#    cols =['diu', 'vid', 'pref', 'act_day', 'act_dt']
#    sql = "select a.* from (select u_uuid diu, u_vid vid, \
#    if(f_rating=0, 0.5, f_rating)*exp(-0.049*datediff('%s', from_unixtime(f_timestamp, 'yyyy-MM-dd'))) pref,\
#    from_unixtime(f_timestamp, 'yyyy-MM-dd') act_day,\
#    from_unixtime(f_timestamp, 'yyyy-MM-dd HH:mm:ss') act_dt \
#    from da.wx_recy_uvm \
#    where dt='%s' and to_date(from_unixtime(f_timestamp)) >= '%s' \
#    and to_date(from_unixtime(f_timestamp)) <= '%s') a \
#    join (select cast(vid AS string) vid from da.video \
#    where parent_category in (1, 2, 16, 20, 21, 22, 36)) b on (a.vid=b.vid) \
#    " %(mode_day,mode_day,build_model_day, mode_day)
#    print sql
#    return spark.sql(sql).rdd.map(lambda x: [x[col] for col in cols]).filter(lambda x: x[0] not in ['-', ''])

def sorted_recommed(recommed_list, method="sum", topn=-1):
    """对用户的推荐列表，按照得分进行排序.
    Args:
        recommed_list:视频相似度列表(item1,(item2, simil)) 或者用户推荐列表(user_id,(item_id,pref))
        method: 存在多个相同推荐商品时，可以按照最大值，或者汇总后排序
    Returns:
        视频相似度排序列表(item1, item2,simil, rank) 或者用户推荐排序列表（user_id, item_id, pref,rank)
    """
    def Combiner(a):
        return [a]
    def MergeValue(a, b):
        a.extend([b])
        return a
    def MergeCombiners(a, b):
        a.extend(b)
        return a
    def sort_item(user_recommed):
        uid, item_list = user_recommed
        item_unique = dict()
        for item_id, pref in item_list:
            if method == "max":
                if pref > item_unique.get(item_id, 0):
                    item_unique[item_id] = pref
            else:
                item_unique[item_id] = pref + item_unique.get(item_id, 0)
        item_list_sorted = sorted(item_unique.iteritems(), key=lambda x: x[1], reverse=True)[:topn]
        return [[uid, value[0], round(value[1], 7), rank] for rank, value in enumerate(item_list_sorted)]
    user_recommed = recommed_list.filter(lambda (user_id, (item_id, pref)):  pref > 0)\
        .combineByKey(Combiner, MergeValue, MergeCombiners)
    return user_recommed.flatMap(sort_item)

def filter_item2item(spark, item2item_simil, is_norm=True):
    """过滤大小视频，uid，sync, status
    Args：
        item2item_simil: (item1,(item2,simil))，视频相似度
        is_norm: 是否是大视频
    Returns:
        (item1,(item2,simil))：过滤后的视频相似度
    """
    item2item_simil=item2item_simil.map(lambda (item1, (item2, simil)): Row(item1=item1, item2=item2, simil=simil))
    item2item = spark.createDataFrame(item2item_simil)
    sql = "select vid, type type1 from da.video where uid >0 and status=0"
    video1 = spark.sql(sql)
    video2 = video1.withColumnRenamed('type1', 'type2')
    cols =['item1', 'item2', 'simil', 'type1', 'type2']
    item2item_type = item2item.join(video1, item2item['item1']==video1['vid'])\
        .drop(video1['vid'])\
        .join(video2, item2item['item2'] == video2['vid'])\
        .drop(video2['vid']).rdd.map(lambda x: [x[col] for col in cols])
    if is_norm:
        filter_item2item_type = item2item_type.filter(lambda x:x[3] not in (10, 12) and x[4] not in (10,12) and x[0]!=x[1])
    else:
        filter_item2item_type = item2item_type.filter(lambda x:  x[4]==10 and x[3] in (10, 12) and x[0]!=x[1])
    return filter_item2item_type.map(lambda x: (x[0], (x[1], x[2])))

def filter_recommed_history(sc, user_recommed_list, user_history_dir):
    """过滤用户的历史推荐列表
    Args:
        user_recommed_list:当天候选的推荐列表
        user_history_dir:最近7天用户的推荐历史
    """
    user_history = load_recommed_history(sc, user_history_dir)
    if user_history is None:
        return user_recommed_list.map(lambda (diu, item, pref, rank): (diu, (item, pref)))
    else:
        user_recommed_list = user_recommed_list.map(lambda (diu, item, pref, rank):[(diu, item), pref])
        return user_recommed_list.subtractByKey(user_history).map(lambda ((diu, item), pref):(diu, (item, pref)))


def load_recommed_history(sc, user_history_dir):
    """加载历史推荐结果表
    """
    def parse_history(line):
        [diu, item, pref, rank] = re.split("\t|\001", line.encode("utf-8").strip())[:4]
        pref = float(pref)
        rank = int(rank)
        return [(diu, item), pref]
    history_days = []
    dt =0
    start_day = datetime.datetime.today() - datetime.timedelta(1)
    while dt < 7:
        start_day = start_day-datetime.timedelta(1)
        history_days.append(start_day.strftime("%Y-%m-%d"))
        dt +=1
    history_data = []
    for day in history_days:
        dir = user_history_dir + day
        if hadoop.is_dir_exist(dir) ==0:
            rdd = sc.textFile(user_history_dir + day).map(parse_history)
            history_data.append(rdd)
    if len(history_data) > 0 :
        rdd= sc.union(history_data)
        try:
            rdd.first()
        except (Py4JJavaError, ValueError):
            return None
        else:
            return rdd
    return None


def filter_exposure(spark, user_recommed_list, appname="squaredance"):
    """过滤用户历史曝光数据
    """
    start_day = (datetime.datetime.today()-datetime.timedelta(7)).strftime("%Y-%m-%d")
    if appname =='':
        start_day = (datetime.datetime.today()-datetime.timedelta(3)).strftime("%Y-%m-%d")
    end_day = (datetime.datetime.today()-datetime.timedelta(1)).strftime("%Y-%m-%d")
    sql = "select d_uuid, d_vid, d_time from da.f_wx_video_dv where d_ptype=1 \
    and d_appname ='%s' and dt >= '%s' and dt <='%s' "%(appname, start_day, end_day)
    exposure_rdd = spark.sql(sql).rdd.map(lambda x: [(x['d_uuid'], x['d_vid']), x['d_time']])
    filter_recommed = user_recommed_list.map(lambda (diu,(item, pref)): [(diu, item), pref])\
        .subtractByKey(exposure_rdd)\
        .map(lambda ((diu, item), pref):(diu, (item, pref)))
    return filter_recommed


def load_item2item(sc, dir, is_dt=True):
    """加载商品到商品的相似度
    Args:
        dir:item2item路径
    Return:
        [item1, item2, pref, rank, mode_id]:商品的相似度
    """
    def parse_item2item(line):
        [item1, item2, simil, rank] = re.split("\t|\001|,", line.encode("utf-8").strip())[:4]
        simil = float(simil)
        rank = int(rank)
        return [item1, item2, simil, rank]
    if is_dt:
        data = load_dir(sc, dir)
    else:
        data = sc.textFile(dir)
    item2item = data.map(parse_item2item)
    return item2item

def load_dir(sc, dir):
    """从文件地址中加载数据，按照最近数据一次读取
    """
    if not dir.endswith("/"):
        dir += "/"
    start_day = datetime.datetime.today()
    end_day = start_day - datetime.timedelta(days=61)
    mode_day = start_day
    while mode_day >= end_day:
        data_load_day = datetime.datetime.strftime(mode_day, "%Y-%m-%d")
        data = sc.textFile(dir + data_load_day)
        try:
            data.first()
        except (Py4JJavaError, ValueError):
            mode_day = mode_day - datetime.timedelta(days=1)
        else:
            return data

def add_mode_id(recom_result, mode_id):
    result = map(str, recom_result)
    result.append(mode_id)
    return "\t".join(result)

