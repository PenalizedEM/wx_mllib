#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/6/14 上午11:47'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'word2vec.py.py'
"""
import datetime
import math
import util
import sys
import re
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from pyspark.sql import Row
from pyspark.ml.feature import Word2Vec
from pyspark.ml.linalg import Vector
#from pyspark.mllib.feature import Word2Vec
#from pyspark.mllib.linalg import Vectors
from py4j.protocol import Py4JJavaError
from optparse import OptionParser
import hadoop


# word2vec表示word的词长度
VECTORSIZE = 64
# item2item商品的相似邻居的个数
NEIGHBOURS = 15
# 用户推荐商品个数
RECOMMED_NUMS = 20
SIMIL_MODE_ID = "13"
WORD2VEC_PERSONAL_DIR =""
INPUT_DIR='/olap/da/word2vec_parse/'
WORD2VEC_SIMIL_DIR = "/olap/da/word2vec_item2item/"
WORD2VEC_FEATURE_DIR = "/olap/da/word2vec_feature/"
UPDATE_ITEM_SIMIL=True


def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--word2vec_parse_dir", dest="word2vec_parse_dir", default=INPUT_DIR, help="word2vec parse dir")
    parser.add_option("--item2item_dir", dest="item2item_dir", default=WORD2VEC_SIMIL_DIR, help="word2vec item simil dir")
    parser.add_option("--features_dir", dest="features_dir", default=WORD2VEC_FEATURE_DIR, help="word2vec features dir")
    parser.add_option("--update_simil", dest="update_simil", default=UPDATE_ITEM_SIMIL, help="whether update item simil")
    parser.add_option("--is_dt", dest="is_dt", default=True, help="whether word2vec parser dir add dt")
    (flags, args) = parser.parse_args(args)
    word2vec_item_dir = flags.item2item_dir
    mode_date = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_date = (datetime.datetime.today() - datetime.timedelta(4)).strftime("%Y-%m-%d")
    # 删除无效的数据:当天及历史数据
    hadoop.del_hdfs([word2vec_item_dir, flags.features_dir], [mode_date, del_date])
    spark = SparkSession.builder.master('yarn-client') \
        .appName('word2vec:' + mode_date) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.addPyFile("hadoop.py") 
    sc.addPyFile("util.py")
    if flags.is_dt in ['False','F','false','f']:
        flags.is_dt = False
    word2vec_input = flags.word2vec_parse_dir
    if flags.is_dt:
        word2vec_input = flags.word2vec_parse_dir+mode_date
    global features_dir
    features_dir = flags.features_dir + mode_date
    if flags.update_simil:
        item2item_simil_topn=word2vector_item_simil(spark, word2vec_input, NEIGHBOURS)
        # item2item_simil_topn.map(lambda x: util.add_mode_id(x, SIMIL_MODE_ID)) \
        #     .coalesce(100).saveAsTextFile(word2vec_item_dir + mode_date)
    else:
        # 加载item2item的相似度数据
        item2item_simil_topn = util.load_item2item(sc, word2vec_item_dir)
    return None

def word2vector_item_simil(spark, word2vec_input, neighbours):
    """基于word2vec方法，计算出商品的相似度
    Args:
        word2vec_input:用户的点击商品序列
        neighbours:商品邻居的个数
    Returns:
         item2item_simil(item1,item2,simil,rank):商品到商品的相似度
    """
    #def cosine_simil(item_item_vectors):
    #    """基于word2vec，商品的特征向量来计算商品的cosine距离
    #    Args:
    #        item_item_vectors:([item1, item1_features], [item2, item2_features]):分别为商品及word2vec表示的向量值
    #    Returns:
    #    [item1, (item2, simil)]:主商品、推荐商品cosine相似度
    #    """
    #    [item1, item1_features] = item_item_vectors
    #    item_item = [[item2, similarity(item1_features, item2_features)] \
    #            for item2, item2_features in item_vectors_dict.value.iteritems()]
    #    sorted_item = sorted(item_item, key=lambda x: x[1], reverse=True)
    #    return [(item1, (item2, simil)) for item2, simil in sorted_item[:RECOMMED_NUMS * 3] if item1 != item2]
    #def similarity(item1_features, item2_features):
    #    norm = math.sqrt(item1_features.dot(item1_features) * item2_features.dot(item2_features))
    #    return item1_features.dot(item2_features) * 1.0 / norm\
    sc = spark.sparkContext
    word2vec_data = sc.textFile(word2vec_input).map(lambda x: Row(x.strip().split(" ")))
    word2vec_df = spark.createDataFrame(word2vec_data, ["sentence"])
    #model = Word2Vec().setVectorSize(VECTORSIZE).setMinCount(10).fit(word2vec_data)
    #item_word2vec = model.getVectors()
    #item_vectors = [[item_id.encode("utf-8"), ",".join(map(str,list(values)))] for item_id, values in item_word2vec.iteritems()]
    ##item_vectors = [[item_id.encode("utf-8"), Vectors.dense(list(values))] for item_id, values in item_word2vec.iteritems()]
    model = Word2Vec(vectorSize=VECTORSIZE, minCount=10,maxIter=10, numPartitions=50, inputCol="sentence", outputCol="model").fit(word2vec_df)
    item_vectors = model.getVectors().rdd.map(lambda x: [x['word'].encode("utf-8"), ",".join(map(str,list(x['vector'])))])
    item_vectors.map(lambda x: "\t".join(x))\
        .repartition(200).saveAsTextFile(features_dir)
    #item_vectors_dict = sc.broadcast(dict(item_vectors))
    # item_vector_p = sc.parallelize(item_vectors, 100)
    # item_item_simil = item_vector_p.flatMap(cosine_simil)
    # # 业务过滤数据
    # filter_item2item = util.filter_item2item(spark, item_item_simil)
    # item2item_topN_simil = util.sorted_recommed(filter_item2item) \
    #     .filter(lambda (item1, item2, simil, rank): rank < neighbours)
    # return item2item_topN_simil
    return None

if __name__ == "__main__":
    main()
