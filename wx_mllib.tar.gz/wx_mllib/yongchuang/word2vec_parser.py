#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""建立word2vec数据
@Time    : '2018/7/5 下午6:41'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'word2vec_parser.py.py'
"""
import sys
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from optparse import OptionParser
import hadoop
INPUT_DIR=''
WORD2VEC_PARSER_DIR='/olap/da/word2vec_parse/'
import util


def main():
    args = map(lambda x:x.lstrip("r") if x.startswith("r--") else x, sys.argv[1:])
    parser = OptionParser()
    parser.add_option("--uvr_dir", dest="uvr_dir", default=INPUT_DIR, help="user item pref dir")
    parser.add_option("--word2vec_dir", dest="word2vec_dir", default=WORD2VEC_PARSER_DIR, help="word2vec parse dir")
    parser.add_option("--date_span", dest="date_span", default=60, help="date span for word2vec model training")
    (flags, args) = parser.parse_args(args)
    word2vec_dir = flags.word2vec_dir
    date_span = int(float(flags.date_span))
    mode_date = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    del_date = (datetime.datetime.today() - datetime.timedelta(4)).strftime("%Y-%m-%d")
    # 删除无效的数据:当天及历史数据
    hadoop.del_hdfs([word2vec_dir], [mode_date, del_date])
    spark = SparkSession.builder \
        .appName('word2vec parser:' + mode_date) \
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse') \
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.addPyFile("hadoop.py")
    sc.addPyFile("util.py")
    user_item_pref = util.load_file(spark, INPUT_DIR, method='word2vec', date_span=date_span)
    user_item_list = user_item_pref.map(lambda (diu, vid, pref, act_day, act_dt):[(diu, act_day),(vid, act_dt)])\
        .groupByKey().map(parse_word2vec).filter(lambda x: x is not None)
    user_item_list.repartition(100).saveAsTextFile(word2vec_dir+mode_date)

def parse_word2vec(line):
    diu_act, vidset = line
    diu, act_day = diu_act
    vid_list = []
    for vid, act_dt in vidset:
        act_time = datetime.datetime.strptime(act_dt,"%Y-%m-%d %H:%M:%S")
        vid_list.append((vid, act_time))
    sorted_vid_list = sorted(vid_list, key=lambda x: x[1], reverse=True)
    nn = len(sorted_vid_list)
    if nn < 5 or nn > 200:
        return None
    vids = map(lambda x: x[0], sorted_vid_list)
    return " ".join(vids)


if __name__ == "__main__":
    main()


