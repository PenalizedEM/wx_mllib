#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/8/13 下午3:04'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'wide_model_dist.py.py'
"""

import tensorflow as tf
import shutil
import util
import glob
from uaitrain.arch.tensorflow import uflag
import os
import datetime
import functools



tf.app.flags.DEFINE_integer("epochs", 1, "Number of epochs")
tf.app.flags.DEFINE_integer("train_epochs", 1, "Number of train epochs")
tf.app.flags.DEFINE_integer("batch_size", 2, "Number of batch size")

FLAGS = tf.app.flags.FLAGS
TRAIN= "./data/train"
TEST = "./data/test"
BATCH = 2
#BATCH = 12800

def main():
    shutil.rmtree(FLAGS.output_dir, ignore_errors=True)
    run_config = run_conf()
    init()
    export_dir = FLAGS.output_dir + '/export_model'
    check_mkdir(export_dir)
    global model_dir
    model_dir = FLAGS.output_dir +'/checkpoints'
    check_mkdir(model_dir)
    #model = build_estimator(model_dir, "wide_deep")
    global train_files
    train_files = get_files(TRAIN)
    global test_files
    test_files = get_files(TEST)
    tf.contrib.learn.learn_runner.run(
        get_experiment_fn(),
        run_config=run_config)

def get_experiment_fn():
    def _experiment_fn(run_config, hparams):
        classifier = build_estimator(FLAGS.output_dir, "wide_deep", run_config=run_config)
        train_input_fn=functools.partial(
            my_input_fn,
            data_file=train_files,
            num_epochs=FLAGS.train_epochs,
            batch_size=FLAGS.batch_size)
        eval_input_fn=functools.partial(
            my_input_fn,
            data_file=train_files,
            num_epochs=1,
            batch_size=FLAGS.batch_size)
        train_steps = FLAGS.train_epochs * 100
        eval_steps = 10
        return tf.contrib.learn.Experiment(
            classifier,
            train_input_fn=train_input_fn,
            eval_input_fn=eval_input_fn,
            train_steps=train_steps,
            eval_steps=10,
            export_strategies=[tf.contrib.learn.make_export_strategy(
                export_fn(),
                exports_to_keep=1
            )]
        )
    return _experiment_fn


def init():
    global feature_name
    feature_name = util.format_all_features(True)
    global feature_default
    feature_default = util.get_feature_default()
    global cate_feature_index
    cate_feature_index = util.get_cate_index()


def run_conf():
    sess_config = tf.ConfigProto(
        allow_soft_placement=True,
        gpu_options=tf.GPUOptions(force_gpu_compatible=True),
        device_count={'GPU': 0})
    run_config = tf.contrib.learn.RunConfig(
        session_config=sess_config,
        model_dir=FLAGS.output_dir)
    return run_config

def build_estimator(model_dir, model_type, run_config):
    hidden_units= [1024, 512, 256]
    wide_columns, deep_columns = build_model_columns()
    if model_type == 'wide':
        return tf.estimator.LinearClassifier(
            model_dir=model_dir,
            feature_columns=wide_columns,
            config=run_config)
    elif model_type == 'deep':
        return tf.estimator.DNNClassifier(
            model_dir=model_dir,
            feature_columns=deep_columns,
            hidden_units=hidden_units,
            config=run_config
        )
    else:
        return tf.estimator.DNNLinearCombinedClassifier(
        #return tf.contrib.learn.DNNLinearCombinedClassifier(
            model_dir=model_dir,
            linear_feature_columns=wide_columns,
            dnn_feature_columns=deep_columns,
            dnn_hidden_units=hidden_units,
            config=run_config
        )


def build_model_columns():
    # 视频连续特征
    it_numeric = util.video_numeric + util.ugc_numeric + util.wx_numeric_tf
    it_com_features = ['_'.join([com_it, str(j)]) for com_it in util.com_item_features \
                       for j in range(util.com_features.get(com_it))]
    it_numeric = it_numeric + it_com_features
    video_numeric_columns = [tf.feature_column.numeric_column(k) for k in it_numeric]

    # 视频类别特征
    video_cate_col = util.video_cate + util.wx_cate
    video_cate_col = util.change_col(video_cate_col)
    # type, child_category, parent_category remove
    # for i in ["ttype","child_category", "parent_category"]:
    #     if i in video_cate_col:
    #         video_cate_col.remove(i)
    video_cate_columns = [tf.feature_column.categorical_column_with_hash_bucket(k, 10) for k in video_cate_col]

    # 用户连续特征
    user_numeric = util.user_numeric
    us_com_features = ['_'.join([com_us, str(j)]) for com_us in util.com_user_features \
                       for j in range(util.com_features.get(com_us))]
    user_numeric = user_numeric + us_com_features
    user_numeric_columns = [tf.feature_column.numeric_column(k) for k in user_numeric]

    # 用户类别特征
    category_dict = util.build_category_dict()
    user_vocabulary_columns = [tf.feature_column.categorical_column_with_vocabulary_list(cate, cate_list) \
                               for cate, cate_list in category_dict.iteritems()]
    user_cate = util.user_cate
    user_cate_columns = [tf.feature_column.categorical_column_with_hash_bucket(k, 20) \
                         for k in util.user_cate if k not in category_dict.keys()]
    # 交叉特征
    cross_col = [
        ['pc', 'pc_2'], ['pc', 'pc_3'], ['pc_2', 'pc_3'],['pc', 'parent_category'],\
        ['pc_2', 'parent_category'],['pc_3', 'parent_category'],['child_category', 'cc'],
        ['child_category', 'cc_2'],['child_category', 'cc_3'],['talent_level', 'pc']
    ]
    crossed_columns = [tf.feature_column.crossed_column(k, hash_bucket_size=30) for k in cross_col]
    # indicator特征
    indicator_columns = [tf.feature_column.indicator_column(k) for k in user_vocabulary_columns]
    # embedding特征
    embedding_col = ['child_category', 'parent_category', 'pc', 'u_client', 'pc_2']
    embedding_columns = [tf.feature_column.categorical_column_with_hash_bucket(k, 20) for k in embedding_col]
    embedding_columns = [tf.feature_column.embedding_column(k, 8) for k in embedding_columns]

    id_cate = [tf.feature_column.categorical_column_with_hash_bucket(k, 10000) for k in ['d_uuid', 'vid', 'uid']]
    id_cross = [tf.feature_column.crossed_column(k, hash_bucket_size=100000) for k in [['d_uuid', 'vid'],['d_uuid', 'uid']]]
    id_embedding = [tf.feature_column.embedding_column(k, 16) for k in id_cate]

    base_columns = video_cate_columns + user_cate_columns + indicator_columns + id_cate
    wide_columns = base_columns + crossed_columns + id_cross
    deep_columns = video_numeric_columns + user_numeric_columns + embedding_columns + id_embedding
    return wide_columns, deep_columns

def my_input_fn(data_file, num_epochs, batch_size=BATCH, shuffle =True, buffer_size=128000):
  def parse_csv(value):
    columns = tf.decode_csv(value, record_defaults=feature_default)
    for index in cate_feature_index:
        columns[index+1] = str(columns[index+1])
    label = columns[0]
    features_value = columns[1:]
    features = dict(zip(feature_name, features_value))
    return features, label
  dataset = tf.data.TextLineDataset(data_file)
  if shuffle:
      dataset = dataset.shuffle(buffer_size)
  dataset = dataset.map(parse_csv, num_parallel_calls=40)
  dataset = dataset.prefetch(batch_size*5)
  dataset = dataset.repeat(num_epochs)
  dataset = dataset.batch(batch_size)
  iterator = dataset.make_one_shot_iterator()
  features, labels = iterator.get_next()
  return features, labels

def export_fn():
    """导出模型用于模型预测
    """
    wide_columns, deep_columns = build_model_columns()
    feature_columns = wide_columns + deep_columns
    feature_spec = tf.feature_column.make_parse_example_spec(feature_columns)
    export_input_fn = tf.estimator.export.build_parsing_serving_input_receiver_fn(feature_spec)
    return export_input_fn

def get_files(dir):
    return glob.glob(dir+'/*')

def check_mkdir(dir):
    if not os.path.exists(dir):
        os.makedirs(dir)

if __name__ == "__main__":
    main()
